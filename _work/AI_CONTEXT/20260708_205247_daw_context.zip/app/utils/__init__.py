"""Gemeinsame Hilfsfunktionen fuer SongStudio."""
