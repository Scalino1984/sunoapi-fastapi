import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useHotkeys } from 'react-hotkeys-hook';
import {
  AlertTriangle,
  ArrowLeft,
  Bot,
  CheckCircle2,
  Copy,
  Download,
  FileAudio,
  Flag,
  GripHorizontal,
  Headphones,
  HelpCircle,
  Loader2,
  Magnet,
  Minus,
  Pause,
  Play,
  Plus,
  Redo2,
  RotateCcw,
  Save,
  Undo2,
  Scissors,
  SkipBack,
  SkipForward,
  SplitSquareHorizontal,
  Trash2,
  Volume2,
  X,
} from 'lucide-react';
import { api } from '../api/client.js';
import { Waveform } from '../components/Waveform.jsx';
import { formatDuration, handleCoverImageError, pickCover, pickTitle } from '../utils.js';
import { useI18n } from '../i18n/I18nContext.jsx';

const TRACKS = [
  { id: 'track-1', name: 'Spur 1' },
  { id: 'track-2', name: 'Spur 2' },
  { id: 'track-3', name: 'Spur 3' },
];
const TOOL_MODES = [
  { id: 'select', label: 'Auswahl', icon: GripHorizontal },
  { id: 'range', label: 'Bereich', icon: Flag },
  { id: 'split', label: 'Schere', icon: Scissors },
  { id: 'marker', label: 'Marker', icon: Flag },
];
const SNAP_UNITS = [
  { id: 'bar', label: 'Takt' },
  { id: 'beat', label: 'Beat' },
  { id: 'half', label: '1/2' },
  { id: 'quarter', label: '1/4' },
];
const DAW_TIMELINE_ZOOM_OPTIONS = [
  { id: 0, label: 'Kompakt', width: 100 },
  { id: 1, label: 'Normal', width: 125 },
  { id: 2, label: 'Groß', width: 160 },
  { id: 3, label: 'Breiter', width: 210 },
  { id: 4, label: 'Max', width: 280 },
];
const TOOL_HELP = {
  select: {
    title: 'Auswahl aktiv',
    text: 'Clip anklicken, halten und ziehen. Linken oder rechten Rand ziehen zum Kürzen.',
  },
  range: {
    title: 'Bereich markieren',
    text: 'Im oberen Ruler-/Markerbereich ziehen oder Strg/Cmd + Klick für Anfang und Alt + Klick für Ende nutzen.',
  },
  split: {
    title: 'Schere aktiv',
    text: 'Klick in einen Clip oder S drücken, um am Playhead zu schneiden.',
  },
  marker: {
    title: 'Marker setzen',
    text: 'Klick im oberen Ruler-/Markerbereich mit aktivem Marker-Werkzeug. Shift + Klick setzt Sprungmarker 1–9.',
  },
};
const DAW_SHORTCUTS = [
  ['Leertaste', 'Play/Pause'],
  ['S', 'am Playhead schneiden'],
  ['Strg/Cmd + Klick oben', 'Bereichsanfang setzen'],
  ['Alt + Klick oben', 'Bereichsende setzen'],
  ['Shift + Klick oben', 'Sprungmarker 1–9 setzen'],
  ['1–9', 'zum passenden Sprungmarker springen'],
  ['Entf / Backspace', 'ausgewählten Clip löschen'],
  ['Esc', 'Auswahl/Bereich aufheben'],
  ['← / →', 'Playhead um 1s bewegen'],
  ['Shift + ← / →', 'Playhead um 5s bewegen'],
  ['Strg/Cmd + Z', 'rückgängig'],
  ['Strg/Cmd + Y', 'wiederholen'],
];

const OUTPUT_FORMATS = ['mp3', 'wav', 'm4a'];
const HISTORY_LIMIT = 40;
const JUMP_MARKER_LABELS = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
const SNAP_EDGE_PIXEL_TOLERANCE = 14;
const SNAP_EDGE_MIN_SECONDS = 0.08;
const SNAP_EDGE_MAX_SECONDS = 0.65;
const SECTION_KIND_LABELS = {
  intro: 'Intro',
  verse: 'Verse',
  pre_chorus: 'Pre-Chorus',
  chorus: 'Chorus / Hook',
  post_chorus: 'Post-Chorus',
  bridge: 'Bridge',
  break: 'Break',
  drop: 'Drop',
  instrumental: 'Instrumental',
  outro: 'Outro',
};
const SECTION_KIND_PRIORITY = ['intro', 'verse', 'pre_chorus', 'chorus', 'post_chorus', 'bridge', 'break', 'drop', 'instrumental', 'outro'];


const DAW_TIMELINE_VISUAL_CSS = `
/* DAW Step 2 Repair: lokale Timeline-Optik ohne globale CSS-Risiken.
   Ziel: keine Fremdrahmen um Clips, Waveform wieder in voller Hoehe, Playhead-Linie blockiert keine Clip-Auswahl.
   Nicht erweitern fuer Header, MiniPlayer, Library oder globale Komponenten. */
.daw-filmora-timeline .daw-arr-ruler,
.daw-filmora-timeline .daw-arr-markers {
  cursor: crosshair;
}
.daw-filmora-timeline .daw-arr-playhead,
.daw-filmora-timeline .daw-arr-playhead::after {
  pointer-events: none !important;
}

.daw-filmora-timeline .daw-arr-timeline {
  overflow-x: auto !important;
  overflow-y: hidden !important;
  background: linear-gradient(180deg, rgba(8,13,27,.96), rgba(4,8,18,.98));
  scrollbar-width: thin;
  scrollbar-color: rgba(103, 232, 249, .36) rgba(15, 23, 42, .42);
}
.daw-filmora-timeline .daw-arr-timeline::-webkit-scrollbar { height: 10px; }
.daw-filmora-timeline .daw-arr-timeline::-webkit-scrollbar-track { background: rgba(15, 23, 42, .42); border-radius: 999px; }
.daw-filmora-timeline .daw-arr-timeline::-webkit-scrollbar-thumb { background: rgba(103, 232, 249, .34); border-radius: 999px; }
.daw-filmora-timeline .daw-arr-timeline-canvas {
  position: relative;
  width: var(--daw-timeline-width, 100%);
  min-width: 100%;
  min-height: 378px;
  background:
    linear-gradient(90deg, rgba(148,163,184,.08) 1px, transparent 1px) 0 0 / 8.333% 100%,
    linear-gradient(180deg, rgba(8,13,27,.96), rgba(4,8,18,.98));
}
.daw-filmora-timeline .daw-arr-track-head.spacer {
  height: 90px;
}
.daw-filmora-timeline .daw-arr-ruler {
  height: 48px;
  background: linear-gradient(180deg, rgba(20, 31, 55, .88), rgba(10, 16, 31, .78));
  border-bottom-color: rgba(103, 232, 249, .18);
}
.daw-filmora-timeline .daw-arr-ruler span {
  top: 0;
  height: 100%;
  display: flex;
  align-items: flex-start;
  padding-top: 8px;
  padding-left: 8px;
  color: rgba(226, 232, 240, .86);
  font-size: .74rem;
  font-weight: 900;
  border-left-color: rgba(148, 163, 184, .34);
  text-shadow: 0 1px 8px rgba(0,0,0,.38);
}
.daw-filmora-timeline .daw-arr-ruler span.major {
  color: #f8fafc;
  border-left-color: rgba(103, 232, 249, .70);
  background: linear-gradient(90deg, rgba(103, 232, 249, .08), transparent 40px);
}
.daw-filmora-timeline .daw-arr-ruler span.minor {
  color: rgba(203, 213, 225, .62);
  font-size: .68rem;
}
.daw-filmora-timeline .daw-timeline-zoom-group {
  min-width: 220px;
}
.daw-filmora-timeline .daw-timeline-zoom-group .daw-zoom-label {
  min-width: 68px;
  text-align: center;
  color: #e0f2fe;
  font-weight: 900;
}
.daw-filmora-timeline .daw-arr-clip {
  top: 9px;
  bottom: 9px;
  overflow: visible;
  border: 0 !important;
  outline: 0;
  background: transparent !important;
  box-shadow: none !important;
  cursor: grab;
}
.daw-filmora-timeline .daw-arr-clip:hover,
.daw-filmora-timeline .daw-arr-clip.selected {
  border: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform {
  position: absolute;
  inset: 0;
  display: block;
  pointer-events: none;
  z-index: 2;
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform .react-waveform {
  height: 100%;
  min-height: 0;
  padding: 26px 10px 8px;
  border: 0;
  border-radius: 10px;
  background:
    linear-gradient(180deg, rgba(14, 165, 233, .14), rgba(8, 13, 27, .30)),
    rgba(3, 7, 18, .56);
  box-shadow: inset 0 0 0 1px rgba(103, 232, 249, .16);
}
.daw-filmora-timeline .daw-arr-clip:hover .clip-waveform .react-waveform {
  box-shadow: inset 0 0 0 1px rgba(103, 232, 249, .34);
}
.daw-filmora-timeline .daw-arr-clip.selected .clip-waveform .react-waveform {
  background:
    linear-gradient(180deg, rgba(45, 212, 191, .20), rgba(14, 165, 233, .12) 46%, rgba(79, 70, 229, .18)),
    rgba(3, 7, 18, .62);
  box-shadow:
    inset 0 0 0 2px rgba(255, 255, 255, .88),
    inset 0 0 0 4px rgba(34, 211, 238, .20),
    0 0 0 1px rgba(34, 211, 238, .36),
    0 14px 26px rgba(14, 165, 233, .18);
}
.daw-filmora-timeline .daw-arr-clip.selected::before {
  content: '';
  position: absolute;
  inset: 1px;
  z-index: 4;
  pointer-events: none;
  border-radius: 10px;
  border-top: 2px solid rgba(255,255,255,.86);
  border-bottom: 2px solid rgba(34,211,238,.66);
  box-shadow: inset 0 0 22px rgba(34, 211, 238, .10);
}
.daw-filmora-timeline .daw-arr-clip.selected::after {
  content: '';
  position: absolute;
  left: 8px;
  top: 50%;
  z-index: 5;
  width: 4px;
  height: calc(100% - 22px);
  min-height: 28px;
  transform: translateY(-50%);
  border-radius: 999px;
  background: linear-gradient(180deg, #ffffff, #67e8f9);
  box-shadow: 0 0 16px rgba(34, 211, 238, .42);
  pointer-events: none;
}
.daw-filmora-timeline .daw-arr-clip.selected .clip-waveform .react-waveform-bars span {
  opacity: 1;
  filter: saturate(1.16) brightness(1.08);
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform .react-waveform-bars {
  height: calc(100% - 4px);
  min-height: 42px;
  align-items: end;
  gap: 1px;
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform .react-waveform-bars span {
  min-width: 2px;
  max-width: 9px;
  opacity: .96;
  background: linear-gradient(180deg, #67e8f9 0%, #22d3ee 45%, #ec4899 72%, #8b5cf6 100%);
  box-shadow: 0 0 10px rgba(34, 211, 238, .12);
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform .react-waveform-segments {
  inset: 4px 8px auto 8px;
  height: 20px;
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform .react-waveform-segment {
  top: 0;
  height: 17px;
  border-radius: 999px;
  padding: 1px 7px;
  font-size: 10px;
  line-height: 15px;
  pointer-events: none;
}
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 14px;
  z-index: 25;
  cursor: ew-resize;
  border: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
  opacity: 0;
  transition: opacity .12s ease;
}
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle::before,
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle::after {
  content: '';
  position: absolute;
  pointer-events: none;
}
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle::before {
  top: 0;
  bottom: 0;
  width: 28px;
}
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle::after {
  top: 50%;
  width: 2px;
  height: 28px;
  transform: translateY(-50%);
  border-radius: 999px;
  background: rgba(255, 255, 255, .72);
  box-shadow: none;
}
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle.left { left: 0; }
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle.left::before { left: 0; }
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle.left::after { left: 5px; }
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle.right { right: 0; }
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle.right::before { right: 0; }
.daw-filmora-timeline .daw-arr-clip .clip-resize-handle.right::after { right: 5px; }
.daw-filmora-timeline .daw-arr-clip:hover .clip-resize-handle,
.daw-filmora-timeline .daw-arr-clip.selected .clip-resize-handle {
  opacity: .95;
}
.daw-filmora-timeline .daw-arr-clip .clip-fade-overlay {
  position: absolute;
  top: 6px;
  bottom: 6px;
  z-index: 13;
  pointer-events: none;
  opacity: .55;
  min-width: 0;
}
.daw-filmora-timeline .daw-arr-clip .clip-fade-overlay.in {
  left: 14px;
  border-radius: 8px 0 0 8px;
  background: linear-gradient(115deg, rgba(15, 23, 42, .86), rgba(34, 211, 238, .18));
  border-right: 1px solid rgba(103, 232, 249, .36);
  clip-path: none;
}
.daw-filmora-timeline .daw-arr-clip .clip-fade-overlay.out {
  right: 14px;
  border-radius: 0 8px 8px 0;
  background: linear-gradient(245deg, rgba(15, 23, 42, .86), rgba(236, 72, 153, .18));
  border-left: 1px solid rgba(244, 114, 182, .34);
  clip-path: none;
}
.daw-filmora-timeline .daw-arr-clip .clip-fade-handle {
  position: absolute;
  top: 7px;
  z-index: 31;
  width: 14px;
  height: 14px;
  transform: translateX(-50%);
  border-radius: 999px;
  border: 1px solid rgba(255, 255, 255, .82);
  background: rgba(15, 23, 42, .88);
  box-shadow: 0 0 0 2px rgba(15, 23, 42, .52), 0 6px 14px rgba(0,0,0,.30);
  cursor: ew-resize;
  pointer-events: auto;
  opacity: 0;
  transition: opacity .12s ease, transform .12s ease;
}
.daw-filmora-timeline .daw-arr-clip:hover .clip-fade-handle,
.daw-filmora-timeline .daw-arr-clip.selected .clip-fade-handle {
  opacity: .95;
}
.daw-filmora-timeline .daw-arr-clip .clip-fade-handle:hover,
.daw-filmora-timeline .daw-arr-clip .clip-fade-handle:focus-visible {
  outline: none;
  transform: translateX(-50%) scale(1.12);
}

.daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-compact {
  display: grid;
  grid-template-columns: minmax(280px, .8fr) minmax(420px, 1.25fr) minmax(320px, .85fr);
  gap: 12px;
  align-items: stretch;
  padding: 12px;
}
.daw-filmora-timeline .daw-arr-context-card,
.daw-filmora-timeline .daw-arr-clip-inspector,
.daw-filmora-timeline .daw-arr-preview-card {
  border: 1px solid rgba(148, 163, 184, .14);
  border-radius: 16px;
  background: rgba(6, 10, 22, .58);
  padding: 14px;
  min-width: 0;
}
.daw-filmora-timeline .daw-arr-context-card {
  display: grid;
  align-content: space-between;
  gap: 12px;
}
.daw-filmora-timeline .daw-arr-context-head,
.daw-filmora-timeline .daw-arr-inspector-head,
.daw-filmora-timeline .daw-arr-preview-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 10px;
}
.daw-filmora-timeline .daw-arr-context-head strong,
.daw-filmora-timeline .daw-arr-inspector-head strong,
.daw-filmora-timeline .daw-arr-preview-head strong {
  display: block;
  color: #f8fafc;
  font-weight: 950;
}
.daw-filmora-timeline .daw-arr-context-head span,
.daw-filmora-timeline .daw-arr-inspector-head span,
.daw-filmora-timeline .daw-arr-preview-head span {
  display: block;
  margin-top: 3px;
  color: rgba(203, 213, 225, .68);
  font-size: .78rem;
}
.daw-filmora-timeline .daw-arr-context-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
}
.daw-filmora-timeline .daw-arr-context-meta span {
  display: inline-flex;
  align-items: center;
  min-height: 28px;
  border: 1px solid rgba(148, 163, 184, .16);
  border-radius: 999px;
  padding: 4px 9px;
  color: rgba(226, 232, 240, .82);
  background: rgba(15, 23, 42, .62);
  font-size: .76rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-arr-compact-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.daw-filmora-timeline .daw-arr-compact-actions button {
  min-height: 34px;
  padding: 7px 10px;
}
.daw-filmora-timeline .daw-arr-clip-inspector.is-empty {
  display: grid;
  place-items: center;
  min-height: 190px;
  color: rgba(203, 213, 225, .70);
  text-align: center;
}
.daw-filmora-timeline .daw-arr-clip-fields {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
}
.daw-filmora-timeline .daw-arr-clip-fields label,
.daw-filmora-timeline .daw-arr-preview-fields label {
  display: grid;
  gap: 6px;
  color: rgba(203, 213, 225, .70);
  font-size: .75rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-arr-clip-fields label.wide {
  grid-column: span 2;
}
.daw-filmora-timeline .daw-arr-clip-fields input,
.daw-filmora-timeline .daw-arr-preview-fields input {
  min-height: 36px;
}
.daw-filmora-timeline .daw-arr-preview-card {
  display: grid;
  gap: 10px;
}
.daw-filmora-timeline .daw-arr-preview-fields {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 10px;
}
.daw-filmora-timeline .daw-arr-preview-card audio {
  width: 100%;
}
@media (max-width: 1280px) {
  .daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-compact {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-arr-clip-fields {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 720px) {
  .daw-filmora-timeline .daw-arr-clip-fields {
    grid-template-columns: 1fr;
  }
}

/* DAW UX Cleanup: zentrale Werkzeugleiste sichtbar, Footer nur Inspector/Vorschau.
   Bewusst lokal auf /daw gekapselt; keine app.css-/MiniPlayer-/Library-Anpassungen. */
.daw-filmora-timeline .daw-main-action-toolbar {
  align-items: stretch;
  gap: 10px;
}
.daw-filmora-timeline .daw-toolbar-cluster {
  flex: 1 1 360px;
  min-width: 0;
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  border: 1px solid rgba(148, 163, 184, .14);
  border-radius: 14px;
  background: rgba(5, 10, 24, .44);
}
.daw-filmora-timeline .daw-toolbar-actions {
  flex: 1.6 1 520px;
  border-color: rgba(103, 232, 249, .20);
  background: linear-gradient(135deg, rgba(8, 47, 73, .18), rgba(5, 10, 24, .44));
}
.daw-filmora-timeline .daw-toolbar-buttons {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  min-width: 0;
}
.daw-filmora-timeline .daw-toolbar-buttons button {
  min-height: 36px;
  padding: 8px 11px;
  font-weight: 850;
}
.daw-filmora-timeline .daw-toolbar-primary-action {
  border-color: rgba(103, 232, 249, .42);
  background: rgba(14, 165, 233, .14);
  color: #e0f2fe;
}
.daw-filmora-timeline .daw-toolbar-check {
  flex: 0 0 auto;
  min-height: 36px;
  padding: 8px 11px;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, .16);
  background: rgba(255,255,255,.045);
  font-weight: 850;
}
.daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-streamlined {
  display: grid;
  grid-template-columns: minmax(560px, 1.45fr) minmax(330px, .55fr);
  gap: 12px;
  align-items: stretch;
  padding: 12px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector,
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-preview-card {
  border: 1px solid rgba(148, 163, 184, .14);
  border-radius: 16px;
  background: rgba(6, 10, 22, .58);
  padding: 14px;
  min-width: 0;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector.is-empty {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 96px;
  color: rgba(203, 213, 225, .72);
}
.daw-filmora-timeline .daw-arr-empty-inspector {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.daw-filmora-timeline .daw-arr-inspector-head,
.daw-filmora-timeline .daw-arr-preview-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 10px;
}
.daw-filmora-timeline .daw-arr-inspector-head strong,
.daw-filmora-timeline .daw-arr-preview-head strong {
  display: block;
  color: #f8fafc;
  font-weight: 950;
}
.daw-filmora-timeline .daw-arr-inspector-pills {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 6px;
}
.daw-filmora-timeline .daw-arr-inspector-pills span {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  padding: 4px 8px;
  border-radius: 999px;
  border: 1px solid rgba(148, 163, 184, .16);
  background: rgba(255,255,255,.045);
  color: rgba(226, 232, 240, .86);
  font-size: .74rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-arr-clip-fields {
  display: grid;
  grid-template-columns: minmax(180px, 1.1fr) repeat(3, minmax(110px, .8fr));
  gap: 9px;
}
.daw-filmora-timeline .daw-arr-clip-fields .wide {
  grid-column: span 1;
}
.daw-filmora-timeline .daw-arr-clip-fields label,
.daw-filmora-timeline .daw-arr-preview-fields label {
  display: grid;
  gap: 5px;
  color: rgba(203, 213, 225, .76);
  font-size: .73rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-arr-clip-fields input,
.daw-filmora-timeline .daw-arr-preview-fields input {
  min-height: 34px;
  padding: 7px 9px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) {
  padding: 18px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) .daw-arr-inspector-head {
  margin-bottom: 14px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) .daw-arr-clip-fields {
  gap: 12px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) .daw-arr-clip-fields label {
  gap: 7px;
  font-size: .80rem;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) .daw-arr-clip-fields input {
  min-height: 42px;
  padding: 10px 12px;
  border-radius: 12px;
  font-size: .92rem;
  font-weight: 800;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-inspector-head .danger {
  min-height: 40px;
  padding: 9px 12px;
}
.daw-filmora-timeline .daw-arr-preview-fields {
  display: grid;
  gap: 10px;
}
.daw-filmora-timeline .daw-arr-warning-row.compact {
  margin-top: 10px;
}
@media (max-width: 1180px) {
  .daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-streamlined {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-arr-clip-fields {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 760px) {
  .daw-filmora-timeline .daw-toolbar-cluster,
  .daw-filmora-timeline .daw-arr-clip-fields {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-arr-empty-inspector,
  .daw-filmora-timeline .daw-arr-inspector-head,
  .daw-filmora-timeline .daw-arr-preview-head {
    display: grid;
  }
}

/* DAW Step 1 Final: sichtbare Snap-Guides und klarere direkte Clip-Aktionen. */
.daw-filmora-timeline .daw-snap-guide {
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 48;
  width: 0;
  pointer-events: none;
  border-left: 2px solid rgba(255, 255, 255, .92);
  filter: drop-shadow(0 0 8px rgba(34, 211, 238, .72));
}
.daw-filmora-timeline .daw-snap-guide::before {
  content: '';
  position: absolute;
  top: 48px;
  left: -5px;
  width: 9px;
  height: 9px;
  border-radius: 999px;
  background: #ffffff;
  box-shadow: 0 0 0 4px rgba(34, 211, 238, .18), 0 0 18px rgba(34, 211, 238, .52);
}
.daw-filmora-timeline .daw-snap-guide-label {
  position: absolute;
  top: 58px;
  left: 8px;
  transform: translateX(0);
  max-width: 220px;
  white-space: nowrap;
  border: 1px solid rgba(255, 255, 255, .18);
  border-radius: 999px;
  padding: 5px 9px;
  background: rgba(2, 6, 23, .92);
  color: #f8fafc;
  font-size: .72rem;
  font-weight: 950;
  box-shadow: 0 14px 34px rgba(0,0,0,.42);
}
.daw-filmora-timeline .daw-clip-quick-actions {
  display: flex;
  align-items: center;
  gap: 7px;
  flex-wrap: wrap;
}
.daw-filmora-timeline .daw-clip-quick-actions button {
  min-height: 36px;
  padding: 8px 10px;
  font-weight: 850;
}
.daw-filmora-timeline .daw-toolbar-clip-actions {
  flex: 1.15 1 420px;
  border-color: rgba(167, 243, 208, .20);
  background: linear-gradient(135deg, rgba(20, 83, 45, .14), rgba(5, 10, 24, .44));
}
.daw-filmora-timeline .daw-toolbar-clip-actions .daw-group-label {
  color: rgba(187, 247, 208, .86);
}
.daw-filmora-timeline .daw-arr-ruler span::after {
  content: '';
  position: absolute;
  left: -1px;
  bottom: 0;
  width: 1px;
  height: 18px;
  background: rgba(148, 163, 184, .34);
}
.daw-filmora-timeline .daw-arr-ruler span.major::after {
  height: 30px;
  width: 2px;
  background: rgba(103, 232, 249, .72);
}



/* DAW Step 3 Segment Resolver: Abschnittsauswahl und Aktionen ohne globale CSS-Aenderungen. */
.daw-filmora-timeline .daw-section-resolver-strip {
  display: grid;
  grid-template-columns: minmax(280px, .8fr) minmax(360px, 1.1fr) auto;
  gap: 12px;
  align-items: center;
  margin-top: 10px;
  padding: 12px;
  border: 1px solid rgba(103, 232, 249, .16);
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(8, 47, 73, .16), rgba(6, 10, 22, .58));
}
.daw-filmora-timeline .daw-section-resolver-head {
  display: grid;
  gap: 4px;
  min-width: 0;
}
.daw-filmora-timeline .daw-section-resolver-head strong {
  color: #f8fafc;
  font-weight: 950;
}
.daw-filmora-timeline .daw-section-resolver-head span {
  color: rgba(203, 213, 225, .72);
  font-size: .78rem;
  font-weight: 760;
}
.daw-filmora-timeline .daw-section-resolver-main {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.daw-filmora-timeline .daw-section-select {
  min-width: 280px;
  max-width: 520px;
  flex: 1 1 320px;
  min-height: 38px;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, .18);
  background: rgba(2, 6, 23, .58);
  color: #f8fafc;
  padding: 8px 10px;
  font-weight: 850;
}
.daw-filmora-timeline .daw-section-meta-pills {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.daw-filmora-timeline .daw-section-meta-pills span {
  display: inline-flex;
  align-items: center;
  min-height: 26px;
  padding: 4px 8px;
  border-radius: 999px;
  border: 1px solid rgba(148, 163, 184, .16);
  background: rgba(255,255,255,.045);
  color: rgba(226, 232, 240, .84);
  font-size: .74rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-section-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 8px;
}
.daw-filmora-timeline .daw-section-actions button {
  min-height: 38px;
  padding: 8px 11px;
  font-weight: 900;
}
.daw-filmora-timeline .daw-section-actions .primary-soft {
  border-color: rgba(34, 211, 238, .36);
  background: rgba(14, 165, 233, .14);
  color: #e0f2fe;
}
.daw-filmora-timeline .daw-arr-track-head.spacer {
  height: 122px;
}
.daw-filmora-timeline .daw-arr-sections {
  position: relative;
  height: 32px;
  border-bottom: 1px solid rgba(148, 163, 184, .12);
  background: linear-gradient(180deg, rgba(15, 23, 42, .52), rgba(2, 6, 23, .62));
  overflow: hidden;
}
.daw-filmora-timeline .daw-arr-section-chip {
  position: absolute;
  top: 5px;
  height: 22px;
  min-width: 42px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  border: 1px solid rgba(34, 211, 238, .22);
  border-radius: 999px;
  padding: 2px 8px;
  background: rgba(14, 165, 233, .11);
  color: rgba(226, 232, 240, .86);
  font-size: .68rem;
  font-weight: 950;
  cursor: pointer;
}
.daw-filmora-timeline .daw-arr-section-chip.selected {
  border-color: rgba(255, 255, 255, .74);
  background: linear-gradient(135deg, rgba(34, 211, 238, .30), rgba(236, 72, 153, .20));
  color: #ffffff;
  box-shadow: 0 0 18px rgba(34, 211, 238, .20);
}
.daw-filmora-timeline .daw-command-section-choice {
  display: grid;
  gap: 8px;
  border: 1px solid rgba(34, 211, 238, .16);
  border-radius: 14px;
  padding: 11px 12px;
  background: rgba(8, 47, 73, .14);
}
.daw-filmora-timeline .daw-command-section-choice strong {
  color: #f8fafc;
}
.daw-filmora-timeline .daw-command-section-choice span {
  color: rgba(203, 213, 225, .76);
  font-size: .80rem;
  font-weight: 800;
}
@media (max-width: 1180px) {
  .daw-filmora-timeline .daw-section-resolver-strip {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-section-actions {
    justify-content: flex-start;
  }
}
@media (max-width: 760px) {
  .daw-filmora-timeline .daw-section-resolver-main {
    display: grid;
  }
  .daw-filmora-timeline .daw-section-select {
    min-width: 0;
    width: 100%;
  }
}

/* DAW Step 2 Command Engine: Vorschau-Modal fuer sichere Bearbeitungsplaene. */
.daw-filmora-timeline .daw-command-backdrop {
  position: fixed;
  inset: 0;
  z-index: 1200;
  display: grid;
  place-items: center;
  padding: 24px;
  background: rgba(2, 6, 23, .72);
  backdrop-filter: blur(10px);
}
.daw-filmora-timeline .daw-command-modal {
  width: min(760px, calc(100vw - 36px));
  max-height: calc(100vh - 48px);
  overflow: auto;
  border: 1px solid rgba(103, 232, 249, .24);
  border-radius: 22px;
  background: linear-gradient(180deg, rgba(15, 23, 42, .96), rgba(3, 7, 18, .98));
  box-shadow: 0 28px 80px rgba(0, 0, 0, .58);
}
.daw-filmora-timeline .daw-command-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  padding: 20px 22px 14px;
  border-bottom: 1px solid rgba(148, 163, 184, .14);
}
.daw-filmora-timeline .daw-command-header p {
  margin: 0 0 4px;
  color: rgba(103, 232, 249, .92);
  font-size: .72rem;
  font-weight: 950;
  letter-spacing: .11em;
  text-transform: uppercase;
}
.daw-filmora-timeline .daw-command-header h3 {
  margin: 0;
  color: #f8fafc;
  font-size: 1.18rem;
}
.daw-filmora-timeline .daw-command-body {
  display: grid;
  gap: 14px;
  padding: 18px 22px 20px;
}
.daw-filmora-timeline .daw-command-summary {
  border: 1px solid rgba(148, 163, 184, .14);
  border-radius: 16px;
  padding: 13px 14px;
  background: rgba(15, 23, 42, .56);
  color: rgba(226, 232, 240, .86);
  font-weight: 750;
  line-height: 1.45;
}
.daw-filmora-timeline .daw-command-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
}
.daw-filmora-timeline .daw-command-metric {
  border: 1px solid rgba(148, 163, 184, .14);
  border-radius: 14px;
  padding: 11px 12px;
  background: rgba(255, 255, 255, .045);
}
.daw-filmora-timeline .daw-command-metric span {
  display: block;
  margin-bottom: 4px;
  color: rgba(203, 213, 225, .66);
  font-size: .72rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-command-metric strong {
  color: #f8fafc;
  font-size: .98rem;
}
.daw-filmora-timeline .daw-command-actions-list {
  display: grid;
  gap: 7px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.daw-filmora-timeline .daw-command-actions-list li {
  display: flex;
  align-items: center;
  gap: 9px;
  min-height: 34px;
  border: 1px solid rgba(148, 163, 184, .12);
  border-radius: 12px;
  padding: 7px 10px;
  background: rgba(2, 6, 23, .38);
  color: rgba(226, 232, 240, .86);
  font-size: .82rem;
  font-weight: 780;
}
.daw-filmora-timeline .daw-command-actions-list li svg {
  color: rgba(34, 211, 238, .92);
  flex: 0 0 auto;
}
.daw-filmora-timeline .daw-command-warning-list {
  display: grid;
  gap: 6px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.daw-filmora-timeline .daw-command-warning-list li {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #fde68a;
  font-size: .82rem;
  font-weight: 800;
}
.daw-filmora-timeline .daw-command-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 0 22px 20px;
}


/* DAW Step 4 KI-DAW: kompakte Command-Zeile und Preview-Erklaerung. */
.daw-filmora-timeline .daw-ai-command-strip {
  display: grid;
  grid-template-columns: minmax(210px, .58fr) minmax(420px, 1.35fr) auto;
  gap: 12px;
  align-items: center;
  margin-top: 10px;
  padding: 12px;
  border: 1px solid rgba(168, 85, 247, .22);
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(88, 28, 135, .18), rgba(6, 10, 22, .62));
}
.daw-filmora-timeline .daw-ai-command-head {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.daw-filmora-timeline .daw-ai-command-head svg {
  color: rgba(216, 180, 254, .96);
  flex: 0 0 auto;
}
.daw-filmora-timeline .daw-ai-command-head strong {
  display: block;
  color: #f8fafc;
  font-weight: 950;
}
.daw-filmora-timeline .daw-ai-command-head span {
  display: block;
  color: rgba(203, 213, 225, .70);
  font-size: .74rem;
  font-weight: 780;
}
.daw-filmora-timeline .daw-ai-command-form {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.daw-filmora-timeline .daw-ai-command-form input {
  flex: 1 1 auto;
  min-width: 240px;
  min-height: 40px;
  border-radius: 13px;
  border: 1px solid rgba(216, 180, 254, .20);
  background: rgba(2, 6, 23, .62);
  color: #f8fafc;
  padding: 9px 12px;
  font-weight: 850;
}
.daw-filmora-timeline .daw-ai-command-form input:focus {
  outline: none;
  border-color: rgba(216, 180, 254, .56);
  box-shadow: 0 0 0 3px rgba(168, 85, 247, .14);
}
.daw-filmora-timeline .daw-ai-command-form button {
  min-height: 40px;
  font-weight: 950;
}
.daw-filmora-timeline .daw-ai-command-examples {
  display: flex;
  justify-content: flex-end;
  flex-wrap: wrap;
  gap: 7px;
}
.daw-filmora-timeline .daw-ai-command-examples button {
  min-height: 34px;
  padding: 7px 10px;
  border-color: rgba(216, 180, 254, .18);
  background: rgba(168, 85, 247, .10);
  color: rgba(245, 243, 255, .90);
  font-size: .76rem;
  font-weight: 880;
}
.daw-filmora-timeline .daw-ai-command-status {
  grid-column: 2 / 4;
  color: rgba(216, 180, 254, .86);
  font-size: .78rem;
  font-weight: 840;
}
.daw-filmora-timeline .daw-ai-command-preview {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  border: 1px solid rgba(216, 180, 254, .18);
  border-radius: 14px;
  padding: 11px 12px;
  background: rgba(88, 28, 135, .14);
  color: rgba(245, 243, 255, .88);
  font-weight: 800;
}
.daw-filmora-timeline .daw-ai-command-preview svg {
  color: rgba(216, 180, 254, .95);
  flex: 0 0 auto;
  margin-top: 1px;
}
.daw-filmora-timeline .daw-ai-command-preview strong {
  display: block;
  margin-bottom: 3px;
  color: #faf5ff;
}
.daw-filmora-timeline .daw-ai-command-preview span {
  display: block;
  color: rgba(233, 213, 255, .78);
  font-size: .80rem;
  line-height: 1.35;
}
@media (max-width: 1180px) {
  .daw-filmora-timeline .daw-ai-command-strip {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-ai-command-status {
    grid-column: auto;
  }
  .daw-filmora-timeline .daw-ai-command-examples {
    justify-content: flex-start;
  }
}
@media (max-width: 720px) {
  .daw-filmora-timeline .daw-ai-command-form {
    display: grid;
  }
  .daw-filmora-timeline .daw-ai-command-form input {
    min-width: 0;
    width: 100%;
  }
}

@media (max-width: 760px) {
  .daw-filmora-timeline .daw-command-grid {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-command-footer {
    display: grid;
  }
}
/* DAW UX Final Polish: klare Bedienhierarchie statt Button-Wirrwarr.
   Nur lokal unter .daw-filmora-timeline, keine app.css- oder globale Layout-Aenderung. */
.daw-filmora-timeline {
  --daw-cyan: #22d3ee;
  --daw-blue: #38bdf8;
  --daw-green: #34d399;
  --daw-violet: #a78bfa;
  --daw-amber: #fbbf24;
  --daw-red: #fb7185;
  --daw-panel: rgba(5, 10, 24, .74);
  --daw-panel-soft: rgba(15, 23, 42, .58);
  --daw-border: rgba(148, 163, 184, .15);
}
.daw-filmora-timeline .daw-ux-console {
  display: grid;
  gap: 10px;
  padding: 12px;
  border-color: rgba(59, 130, 246, .18);
  background:
    radial-gradient(circle at 8% 0%, rgba(14, 165, 233, .10), transparent 36%),
    linear-gradient(180deg, rgba(6, 10, 22, .88), rgba(3, 7, 18, .86));
}
.daw-filmora-timeline .daw-console-row {
  display: grid;
  gap: 10px;
  align-items: stretch;
}
.daw-filmora-timeline .daw-console-top {
  grid-template-columns: minmax(420px, 1.35fr) minmax(360px, 1fr) minmax(280px, .72fr);
}
.daw-filmora-timeline .daw-workbench-toolbar {
  grid-template-columns: minmax(280px, .75fr) minmax(420px, 1.05fr) minmax(460px, 1.15fr);
}
.daw-filmora-timeline .daw-console-card,
.daw-filmora-timeline .daw-toolbar-zone,
.daw-filmora-timeline .daw-smart-card {
  position: relative;
  min-width: 0;
  border: 1px solid var(--daw-border);
  border-radius: 15px;
  padding: 10px;
  background: var(--daw-panel);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.035);
}
.daw-filmora-timeline .daw-console-card::before,
.daw-filmora-timeline .daw-toolbar-zone::before,
.daw-filmora-timeline .daw-smart-card::before {
  content: '';
  position: absolute;
  left: 0;
  top: 10px;
  bottom: 10px;
  width: 3px;
  border-radius: 999px;
  background: rgba(148,163,184,.34);
}
.daw-filmora-timeline .daw-console-transport::before { background: var(--daw-blue); }
.daw-filmora-timeline .daw-console-timing::before { background: var(--daw-amber); }
.daw-filmora-timeline .daw-console-project::before { background: rgba(226,232,240,.74); }
.daw-filmora-timeline .daw-zone-tools::before { background: var(--daw-blue); }
.daw-filmora-timeline .daw-zone-edit::before { background: var(--daw-cyan); }
.daw-filmora-timeline .daw-zone-clip::before { background: var(--daw-green); }
.daw-filmora-timeline .daw-smart-card-sections::before { background: var(--daw-amber); }
.daw-filmora-timeline .daw-smart-card-ai::before { background: var(--daw-violet); }
.daw-filmora-timeline .daw-console-transport {
  border-color: rgba(56, 189, 248, .23);
  background: linear-gradient(135deg, rgba(14, 165, 233, .13), rgba(5, 10, 24, .70));
}
.daw-filmora-timeline .daw-console-timing {
  border-color: rgba(251, 191, 36, .20);
  background: linear-gradient(135deg, rgba(120, 53, 15, .14), rgba(5, 10, 24, .70));
}
.daw-filmora-timeline .daw-zone-edit {
  border-color: rgba(34, 211, 238, .22);
  background: linear-gradient(135deg, rgba(8, 47, 73, .20), rgba(5, 10, 24, .70));
}
.daw-filmora-timeline .daw-zone-clip {
  border-color: rgba(52, 211, 153, .22);
  background: linear-gradient(135deg, rgba(6, 78, 59, .18), rgba(5, 10, 24, .70));
}
.daw-filmora-timeline .daw-zone-clip.is-disabled {
  border-color: rgba(148, 163, 184, .11);
  background: rgba(5, 10, 24, .56);
}
.daw-filmora-timeline .daw-kicker {
  display: block;
  margin: 0 0 8px;
  color: rgba(148, 163, 184, .82);
  font-size: .66rem;
  line-height: 1;
  font-weight: 950;
  letter-spacing: .12em;
  text-transform: uppercase;
}
.daw-filmora-timeline .daw-console-buttons,
.daw-filmora-timeline .daw-toolbar-buttons,
.daw-filmora-timeline .daw-clip-quick-actions,
.daw-filmora-timeline .daw-section-actions,
.daw-filmora-timeline .daw-ai-command-examples {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 7px;
}
.daw-filmora-timeline .daw-console-buttons-tight {
  gap: 6px;
}
.daw-filmora-timeline .daw-console-buttons button,
.daw-filmora-timeline .daw-toolbar-buttons button,
.daw-filmora-timeline .daw-clip-quick-actions button,
.daw-filmora-timeline .daw-section-actions button,
.daw-filmora-timeline .daw-ai-command-examples button,
.daw-filmora-timeline .daw-ai-command-form button {
  min-height: 34px;
  border-radius: 11px;
  border: 1px solid rgba(148, 163, 184, .17);
  background: rgba(15, 23, 42, .68);
  color: rgba(241, 245, 249, .90);
  font-size: .80rem;
  font-weight: 900;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.035);
}
.daw-filmora-timeline .daw-console-buttons button:hover:not(:disabled),
.daw-filmora-timeline .daw-toolbar-buttons button:hover:not(:disabled),
.daw-filmora-timeline .daw-clip-quick-actions button:hover:not(:disabled),
.daw-filmora-timeline .daw-section-actions button:hover:not(:disabled) {
  border-color: rgba(226, 232, 240, .30);
  background: rgba(30, 41, 59, .78);
}
.daw-filmora-timeline button:disabled,
.daw-filmora-timeline .daw-zone-clip.is-disabled button {
  opacity: .46;
  cursor: not-allowed;
}
.daw-filmora-timeline .daw-main-play,
.daw-filmora-timeline .daw-primary-edit,
.daw-filmora-timeline .daw-toolbar-primary-action {
  border-color: rgba(34, 211, 238, .52) !important;
  background: linear-gradient(135deg, rgba(14, 165, 233, .36), rgba(8, 47, 73, .72)) !important;
  color: #f0fdfa !important;
  box-shadow: 0 0 0 1px rgba(34, 211, 238, .10), 0 10px 22px rgba(14, 165, 233, .12) !important;
}
.daw-filmora-timeline .daw-zone-tools .active,
.daw-filmora-timeline .daw-toggle-action.active {
  border-color: rgba(56, 189, 248, .66) !important;
  background: linear-gradient(135deg, rgba(14, 165, 233, .34), rgba(30, 64, 175, .34)) !important;
  color: #ffffff !important;
}
.daw-filmora-timeline .daw-zone-clip.has-selection button:not(:disabled) {
  border-color: rgba(52, 211, 153, .30);
  background: rgba(6, 78, 59, .28);
}
.daw-filmora-timeline .daw-time-readout {
  min-height: 34px;
  display: inline-flex;
  align-items: center;
  border-radius: 11px;
  padding: 0 11px;
  color: #f8fafc;
  background: rgba(2, 6, 23, .55);
  border: 1px solid rgba(148, 163, 184, .13);
  font-size: .86rem;
  font-weight: 950;
}
.daw-filmora-timeline .daw-field-pill,
.daw-filmora-timeline .daw-zoom-pill,
.daw-filmora-timeline .daw-toolbar-check {
  min-height: 34px;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  border-radius: 11px;
  border: 1px solid rgba(148, 163, 184, .17);
  background: rgba(2, 6, 23, .52);
  padding: 5px 8px;
  color: rgba(226,232,240,.88);
  font-size: .78rem;
  font-weight: 900;
}
.daw-filmora-timeline .daw-field-pill input {
  width: 70px;
  min-height: 26px;
  padding: 3px 7px;
  border-radius: 8px;
  background: rgba(15,23,42,.72);
}
.daw-filmora-timeline .daw-select-pill {
  min-height: 34px;
  border-radius: 11px;
  border: 1px solid rgba(148, 163, 184, .17);
  background: rgba(2, 6, 23, .56);
  color: rgba(241,245,249,.92);
  padding: 6px 9px;
  font-weight: 900;
}
.daw-filmora-timeline .daw-zoom-pill strong {
  min-width: 64px;
  text-align: center;
  color: #fef3c7;
  font-size: .82rem;
}
.daw-filmora-timeline .daw-zoom-pill button {
  min-width: 30px;
  min-height: 28px;
  padding: 4px;
}
.daw-filmora-timeline .daw-smart-rail {
  display: grid;
  grid-template-columns: minmax(520px, 1fr) minmax(520px, 1fr);
  gap: 10px;
  padding: 10px;
  border-color: rgba(148, 163, 184, .13);
  background: rgba(3, 7, 18, .74);
}
.daw-filmora-timeline .daw-smart-card {
  display: grid;
  grid-template-columns: minmax(128px, .24fr) minmax(280px, 1fr) auto;
  align-items: center;
  gap: 10px;
  padding: 10px 10px 10px 14px;
}
.daw-filmora-timeline .daw-smart-card-sections {
  border-color: rgba(251, 191, 36, .20);
  background: linear-gradient(135deg, rgba(120, 53, 15, .13), rgba(5, 10, 24, .62));
}
.daw-filmora-timeline .daw-smart-card-ai {
  border-color: rgba(167, 139, 250, .24);
  background: linear-gradient(135deg, rgba(88, 28, 135, .18), rgba(5, 10, 24, .62));
}
.daw-filmora-timeline .daw-smart-head,
.daw-filmora-timeline .daw-ai-command-head {
  min-width: 0;
}
.daw-filmora-timeline .daw-smart-head strong,
.daw-filmora-timeline .daw-ai-command-head strong {
  display: block;
  color: #f8fafc;
  font-weight: 950;
  white-space: nowrap;
}
.daw-filmora-timeline .daw-section-resolver-main {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.daw-filmora-timeline .daw-section-select,
.daw-filmora-timeline .daw-ai-command-form input {
  min-height: 38px;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, .20);
  background: rgba(2, 6, 23, .62);
  color: #f8fafc;
  padding: 8px 10px;
  font-weight: 850;
}
.daw-filmora-timeline .daw-section-select {
  min-width: 230px;
  max-width: none;
}
.daw-filmora-timeline .daw-section-meta-pills {
  display: flex;
  gap: 5px;
  flex-wrap: wrap;
}
.daw-filmora-timeline .daw-section-meta-pills span,
.daw-filmora-timeline .daw-arr-inspector-pills span {
  min-height: 24px;
  border-radius: 999px;
  border: 1px solid rgba(148, 163, 184, .14);
  background: rgba(15, 23, 42, .58);
  color: rgba(226, 232, 240, .84);
  padding: 4px 8px;
  font-size: .72rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-section-actions {
  justify-content: flex-end;
  min-width: max-content;
}
.daw-filmora-timeline .daw-section-actions .primary-soft {
  border-color: rgba(251, 191, 36, .45) !important;
  background: rgba(120, 53, 15, .34) !important;
  color: #fef3c7 !important;
}
.daw-filmora-timeline .daw-ai-command-head {
  display: flex;
  align-items: center;
  gap: 9px;
}
.daw-filmora-timeline .daw-ai-command-head svg {
  color: var(--daw-violet);
}
.daw-filmora-timeline .daw-ai-command-form {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.daw-filmora-timeline .daw-ai-command-form input {
  flex: 1 1 280px;
  min-width: 0;
  border-color: rgba(167, 139, 250, .23);
}
.daw-filmora-timeline .daw-ai-command-form input:focus {
  outline: none;
  border-color: rgba(167, 139, 250, .62);
  box-shadow: 0 0 0 3px rgba(167, 139, 250, .13);
}
.daw-filmora-timeline .daw-ai-command-form button.primary {
  border-color: rgba(167, 139, 250, .48);
  background: linear-gradient(135deg, rgba(124, 58, 237, .56), rgba(88, 28, 135, .72));
  color: #fff;
}
.daw-filmora-timeline .daw-ai-command-examples {
  justify-content: flex-end;
}
.daw-filmora-timeline .daw-ai-command-examples button {
  min-height: 30px;
  max-width: 180px;
  padding: 6px 8px;
  border-color: rgba(167, 139, 250, .18);
  background: rgba(88, 28, 135, .18);
  color: rgba(245, 243, 255, .88);
  font-size: .72rem;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.daw-filmora-timeline .daw-ai-command-status {
  grid-column: 2 / 4;
  color: rgba(216, 180, 254, .92);
  font-size: .78rem;
  font-weight: 850;
}
.daw-filmora-timeline .daw-arr-editor {
  border-color: rgba(34, 211, 238, .18);
  background: linear-gradient(180deg, rgba(3, 7, 18, .88), rgba(2, 6, 23, .96));
}
.daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-streamlined {
  grid-template-columns: minmax(660px, 1.38fr) minmax(330px, .62fr);
  gap: 10px;
  padding: 10px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector,
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-preview-card {
  border-radius: 15px;
  background: rgba(5, 10, 24, .72);
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) {
  border-color: rgba(52, 211, 153, .22);
  background: linear-gradient(135deg, rgba(6, 78, 59, .12), rgba(5, 10, 24, .72));
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-preview-card {
  border-color: rgba(56, 189, 248, .18);
}
.daw-filmora-timeline .daw-arr-clip-fields {
  grid-template-columns: minmax(210px, 1.2fr) repeat(3, minmax(128px, .8fr));
  gap: 11px;
}
.daw-filmora-timeline .daw-arr-clip-fields label,
.daw-filmora-timeline .daw-arr-preview-fields label {
  color: rgba(203, 213, 225, .82);
  font-size: .78rem;
  font-weight: 900;
}
.daw-filmora-timeline .daw-arr-clip-fields input,
.daw-filmora-timeline .daw-arr-preview-fields input {
  border-color: rgba(148, 163, 184, .18);
  background: rgba(2, 6, 23, .62);
  color: #f8fafc;
}
.daw-filmora-timeline .danger,
.daw-filmora-timeline .danger.ghost {
  border-color: rgba(251, 113, 133, .34) !important;
  background: rgba(127, 29, 29, .22) !important;
  color: #fecdd3 !important;
}
@media (max-width: 1420px) {
  .daw-filmora-timeline .daw-console-top,
  .daw-filmora-timeline .daw-workbench-toolbar,
  .daw-filmora-timeline .daw-smart-rail {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-smart-card {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-section-actions,
  .daw-filmora-timeline .daw-ai-command-examples {
    justify-content: flex-start;
  }
}
@media (max-width: 760px) {
  .daw-filmora-timeline .daw-console-buttons,
  .daw-filmora-timeline .daw-toolbar-buttons,
  .daw-filmora-timeline .daw-clip-quick-actions,
  .daw-filmora-timeline .daw-section-resolver-main,
  .daw-filmora-timeline .daw-ai-command-form {
    display: grid;
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-section-select,
  .daw-filmora-timeline .daw-ai-command-form input {
    width: 100%;
  }
}

/* DAW Accessibility Readability: groessere, besser lesbare Bedienflaechen fuer schlechte Augen.
   Reiner lokaler Override am Ende der DAW-CSS-Kapselung; keine Logik-, app.css- oder globale UI-Aenderung. */
.daw-filmora-timeline {
  --daw-readable-text: .96rem;
  --daw-readable-small: .88rem;
  --daw-readable-tiny: .82rem;
  --daw-readable-button: .94rem;
  --daw-readable-input: .98rem;
}
.daw-filmora-timeline .daw-kicker {
  font-size: .76rem;
  letter-spacing: .105em;
  color: rgba(203, 213, 225, .90);
}
.daw-filmora-timeline .daw-console-card,
.daw-filmora-timeline .daw-toolbar-zone,
.daw-filmora-timeline .daw-smart-card,
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector,
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-preview-card {
  padding: 13px;
}
.daw-filmora-timeline .daw-console-buttons button,
.daw-filmora-timeline .daw-toolbar-buttons button,
.daw-filmora-timeline .daw-clip-quick-actions button,
.daw-filmora-timeline .daw-section-actions button,
.daw-filmora-timeline .daw-ai-command-examples button,
.daw-filmora-timeline .daw-ai-command-form button,
.daw-filmora-timeline .daw-arr-compact-actions button,
.daw-filmora-timeline .daw-command-footer button {
  min-height: 44px;
  padding: 10px 14px;
  font-size: var(--daw-readable-button);
  line-height: 1.18;
}
.daw-filmora-timeline .daw-console-buttons button svg,
.daw-filmora-timeline .daw-toolbar-buttons button svg,
.daw-filmora-timeline .daw-clip-quick-actions button svg,
.daw-filmora-timeline .daw-section-actions button svg,
.daw-filmora-timeline .daw-ai-command-form button svg,
.daw-filmora-timeline .daw-ai-command-examples button svg {
  width: 17px;
  height: 17px;
}
.daw-filmora-timeline .daw-main-play svg {
  width: 20px;
  height: 20px;
}
.daw-filmora-timeline .daw-ai-command-examples button {
  min-height: 40px;
  max-width: 240px;
  font-size: .86rem;
  padding-inline: 12px;
}
.daw-filmora-timeline .daw-field-pill,
.daw-filmora-timeline .daw-zoom-pill,
.daw-filmora-timeline .daw-toolbar-check,
.daw-filmora-timeline .daw-time-readout,
.daw-filmora-timeline .daw-select-pill,
.daw-filmora-timeline .daw-section-meta-pills span,
.daw-filmora-timeline .daw-arr-inspector-pills span {
  min-height: 40px;
  padding: 8px 12px;
  font-size: var(--daw-readable-small);
  line-height: 1.2;
}
.daw-filmora-timeline .daw-time-readout {
  font-size: 1rem;
  letter-spacing: .01em;
}
.daw-filmora-timeline .daw-field-pill input,
.daw-filmora-timeline .daw-section-select,
.daw-filmora-timeline .daw-ai-command-form input,
.daw-filmora-timeline .daw-arr-clip-fields input,
.daw-filmora-timeline .daw-arr-preview-fields input,
.daw-filmora-timeline .daw-select-pill {
  min-height: 44px;
  font-size: var(--daw-readable-input);
  padding: 10px 13px;
}
.daw-filmora-timeline .daw-smart-head strong,
.daw-filmora-timeline .daw-ai-command-head strong,
.daw-filmora-timeline .daw-arr-inspector-head strong,
.daw-filmora-timeline .daw-arr-preview-head strong,
.daw-filmora-timeline .daw-section-resolver-head strong {
  font-size: 1.04rem;
  line-height: 1.25;
}
.daw-filmora-timeline .daw-smart-head span:not(.daw-kicker),
.daw-filmora-timeline .daw-ai-command-head span:not(.daw-kicker),
.daw-filmora-timeline .daw-arr-inspector-head span,
.daw-filmora-timeline .daw-arr-preview-head span,
.daw-filmora-timeline .daw-section-resolver-head span,
.daw-filmora-timeline .daw-ai-command-status,
.daw-filmora-timeline .daw-ai-command-preview span {
  font-size: var(--daw-readable-small);
  line-height: 1.35;
}
.daw-filmora-timeline .daw-arr-clip-fields label,
.daw-filmora-timeline .daw-arr-preview-fields label {
  font-size: .90rem;
  gap: 8px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) .daw-arr-clip-fields label {
  font-size: .92rem;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) .daw-arr-clip-fields input {
  min-height: 48px;
  font-size: 1rem;
  padding: 11px 14px;
}
.daw-filmora-timeline .daw-arr-track-head strong {
  font-size: 1rem;
  letter-spacing: .02em;
}
.daw-filmora-timeline .daw-arr-track-head span {
  font-size: .86rem;
}
.daw-filmora-timeline .daw-arr-ruler {
  height: 54px;
}
.daw-filmora-timeline .daw-arr-ruler span {
  padding-top: 9px;
  padding-left: 9px;
  font-size: .88rem;
}
.daw-filmora-timeline .daw-arr-ruler span.minor {
  font-size: .82rem;
  color: rgba(226, 232, 240, .74);
}
.daw-filmora-timeline .daw-arr-sections {
  height: 38px;
}
.daw-filmora-timeline .daw-arr-section-chip {
  top: 6px;
  height: 26px;
  padding: 4px 10px;
  font-size: .80rem;
}
.daw-filmora-timeline .daw-arr-track-head.spacer {
  height: 132px;
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform .react-waveform-segments {
  height: 24px;
}
.daw-filmora-timeline .daw-arr-clip .clip-waveform .react-waveform-segment {
  height: 20px;
  line-height: 18px;
  padding: 1px 9px;
  font-size: .76rem;
}
.daw-filmora-timeline .daw-snap-guide-label {
  padding: 7px 11px;
  font-size: .86rem;
}
.daw-filmora-timeline .daw-command-header p,
.daw-filmora-timeline .daw-command-metric span {
  font-size: .84rem;
}
.daw-filmora-timeline .daw-command-header h3 {
  font-size: 1.32rem;
}
.daw-filmora-timeline .daw-command-summary,
.daw-filmora-timeline .daw-command-actions-list li,
.daw-filmora-timeline .daw-command-warning-list li,
.daw-filmora-timeline .daw-command-section-choice span {
  font-size: .94rem;
  line-height: 1.42;
}
@media (max-width: 1420px) {
  .daw-filmora-timeline .daw-smart-card {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-ai-command-examples button {
    max-width: none;
  }
}
@media (max-width: 760px) {
  .daw-filmora-timeline .daw-console-buttons button,
  .daw-filmora-timeline .daw-toolbar-buttons button,
  .daw-filmora-timeline .daw-clip-quick-actions button,
  .daw-filmora-timeline .daw-section-actions button,
  .daw-filmora-timeline .daw-ai-command-examples button,
  .daw-filmora-timeline .daw-ai-command-form button {
    width: 100%;
    justify-content: center;
  }
}

/* DAW Compact Accessibility Refactor: Professionalitaet durch Ordnung statt aufgeblasene Panels.
   Ziel: eine kompakte, gut lesbare DAW-Konsole mit klarer Prioritaet fuer die Timeline. */
.daw-filmora-timeline {
  --daw-readable-button: .88rem;
  --daw-readable-input: .92rem;
  --daw-readable-small: .82rem;
}
.daw-filmora-timeline .daw-control-surface.daw-ux-console {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px;
  border-radius: 16px;
  background: linear-gradient(180deg, rgba(6, 10, 22, .90), rgba(3, 7, 18, .86));
}
.daw-filmora-timeline .daw-console-row {
  gap: 8px;
  align-items: center;
}
.daw-filmora-timeline .daw-console-top {
  grid-template-columns: minmax(500px, 1.45fr) minmax(410px, 1fr) minmax(250px, .62fr);
}
.daw-filmora-timeline .daw-workbench-toolbar {
  grid-template-columns: minmax(310px, .70fr) minmax(520px, 1.10fr) minmax(420px, .92fr);
}
.daw-filmora-timeline .daw-console-card,
.daw-filmora-timeline .daw-toolbar-zone {
  display: flex;
  align-items: center;
  gap: 9px;
  min-height: 52px;
  padding: 8px 10px 8px 14px;
  border-radius: 13px;
  overflow: hidden;
}
.daw-filmora-timeline .daw-console-card::before,
.daw-filmora-timeline .daw-toolbar-zone::before {
  top: 8px;
  bottom: 8px;
  width: 3px;
}
.daw-filmora-timeline .daw-kicker {
  flex: 0 0 auto;
  margin: 0;
  min-width: 82px;
  color: rgba(203, 213, 225, .86);
  font-size: .70rem;
  letter-spacing: .10em;
  line-height: 1.1;
}
.daw-filmora-timeline .daw-console-buttons,
.daw-filmora-timeline .daw-toolbar-buttons,
.daw-filmora-timeline .daw-clip-quick-actions,
.daw-filmora-timeline .daw-section-actions,
.daw-filmora-timeline .daw-ai-command-form {
  gap: 6px;
}
.daw-filmora-timeline .daw-console-top .daw-console-buttons {
  flex-wrap: nowrap;
}
.daw-filmora-timeline .daw-console-buttons button,
.daw-filmora-timeline .daw-toolbar-buttons button,
.daw-filmora-timeline .daw-clip-quick-actions button,
.daw-filmora-timeline .daw-section-actions button,
.daw-filmora-timeline .daw-ai-command-form button,
.daw-filmora-timeline .daw-ai-command-examples button,
.daw-filmora-timeline .daw-arr-compact-actions button,
.daw-filmora-timeline .daw-command-footer button {
  min-height: 38px;
  padding: 8px 10px;
  border-radius: 10px;
  font-size: var(--daw-readable-button);
  line-height: 1.12;
  white-space: nowrap;
}
.daw-filmora-timeline .daw-console-buttons button svg,
.daw-filmora-timeline .daw-toolbar-buttons button svg,
.daw-filmora-timeline .daw-clip-quick-actions button svg,
.daw-filmora-timeline .daw-section-actions button svg,
.daw-filmora-timeline .daw-ai-command-form button svg,
.daw-filmora-timeline .daw-ai-command-examples button svg {
  width: 16px;
  height: 16px;
}
.daw-filmora-timeline .daw-main-play {
  min-width: 42px;
}
.daw-filmora-timeline .daw-time-readout,
.daw-filmora-timeline .daw-field-pill,
.daw-filmora-timeline .daw-zoom-pill,
.daw-filmora-timeline .daw-toolbar-check,
.daw-filmora-timeline .daw-select-pill {
  min-height: 38px;
  padding: 7px 9px;
  border-radius: 10px;
  font-size: .86rem;
}
.daw-filmora-timeline .daw-time-readout {
  min-width: 128px;
  justify-content: center;
  font-size: .92rem;
}
.daw-filmora-timeline .daw-field-pill {
  gap: 6px;
}
.daw-filmora-timeline .daw-field-pill input {
  width: 58px;
  min-height: 30px;
  padding: 4px 7px;
  font-size: .88rem;
}
.daw-filmora-timeline .daw-select-pill {
  max-width: 128px;
  font-size: .88rem;
}
.daw-filmora-timeline .daw-zoom-pill {
  min-width: 138px;
}
.daw-filmora-timeline .daw-zoom-pill strong {
  min-width: 58px;
  font-size: .84rem;
}
.daw-filmora-timeline .daw-zoom-pill button {
  min-width: 30px;
  min-height: 30px;
  padding: 4px;
}
.daw-filmora-timeline .daw-toolbar-buttons,
.daw-filmora-timeline .daw-clip-quick-actions {
  flex-wrap: wrap;
}
.daw-filmora-timeline .daw-zone-clip.is-disabled {
  opacity: .74;
}
.daw-filmora-timeline .daw-smart-rail {
  display: grid;
  grid-template-columns: minmax(560px, 1fr) minmax(560px, 1fr);
  gap: 8px;
  margin-top: 8px;
  padding: 8px;
  border-radius: 16px;
  background: rgba(3, 7, 18, .66);
}
.daw-filmora-timeline .daw-smart-card {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 8px;
  min-height: 58px;
  padding: 8px 10px 8px 14px;
  border-radius: 13px;
  overflow: visible;
}
.daw-filmora-timeline .daw-smart-head {
  min-width: 112px;
  gap: 1px;
}
.daw-filmora-timeline .daw-smart-head strong,
.daw-filmora-timeline .daw-ai-command-head strong {
  font-size: .94rem;
  line-height: 1.15;
}
.daw-filmora-timeline .daw-smart-head span:not(.daw-kicker),
.daw-filmora-timeline .daw-ai-command-head span:not(.daw-kicker) {
  font-size: .78rem;
}
.daw-filmora-timeline .daw-section-resolver-main {
  display: grid;
  grid-template-columns: minmax(220px, 1fr) auto;
  gap: 6px;
  min-width: 0;
  align-items: center;
}
.daw-filmora-timeline .daw-section-select,
.daw-filmora-timeline .daw-ai-command-form input,
.daw-filmora-timeline .daw-arr-clip-fields input,
.daw-filmora-timeline .daw-arr-preview-fields input {
  min-height: 38px;
  padding: 8px 10px;
  font-size: var(--daw-readable-input);
}
.daw-filmora-timeline .daw-section-meta-pills {
  min-width: 0;
  flex-wrap: nowrap;
  overflow: hidden;
}
.daw-filmora-timeline .daw-section-meta-pills span,
.daw-filmora-timeline .daw-arr-inspector-pills span {
  min-height: 32px;
  padding: 6px 9px;
  font-size: .78rem;
  white-space: nowrap;
}
.daw-filmora-timeline .daw-section-meta-pills span:nth-child(n+3) {
  display: none;
}
.daw-filmora-timeline .daw-section-actions {
  flex-wrap: nowrap;
  justify-content: flex-end;
}
.daw-filmora-timeline .daw-section-actions button {
  min-height: 36px;
  padding: 7px 9px;
  font-size: .84rem;
}
.daw-filmora-timeline .daw-smart-card-ai {
  grid-template-columns: auto minmax(280px, 1fr) auto auto;
}
.daw-filmora-timeline .daw-ai-command-head {
  min-width: 122px;
}
.daw-filmora-timeline .daw-ai-command-form input {
  min-width: 0;
}
.daw-filmora-timeline .daw-ai-command-form button.primary {
  min-width: 92px;
}
.daw-filmora-timeline .daw-ai-examples-drawer {
  position: relative;
  justify-self: end;
}
.daw-filmora-timeline .daw-ai-examples-drawer summary {
  min-height: 38px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 8px 11px;
  border-radius: 10px;
  border: 1px solid rgba(167, 139, 250, .24);
  background: rgba(88, 28, 135, .20);
  color: rgba(245, 243, 255, .92);
  font-size: .86rem;
  font-weight: 900;
  cursor: pointer;
  list-style: none;
}
.daw-filmora-timeline .daw-ai-examples-drawer summary::-webkit-details-marker {
  display: none;
}
.daw-filmora-timeline .daw-ai-examples-drawer[open] .daw-ai-command-examples {
  position: absolute;
  right: 0;
  top: calc(100% + 8px);
  z-index: 30;
  width: min(520px, 72vw);
  display: grid;
  grid-template-columns: 1fr;
  gap: 6px;
  padding: 8px;
  border: 1px solid rgba(167, 139, 250, .25);
  border-radius: 13px;
  background: rgba(10, 8, 28, .98);
  box-shadow: 0 18px 42px rgba(0,0,0,.42);
}
.daw-filmora-timeline .daw-ai-command-examples button {
  width: 100%;
  max-width: none;
  min-height: 36px;
  justify-content: flex-start;
  text-align: left;
  font-size: .84rem;
}
.daw-filmora-timeline .daw-ai-command-status {
  grid-column: 2 / 5;
  font-size: .82rem;
  padding-left: 2px;
}
.daw-filmora-timeline .daw-arr-editor {
  margin-top: 8px;
}
.daw-filmora-timeline .daw-arr-ruler {
  height: 46px;
}
.daw-filmora-timeline .daw-arr-ruler span {
  padding-top: 8px;
  padding-left: 8px;
  font-size: .82rem;
}
.daw-filmora-timeline .daw-arr-ruler span.minor {
  font-size: .76rem;
}
.daw-filmora-timeline .daw-arr-track-head.spacer {
  height: 112px;
}
.daw-filmora-timeline .daw-arr-section-chip {
  font-size: .76rem;
}
.daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-streamlined {
  grid-template-columns: minmax(620px, 1.25fr) minmax(320px, .75fr);
  gap: 8px;
  padding: 8px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector,
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-preview-card {
  padding: 10px;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector:not(.is-empty) .daw-arr-clip-fields input {
  min-height: 40px;
  font-size: .92rem;
  padding: 8px 10px;
}
.daw-filmora-timeline .daw-arr-clip-fields label,
.daw-filmora-timeline .daw-arr-preview-fields label {
  font-size: .82rem;
}
@media (max-width: 1500px) {
  .daw-filmora-timeline .daw-console-top,
  .daw-filmora-timeline .daw-workbench-toolbar,
  .daw-filmora-timeline .daw-smart-rail {
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-console-card,
  .daw-filmora-timeline .daw-toolbar-zone,
  .daw-filmora-timeline .daw-smart-card {
    overflow: visible;
  }
}
@media (max-width: 900px) {
  .daw-filmora-timeline .daw-console-card,
  .daw-filmora-timeline .daw-toolbar-zone,
  .daw-filmora-timeline .daw-smart-card,
  .daw-filmora-timeline .daw-smart-card-ai,
  .daw-filmora-timeline .daw-section-resolver-main {
    display: grid;
    grid-template-columns: 1fr;
  }
  .daw-filmora-timeline .daw-kicker,
  .daw-filmora-timeline .daw-smart-head,
  .daw-filmora-timeline .daw-ai-command-head {
    min-width: 0;
  }
  .daw-filmora-timeline .daw-console-top .daw-console-buttons,
  .daw-filmora-timeline .daw-section-actions {
    flex-wrap: wrap;
    justify-content: flex-start;
  }
}



/* DAW 10x Focus Refactor: finaler Layout-Audit-Pass.
   Ziel: professionelle Hierarchie, keine abgeschnittenen Gruppen, Timeline als Mittelpunkt,
   lesbare Controls ohne aufgeblasene Panels. Nur lokal auf /daw gescoped. */
.daw-filmora-timeline {
  --daw-focus-bg: rgba(2, 6, 23, .72);
  --daw-focus-panel: rgba(7, 12, 27, .72);
  --daw-focus-border: rgba(148, 163, 184, .16);
  --daw-control-h: 34px;
}
.daw-filmora-timeline .daw-control-surface.daw-ux-console {
  display: grid !important;
  grid-template-columns: 1fr !important;
  gap: 8px !important;
  padding: 8px !important;
  overflow: visible !important;
  border-radius: 16px !important;
  background: linear-gradient(180deg, rgba(5, 10, 24, .88), rgba(3, 7, 18, .80)) !important;
}
.daw-filmora-timeline .daw-console-row {
  display: grid !important;
  gap: 8px !important;
  width: 100% !important;
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-console-top {
  grid-template-columns: minmax(340px, 1.22fr) minmax(300px, .88fr) minmax(170px, .38fr) !important;
}
.daw-filmora-timeline .daw-workbench-toolbar {
  grid-template-columns: minmax(240px, .56fr) minmax(430px, 1fr) minmax(330px, .78fr) !important;
}
.daw-filmora-timeline .daw-console-card,
.daw-filmora-timeline .daw-toolbar-zone {
  min-width: 0 !important;
  min-height: 46px !important;
  padding: 7px 9px 7px 13px !important;
  gap: 8px !important;
  overflow: visible !important;
  border-radius: 12px !important;
  background: var(--daw-focus-panel) !important;
}
.daw-filmora-timeline .daw-console-card::before,
.daw-filmora-timeline .daw-toolbar-zone::before,
.daw-filmora-timeline .daw-smart-card::before {
  top: 7px !important;
  bottom: 7px !important;
  width: 3px !important;
  opacity: .95 !important;
}
.daw-filmora-timeline .daw-kicker {
  min-width: 58px !important;
  max-width: 74px !important;
  margin: 0 !important;
  font-size: .64rem !important;
  line-height: 1.05 !important;
  letter-spacing: .08em !important;
  color: rgba(203, 213, 225, .78) !important;
}
.daw-filmora-timeline .daw-console-buttons,
.daw-filmora-timeline .daw-toolbar-buttons,
.daw-filmora-timeline .daw-clip-quick-actions {
  gap: 6px !important;
  min-width: 0 !important;
  flex: 1 1 auto !important;
  flex-wrap: wrap !important;
}
.daw-filmora-timeline .daw-console-buttons button,
.daw-filmora-timeline .daw-toolbar-buttons button,
.daw-filmora-timeline .daw-clip-quick-actions button,
.daw-filmora-timeline .daw-section-actions button,
.daw-filmora-timeline .daw-ai-command-form button,
.daw-filmora-timeline .daw-ai-command-examples button {
  min-height: var(--daw-control-h) !important;
  padding: 7px 10px !important;
  border-radius: 10px !important;
  font-size: .82rem !important;
  line-height: 1.05 !important;
}
.daw-filmora-timeline .daw-main-play {
  min-width: 40px !important;
  width: 40px !important;
  padding-inline: 0 !important;
}
.daw-filmora-timeline .daw-time-readout {
  min-height: var(--daw-control-h) !important;
  padding: 0 10px !important;
  font-size: .88rem !important;
  white-space: nowrap !important;
}
.daw-filmora-timeline .daw-field-pill,
.daw-filmora-timeline .daw-select-pill,
.daw-filmora-timeline .daw-zoom-pill,
.daw-filmora-timeline .daw-toolbar-check {
  min-height: var(--daw-control-h) !important;
  padding: 5px 8px !important;
  border-radius: 10px !important;
  font-size: .80rem !important;
}
.daw-filmora-timeline .daw-console-project {
  z-index: 40 !important;
}
.daw-filmora-timeline .daw-console-project .daw-console-buttons {
  flex-wrap: nowrap !important;
}
.daw-filmora-timeline .daw-project-more {
  position: relative;
  display: inline-flex;
}
.daw-filmora-timeline .daw-project-more summary {
  list-style: none;
  cursor: pointer;
  min-height: var(--daw-control-h);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid rgba(148, 163, 184, .18);
  border-radius: 10px;
  padding: 7px 10px;
  background: rgba(15, 23, 42, .70);
  color: rgba(241,245,249,.92);
  font-size: .82rem;
  font-weight: 900;
}
.daw-filmora-timeline .daw-project-more summary::-webkit-details-marker { display: none; }
.daw-filmora-timeline .daw-project-more-panel {
  position: absolute;
  right: 0;
  top: calc(100% + 8px);
  z-index: 90;
  min-width: 148px;
  display: grid;
  gap: 6px;
  padding: 8px;
  border: 1px solid rgba(148, 163, 184, .22);
  border-radius: 12px;
  background: rgba(2, 6, 23, .98);
  box-shadow: 0 18px 44px rgba(0,0,0,.45);
}
.daw-filmora-timeline .daw-project-more-panel button {
  justify-content: flex-start;
  width: 100%;
}
.daw-filmora-timeline .daw-zone-edit .daw-toolbar-buttons {
  flex-wrap: wrap !important;
}
.daw-filmora-timeline .daw-zone-edit .daw-primary-edit,
.daw-filmora-timeline .daw-zone-edit button:nth-of-type(4) {
  order: -2;
}
.daw-filmora-timeline .daw-zone-edit button:nth-of-type(2),
.daw-filmora-timeline .daw-zone-edit .daw-toolbar-check {
  order: 3;
}
.daw-filmora-timeline .daw-zone-edit button:nth-of-type(3) {
  order: 4;
}
.daw-filmora-timeline .daw-clip-delete-action {
  border-color: rgba(251, 113, 133, .34) !important;
  background: rgba(127, 29, 29, .28) !important;
  color: #fecdd3 !important;
}
.daw-filmora-timeline .daw-smart-rail {
  display: grid !important;
  grid-template-columns: minmax(0, 1fr) minmax(0, .92fr) !important;
  gap: 8px !important;
  padding: 8px !important;
  align-items: stretch !important;
  background: rgba(3, 7, 18, .60) !important;
}
.daw-filmora-timeline .daw-smart-card {
  min-height: 48px !important;
  padding: 7px 9px 7px 13px !important;
  gap: 7px !important;
  grid-template-columns: auto minmax(0, 1fr) auto !important;
  border-radius: 12px !important;
  overflow: visible !important;
}
.daw-filmora-timeline .daw-smart-head {
  min-width: 86px !important;
}
.daw-filmora-timeline .daw-smart-head strong,
.daw-filmora-timeline .daw-ai-command-head strong {
  font-size: .86rem !important;
  line-height: 1.05 !important;
}
.daw-filmora-timeline .daw-section-resolver-main {
  grid-template-columns: minmax(190px, 1fr) auto !important;
  gap: 6px !important;
}
.daw-filmora-timeline .daw-section-select,
.daw-filmora-timeline .daw-ai-command-form input {
  min-height: 36px !important;
  height: 36px !important;
  padding: 7px 10px !important;
  font-size: .88rem !important;
}
.daw-filmora-timeline .daw-section-meta-pills span:nth-child(n+2) {
  display: none !important;
}
.daw-filmora-timeline .daw-section-actions {
  flex-wrap: nowrap !important;
  gap: 5px !important;
}
.daw-filmora-timeline .daw-ai-command-head {
  min-width: 112px !important;
}
.daw-filmora-timeline .daw-ai-command-form {
  display: grid !important;
  grid-template-columns: minmax(0, 1fr) auto !important;
  gap: 6px !important;
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-ai-examples-drawer {
  position: relative;
}
.daw-filmora-timeline .daw-ai-examples-drawer summary {
  min-height: 36px !important;
  padding: 8px 10px !important;
  border-radius: 10px !important;
  background: rgba(76, 29, 149, .44) !important;
}
.daw-filmora-timeline .daw-ai-examples-drawer[open] .daw-ai-command-examples {
  position: absolute;
  right: 0;
  top: calc(100% + 8px);
  z-index: 80;
  min-width: min(520px, 78vw);
  padding: 8px;
  border: 1px solid rgba(167, 139, 250, .28);
  border-radius: 12px;
  background: rgba(17, 24, 39, .98);
  box-shadow: 0 18px 48px rgba(0,0,0,.42);
}
.daw-filmora-timeline .daw-arr-editor {
  margin-top: 8px !important;
}
.daw-filmora-timeline .daw-arr-timeline-canvas {
  min-height: 430px !important;
}
.daw-filmora-timeline .daw-arr-ruler {
  height: 46px !important;
}
.daw-filmora-timeline .daw-arr-ruler span {
  font-size: .78rem !important;
  padding-top: 8px !important;
}
.daw-filmora-timeline .daw-arr-track-head {
  min-height: 94px !important;
}
.daw-filmora-timeline .daw-arr-track-head strong {
  font-size: .92rem !important;
}
.daw-filmora-timeline .daw-arr-section-chip {
  font-size: .76rem !important;
  opacity: .88 !important;
}
.daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-streamlined {
  grid-template-columns: minmax(0, 1.35fr) minmax(320px, .65fr) !important;
  gap: 8px !important;
  margin-top: 8px !important;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-inspector,
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-preview-card {
  min-height: 136px !important;
  padding: 12px !important;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-fields {
  grid-template-columns: minmax(220px, 1.2fr) repeat(3, minmax(120px, .7fr)) !important;
  gap: 8px !important;
}
.daw-filmora-timeline .daw-arr-bottom-streamlined .daw-arr-clip-fields input,
.daw-filmora-timeline .daw-arr-preview-fields input {
  min-height: 38px !important;
  font-size: .92rem !important;
}
@media (max-width: 1280px) {
  .daw-filmora-timeline .daw-console-top,
  .daw-filmora-timeline .daw-workbench-toolbar,
  .daw-filmora-timeline .daw-smart-rail,
  .daw-filmora-timeline .daw-arr-bottom.daw-arr-bottom-streamlined {
    grid-template-columns: 1fr !important;
  }
  .daw-filmora-timeline .daw-console-card,
  .daw-filmora-timeline .daw-toolbar-zone,
  .daw-filmora-timeline .daw-smart-card {
    align-items: flex-start !important;
  }
  .daw-filmora-timeline .daw-kicker {
    min-width: 76px !important;
  }
}




/* DAW general song-part + AI chat correction: removes hook-centric UX and gives the AI area a readable history. */
.daw-filmora-timeline .daw-smart-rail-general {
  grid-template-columns: minmax(420px, 0.92fr) minmax(520px, 1.08fr) !important;
  align-items: stretch !important;
}
.daw-filmora-timeline .daw-smart-card-sections .daw-smart-head strong,
.daw-filmora-timeline .daw-smart-card-ai .daw-ai-command-head strong {
  letter-spacing: -0.01em !important;
}
.daw-filmora-timeline .daw-smart-card-sections .daw-section-select {
  min-width: 260px !important;
  max-width: min(420px, 42vw) !important;
}
.daw-filmora-timeline .daw-section-actions button {
  white-space: nowrap !important;
}
.daw-filmora-timeline .daw-ai-chat-card {
  display: grid !important;
  grid-template-columns: minmax(360px, 1fr) minmax(260px, 0.72fr) !important;
  gap: 10px !important;
  align-items: stretch !important;
}
.daw-filmora-timeline .daw-ai-chat-main {
  display: grid !important;
  grid-template-columns: auto minmax(280px, 1fr) !important;
  gap: 10px !important;
  align-items: center !important;
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-ai-chat-card .daw-ai-command-form {
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-ai-chat-side {
  display: grid !important;
  grid-template-columns: minmax(170px, 1fr) auto !important;
  gap: 8px !important;
  align-items: stretch !important;
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-ai-chat-log {
  max-height: 92px !important;
  overflow: auto !important;
  border: 1px solid rgba(167, 139, 250, 0.22) !important;
  border-radius: 14px !important;
  background: rgba(13, 10, 28, 0.62) !important;
  padding: 6px !important;
}
.daw-filmora-timeline .daw-ai-chat-message {
  display: grid !important;
  grid-template-columns: 28px 1fr !important;
  gap: 6px !important;
  align-items: start !important;
  padding: 4px 5px !important;
  border-radius: 10px !important;
}
.daw-filmora-timeline .daw-ai-chat-message span {
  font-size: 10px !important;
  font-weight: 900 !important;
  color: rgba(216, 203, 255, 0.7) !important;
  text-transform: uppercase !important;
}
.daw-filmora-timeline .daw-ai-chat-message p {
  margin: 0 !important;
  font-size: 11px !important;
  line-height: 1.28 !important;
  color: rgba(246, 242, 255, 0.88) !important;
}
.daw-filmora-timeline .daw-ai-chat-message.user {
  background: rgba(15, 23, 42, 0.58) !important;
}
.daw-filmora-timeline .daw-ai-chat-message.assistant {
  background: rgba(109, 40, 217, 0.18) !important;
}
.daw-filmora-timeline .daw-ai-chat-message.warning {
  background: rgba(146, 64, 14, 0.22) !important;
}
.daw-filmora-timeline .daw-ai-chat-empty {
  font-size: 11px !important;
  line-height: 1.3 !important;
  color: rgba(221, 214, 254, 0.68) !important;
  padding: 6px !important;
}
.daw-filmora-timeline .daw-ai-chat-side .daw-ai-examples-drawer {
  align-self: start !important;
  position: relative !important;
}
.daw-filmora-timeline .daw-ai-chat-side .daw-ai-command-examples {
  right: 0 !important;
  min-width: 300px !important;
}
@media (max-width: 1380px) {
  .daw-filmora-timeline .daw-smart-rail-general,
  .daw-filmora-timeline .daw-ai-chat-card {
    grid-template-columns: 1fr !important;
  }
  .daw-filmora-timeline .daw-ai-chat-side {
    grid-template-columns: 1fr auto !important;
  }
}
@media (max-width: 980px) {
  .daw-filmora-timeline .daw-ai-chat-main,
  .daw-filmora-timeline .daw-ai-chat-side {
    grid-template-columns: 1fr !important;
  }
  .daw-filmora-timeline .daw-smart-card-sections .daw-section-select {
    max-width: 100% !important;
  }
}

/* DAW Final Cleanup 2026-07-08: sichtbare Flaeche konsequent auf Transport, Werkzeuge, Timeline und kompakte Ausgabe reduzieren. */
.daw-filmora-timeline.daw-clean-workspace {
  gap: 10px !important;
  padding-bottom: 18px !important;
}
.daw-filmora-timeline.daw-clean-workspace .panel {
  box-sizing: border-box !important;
  min-width: 0 !important;
}
.daw-filmora-timeline.daw-clean-workspace button,
.daw-filmora-timeline.daw-clean-workspace .button,
.daw-filmora-timeline.daw-clean-workspace select,
.daw-filmora-timeline.daw-clean-workspace input {
  max-width: 100% !important;
  box-sizing: border-box !important;
}
.daw-filmora-timeline .daw-projectbar {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  gap: 12px !important;
  padding: 10px 12px !important;
  overflow: visible !important;
}
.daw-filmora-timeline .daw-projectbar-left {
  min-width: 0 !important;
  flex: 1 1 420px !important;
}
.daw-filmora-timeline .daw-project-title {
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-project-title strong,
.daw-filmora-timeline .daw-project-title small {
  display: block !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
  white-space: nowrap !important;
}
.daw-filmora-timeline .daw-projectbar-actions-clean {
  flex: 0 0 auto !important;
  display: flex !important;
  justify-content: flex-end !important;
}
.daw-filmora-timeline .daw-clean-control {
  display: grid !important;
  grid-template-columns: minmax(360px, auto) minmax(280px, 1fr) !important;
  gap: 9px 12px !important;
  align-items: center !important;
  padding: 10px !important;
  overflow: visible !important;
}
.daw-filmora-timeline .daw-clean-transport,
.daw-filmora-timeline .daw-clean-tools,
.daw-filmora-timeline .daw-clean-edit,
.daw-filmora-timeline .daw-clean-project {
  min-width: 0 !important;
  display: flex !important;
  align-items: center !important;
  gap: 7px !important;
  flex-wrap: wrap !important;
  padding: 0 !important;
}
.daw-filmora-timeline .daw-clean-tools,
.daw-filmora-timeline .daw-clean-project {
  justify-content: flex-end !important;
}
.daw-filmora-timeline .daw-clean-control button,
.daw-filmora-timeline .daw-clean-control .button,
.daw-filmora-timeline .daw-clean-control select,
.daw-filmora-timeline .daw-clean-control input,
.daw-filmora-timeline .daw-projectbar-actions-clean button {
  min-height: 34px !important;
  height: 34px !important;
  padding: 7px 10px !important;
  font-size: .82rem !important;
  line-height: 1 !important;
}
.daw-filmora-timeline .daw-clean-control .daw-main-play {
  width: 42px !important;
  height: 42px !important;
  min-height: 42px !important;
  padding: 0 !important;
  border-radius: 14px !important;
}
.daw-filmora-timeline .daw-clean-control .daw-time-readout {
  min-width: 136px !important;
  text-align: center !important;
  font-variant-numeric: tabular-nums !important;
  color: #e2e8f0 !important;
}
.daw-filmora-timeline .daw-clean-control .daw-field-pill,
.daw-filmora-timeline .daw-clean-control .daw-format-select,
.daw-filmora-timeline .daw-clean-control .daw-toolbar-check,
.daw-filmora-timeline .daw-clean-control .daw-zoom-pill {
  min-height: 34px !important;
  height: 34px !important;
  display: inline-flex !important;
  align-items: center !important;
  gap: 6px !important;
  padding: 5px 8px !important;
  border-radius: 12px !important;
}
.daw-filmora-timeline .daw-clean-control .daw-field-pill input {
  width: 62px !important;
}
.daw-filmora-timeline .daw-clean-control .daw-format-select select,
.daw-filmora-timeline .daw-clean-control .daw-select-pill {
  width: auto !important;
  min-width: 78px !important;
}
.daw-filmora-timeline .daw-clean-more {
  position: relative !important;
}
.daw-filmora-timeline .daw-clean-more > summary {
  min-height: 34px !important;
  height: 34px !important;
  display: inline-flex !important;
  align-items: center !important;
  padding: 7px 10px !important;
  border-radius: 12px !important;
  cursor: pointer !important;
  background: rgba(15, 23, 42, .78) !important;
  border: 1px solid rgba(148, 163, 184, .16) !important;
}
.daw-filmora-timeline .daw-clean-more .daw-project-more-panel {
  right: 0 !important;
  left: auto !important;
  top: calc(100% + 8px) !important;
  min-width: 210px !important;
  z-index: 30 !important;
}
.daw-filmora-timeline .daw-advanced-drawer {
  padding: 0 !important;
  overflow: visible !important;
  border: 1px solid rgba(148, 163, 184, .12) !important;
}
.daw-filmora-timeline .daw-advanced-drawer > summary {
  min-height: 42px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  gap: 12px !important;
  padding: 10px 13px !important;
  cursor: pointer !important;
  color: rgba(226, 232, 240, .92) !important;
  list-style: none !important;
}
.daw-filmora-timeline .daw-advanced-drawer > summary::-webkit-details-marker {
  display: none !important;
}
.daw-filmora-timeline .daw-advanced-drawer > summary strong {
  font-size: .9rem !important;
}
.daw-filmora-timeline .daw-advanced-drawer > summary span {
  color: rgba(148, 163, 184, .92) !important;
  font-size: .78rem !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
  white-space: nowrap !important;
}
.daw-filmora-timeline .daw-advanced-drawer:not([open]) {
  background: rgba(8, 13, 27, .62) !important;
}
.daw-filmora-timeline .daw-advanced-content {
  display: grid !important;
  grid-template-columns: minmax(280px, .75fr) minmax(360px, 1.15fr) minmax(260px, .55fr) !important;
  gap: 10px !important;
  padding: 0 12px 12px !important;
  align-items: stretch !important;
}
.daw-filmora-timeline .daw-advanced-content .daw-smart-card {
  min-width: 0 !important;
  padding: 11px !important;
}
.daw-filmora-timeline .daw-advanced-content .daw-section-actions,
.daw-filmora-timeline .daw-advanced-content .daw-clip-quick-actions {
  display: flex !important;
  flex-wrap: wrap !important;
  gap: 7px !important;
}
.daw-filmora-timeline .daw-advanced-content .daw-section-actions button,
.daw-filmora-timeline .daw-advanced-content .daw-clip-quick-actions button,
.daw-filmora-timeline .daw-advanced-content .daw-ai-command-form button {
  min-height: 34px !important;
  height: 34px !important;
  padding: 7px 9px !important;
  font-size: .78rem !important;
}
.daw-filmora-timeline .daw-advanced-content .daw-ai-chat-card {
  grid-template-columns: minmax(240px, 1fr) minmax(220px, .72fr) !important;
}
.daw-filmora-timeline .daw-advanced-content .daw-ai-chat-log {
  max-height: 78px !important;
}
.daw-filmora-timeline .daw-arr-editor {
  display: grid !important;
  grid-template-columns: 92px minmax(0, 1fr) !important;
  gap: 0 !important;
  min-height: 500px !important;
  overflow: hidden !important;
  padding: 0 !important;
}
.daw-filmora-timeline .daw-arr-sidebar {
  width: auto !important;
  min-width: 0 !important;
  overflow: hidden !important;
}
.daw-filmora-timeline .daw-arr-track-head {
  padding: 10px 8px !important;
}
.daw-filmora-timeline .daw-arr-track-head strong,
.daw-filmora-timeline .daw-arr-track-head span {
  overflow: hidden !important;
  text-overflow: ellipsis !important;
  white-space: nowrap !important;
}
.daw-filmora-timeline .daw-arr-timeline {
  min-width: 0 !important;
  width: 100% !important;
  overflow-x: auto !important;
  overflow-y: hidden !important;
}
.daw-filmora-timeline .daw-arr-timeline-canvas {
  min-height: 500px !important;
}
.daw-filmora-timeline .daw-arr-ruler {
  height: 42px !important;
}
.daw-filmora-timeline .daw-arr-markers {
  height: 34px !important;
  top: 42px !important;
}
.daw-filmora-timeline .daw-arr-track-head.spacer {
  height: 76px !important;
}
.daw-filmora-timeline .daw-arr-track-row {
  height: 136px !important;
  min-height: 136px !important;
}
.daw-filmora-timeline .daw-arr-clip {
  top: 16px !important;
  bottom: 16px !important;
  min-height: 98px !important;
}
.daw-filmora-timeline .daw-arr-sections,
.daw-filmora-timeline .daw-section-resolver-strip,
.daw-filmora-timeline .daw-smart-rail-general {
  display: none !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean {
  display: grid !important;
  grid-template-columns: minmax(0, 1fr) minmax(280px, 360px) !important;
  gap: 10px !important;
  align-items: stretch !important;
  padding: 0 !important;
  overflow: hidden !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-clip-inspector,
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-preview-card {
  min-width: 0 !important;
  padding: 11px !important;
  overflow: hidden !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-clip-fields {
  display: grid !important;
  grid-template-columns: minmax(170px, 1.2fr) repeat(3, minmax(92px, .7fr)) !important;
  gap: 8px !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-clip-fields label {
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-clip-fields input,
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-preview-fields input {
  min-height: 32px !important;
  height: 32px !important;
  padding: 6px 8px !important;
  font-size: .82rem !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-empty-inspector {
  min-height: 78px !important;
  display: grid !important;
  place-content: center !important;
  gap: 4px !important;
  text-align: center !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-empty-inspector span {
  color: rgba(148, 163, 184, .85) !important;
  font-size: .78rem !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean .daw-arr-preview-fields {
  display: grid !important;
  grid-template-columns: 1fr !important;
  gap: 8px !important;
}
.daw-filmora-timeline .daw-arr-bottom-clean audio {
  width: 100% !important;
  max-width: 100% !important;
  height: 34px !important;
}
@media (max-width: 1380px) {
  .daw-filmora-timeline .daw-clean-control,
  .daw-filmora-timeline .daw-advanced-content,
  .daw-filmora-timeline .daw-arr-bottom-clean {
    grid-template-columns: 1fr !important;
  }
  .daw-filmora-timeline .daw-clean-tools,
  .daw-filmora-timeline .daw-clean-project {
    justify-content: flex-start !important;
  }
}
@media (max-width: 900px) {
  .daw-filmora-timeline .daw-projectbar,
  .daw-filmora-timeline .daw-clean-transport,
  .daw-filmora-timeline .daw-clean-tools,
  .daw-filmora-timeline .daw-clean-edit,
  .daw-filmora-timeline .daw-clean-project {
    align-items: stretch !important;
  }
  .daw-filmora-timeline .daw-clean-control button,
  .daw-filmora-timeline .daw-clean-control .button,
  .daw-filmora-timeline .daw-clean-control select,
  .daw-filmora-timeline .daw-clean-control input,
  .daw-filmora-timeline .daw-projectbar-actions-clean button {
    flex: 1 1 auto !important;
  }
  .daw-filmora-timeline .daw-arr-editor {
    grid-template-columns: 1fr !important;
  }
  .daw-filmora-timeline .daw-arr-sidebar {
    display: none !important;
  }
}

/* DAW final cleanup: no visible structure/section helper, no waveform section badges, local AI only. */
body.daw-page-active .global-ai-toggle {
  display: none !important;
}
.daw-filmora-timeline .daw-advanced-drawer,
.daw-filmora-timeline .daw-smart-rail,
.daw-filmora-timeline .daw-smart-rail-general,
.daw-filmora-timeline .daw-smart-card-sections,
.daw-filmora-timeline .daw-section-resolver,
.daw-filmora-timeline .daw-section-resolver-main,
.daw-filmora-timeline .daw-section-actions {
  display: none !important;
}
.daw-filmora-timeline .daw-arr-clip .react-waveform-segments,
.daw-filmora-timeline .daw-arr-editor .react-waveform-segments {
  display: none !important;
}
.daw-filmora-timeline .daw-clean-control {
  grid-template-columns: 1fr !important;
  gap: 8px !important;
  overflow: hidden !important;
}
.daw-filmora-timeline .daw-clean-transport,
.daw-filmora-timeline .daw-clean-tools,
.daw-filmora-timeline .daw-clean-edit,
.daw-filmora-timeline .daw-clean-project {
  justify-content: flex-start !important;
  max-width: 100% !important;
}
.daw-filmora-timeline .daw-ai-toolbar-button {
  background: linear-gradient(135deg, rgba(124, 58, 237, .92), rgba(6, 182, 212, .72)) !important;
  border-color: rgba(196, 181, 253, .45) !important;
  color: #fff !important;
  font-weight: 850 !important;
}
.daw-filmora-timeline .daw-ai-toolbar-button.active {
  box-shadow: 0 0 0 1px rgba(34, 211, 238, .45), 0 0 22px rgba(124, 58, 237, .28) !important;
}
.daw-filmora-timeline .daw-ai-drawer {
  display: grid !important;
  grid-template-columns: minmax(220px, .38fr) minmax(360px, 1fr) minmax(260px, .52fr) !important;
  gap: 12px !important;
  align-items: start !important;
  padding: 12px !important;
  overflow: hidden !important;
  border: 1px solid rgba(124, 58, 237, .28) !important;
  background: linear-gradient(135deg, rgba(15, 23, 42, .96), rgba(30, 27, 75, .78)) !important;
}
.daw-filmora-timeline .daw-ai-drawer-head {
  min-width: 0 !important;
  display: flex !important;
  align-items: flex-start !important;
  justify-content: space-between !important;
  gap: 10px !important;
}
.daw-filmora-timeline .daw-ai-drawer-head > div {
  min-width: 0 !important;
}
.daw-filmora-timeline .daw-ai-drawer-head strong,
.daw-filmora-timeline .daw-ai-drawer-head small {
  display: block !important;
}
.daw-filmora-timeline .daw-ai-drawer-head small {
  margin-top: 4px !important;
  color: rgba(203, 213, 225, .78) !important;
  line-height: 1.35 !important;
}
.daw-filmora-timeline .daw-ai-drawer-head button {
  flex: 0 0 auto !important;
  min-height: 32px !important;
}
.daw-filmora-timeline .daw-ai-drawer-form {
  min-width: 0 !important;
  display: grid !important;
  grid-template-columns: minmax(0, 1fr) auto !important;
  gap: 8px !important;
}
.daw-filmora-timeline .daw-ai-drawer-form input {
  width: 100% !important;
  min-width: 0 !important;
  height: 38px !important;
}
.daw-filmora-timeline .daw-ai-drawer-form button {
  height: 38px !important;
  white-space: nowrap !important;
}
.daw-filmora-timeline .daw-ai-drawer-meta {
  min-width: 0 !important;
  display: grid !important;
  grid-template-columns: 1fr !important;
  gap: 8px !important;
}
.daw-filmora-timeline .daw-ai-drawer .daw-ai-chat-log {
  max-height: 92px !important;
  overflow: auto !important;
}
.daw-filmora-timeline .daw-ai-drawer .daw-ai-command-examples {
  display: flex !important;
  flex-wrap: wrap !important;
  gap: 6px !important;
  margin-top: 8px !important;
}
.daw-filmora-timeline .daw-ai-drawer .daw-ai-command-examples button {
  min-height: 30px !important;
  font-size: .76rem !important;
  padding: 6px 8px !important;
}
.daw-filmora-timeline .daw-arr-editor {
  margin-top: 0 !important;
}
.daw-filmora-timeline .daw-arr-clip .react-waveform {
  padding-top: 0 !important;
}
@media (max-width: 1180px) {
  .daw-filmora-timeline .daw-ai-drawer {
    grid-template-columns: 1fr !important;
  }
  .daw-filmora-timeline .daw-ai-drawer-form {
    grid-template-columns: 1fr !important;
  }
}

/* DAW Layout Refinement 2026-07-08: kompakter Kopfbereich plus Abschnittsbalken direkt im Clip. */
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control {
  grid-template-columns: minmax(440px, auto) minmax(0, 1fr) !important;
  grid-template-areas:
    "transport project"
    "tools edit" !important;
  align-items: stretch !important;
  gap: 8px !important;
  padding: 10px !important;
  overflow: visible !important;
  background:
    radial-gradient(circle at 12% 0%, rgba(56, 189, 248, .10), transparent 34%),
    radial-gradient(circle at 92% 0%, rgba(124, 58, 237, .10), transparent 36%),
    linear-gradient(180deg, rgba(8, 13, 27, .90), rgba(3, 7, 18, .88)) !important;
  border-color: rgba(56, 189, 248, .16) !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-transport { grid-area: transport !important; }
.daw-filmora-timeline.daw-clean-workspace .daw-clean-tools { grid-area: tools !important; }
.daw-filmora-timeline.daw-clean-workspace .daw-clean-edit { grid-area: edit !important; }
.daw-filmora-timeline.daw-clean-workspace .daw-clean-project { grid-area: project !important; }
.daw-filmora-timeline.daw-clean-workspace .daw-clean-transport,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-tools,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-edit,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-project {
  min-width: 0 !important;
  min-height: 46px !important;
  padding: 6px !important;
  border: 1px solid rgba(148, 163, 184, .12) !important;
  border-radius: 14px !important;
  background: rgba(2, 6, 23, .38) !important;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .035) !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-project,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-edit {
  justify-content: flex-end !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-tools {
  justify-content: flex-start !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control button,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .button,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control select,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control input {
  min-height: 32px !important;
  height: 32px !important;
  padding: 6px 9px !important;
  font-size: .80rem !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-main-play {
  width: 40px !important;
  height: 40px !important;
  min-height: 40px !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-time-readout {
  min-width: 140px !important;
  background: rgba(2, 6, 23, .72) !important;
  border-color: rgba(56, 189, 248, .18) !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-field-pill,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-format-select,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-toolbar-check,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-zoom-pill {
  min-height: 32px !important;
  height: 32px !important;
  padding: 4px 7px !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-arr-sections,
.daw-filmora-timeline.daw-clean-workspace .daw-section-resolver-strip,
.daw-filmora-timeline.daw-clean-workspace .daw-smart-rail-general,
.daw-filmora-timeline.daw-clean-workspace .daw-advanced-drawer,
.daw-filmora-timeline.daw-clean-workspace .daw-smart-card-sections,
.daw-filmora-timeline.daw-clean-workspace .daw-section-actions {
  display: none !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-arr-editor .daw-arr-clip .clip-waveform .react-waveform-segments {
  display: block !important;
  position: absolute !important;
  inset: 6px 10px auto 10px !important;
  height: 22px !important;
  z-index: 8 !important;
  pointer-events: none !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-arr-editor .daw-arr-clip .clip-waveform .react-waveform-segment {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  height: 20px !important;
  min-width: 38px !important;
  max-width: 100% !important;
  top: 0 !important;
  padding: 0 8px !important;
  border-radius: 999px !important;
  border: 1px solid rgba(255, 255, 255, .26) !important;
  color: rgba(255, 255, 255, .96) !important;
  font-size: .72rem !important;
  line-height: 1 !important;
  font-weight: 950 !important;
  letter-spacing: .01em !important;
  text-shadow: 0 1px 2px rgba(0, 0, 0, .45) !important;
  box-shadow: 0 6px 14px rgba(2, 6, 23, .22) !important;
  opacity: .96 !important;
  pointer-events: none !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-arr-editor .daw-arr-clip .clip-waveform .react-waveform-bars {
  padding-top: 24px !important;
}
@media (max-width: 1500px) {
  .daw-filmora-timeline.daw-clean-workspace .daw-clean-control {
    grid-template-columns: 1fr !important;
    grid-template-areas:
      "transport"
      "tools"
      "edit"
      "project" !important;
  }
  .daw-filmora-timeline.daw-clean-workspace .daw-clean-project,
  .daw-filmora-timeline.daw-clean-workspace .daw-clean-edit {
    justify-content: flex-start !important;
  }
}




/* DAW Timeline-KI 2026-07-08: KI direkt am Clip statt als großer Block über der Timeline. */
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control {
  grid-template-columns: minmax(430px, .92fr) minmax(520px, 1.28fr) !important;
  grid-template-areas:
    "transport project"
    "tools edit" !important;
  gap: 7px !important;
  padding: 8px !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-transport,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-tools,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-edit,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-project {
  min-height: 38px !important;
  padding: 5px !important;
  border-radius: 12px !important;
  align-items: center !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-transport,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-tools {
  justify-content: flex-start !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-project,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-edit {
  justify-content: flex-end !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control button,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control select,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control input,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-format-select,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-field-pill,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-toolbar-check,
.daw-filmora-timeline.daw-clean-workspace .daw-clean-control .daw-zoom-pill {
  height: 30px !important;
  min-height: 30px !important;
}
.daw-filmora-timeline.daw-clean-workspace .daw-ai-drawer {
  display: none !important;
}
.daw-filmora-timeline .daw-clip-ai-button {
  position: absolute;
  right: 10px;
  top: 8px;
  z-index: 18;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 24px;
  min-height: 24px;
  padding: 3px 7px;
  border-radius: 999px;
  border: 1px solid rgba(167, 139, 250, .55);
  background: rgba(49, 46, 129, .86);
  color: #eef2ff;
  font-size: .68rem;
  font-weight: 900;
  letter-spacing: .01em;
  box-shadow: 0 8px 20px rgba(76, 29, 149, .28);
  cursor: pointer;
  opacity: .92;
}
.daw-filmora-timeline .daw-arr-clip:not(:hover):not(.selected) .daw-clip-ai-button:not(.active) {
  opacity: 0;
  pointer-events: none;
}
.daw-filmora-timeline .daw-clip-ai-button:hover,
.daw-filmora-timeline .daw-clip-ai-button.active {
  opacity: 1;
  transform: translateY(-1px);
  border-color: rgba(216, 180, 254, .82);
  background: linear-gradient(135deg, rgba(124, 58, 237, .98), rgba(6, 182, 212, .90));
}
.daw-filmora-timeline .daw-clip-ai-popover {
  position: absolute;
  right: 8px;
  top: 38px;
  z-index: 30;
  width: min(520px, calc(100vw - 360px));
  min-width: 360px;
  padding: 10px;
  border-radius: 14px;
  border: 1px solid rgba(167, 139, 250, .42);
  background:
    radial-gradient(circle at 0% 0%, rgba(14, 165, 233, .16), transparent 38%),
    linear-gradient(180deg, rgba(15, 23, 42, .98), rgba(17, 24, 39, .96));
  box-shadow: 0 22px 60px rgba(2, 6, 23, .68), 0 0 0 1px rgba(255, 255, 255, .05) inset;
  cursor: default;
}
.daw-filmora-timeline .daw-clip-ai-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 8px;
}
.daw-filmora-timeline .daw-clip-ai-head strong {
  display: block;
  color: #fff;
  font-size: .86rem;
  line-height: 1.1;
}
.daw-filmora-timeline .daw-clip-ai-head button {
  height: 26px;
  min-height: 26px;
  padding: 4px 7px;
}
.daw-filmora-timeline .daw-clip-ai-popover input {
  width: 100%;
  min-height: 36px;
  height: 36px;
  border-radius: 10px;
  border: 1px solid rgba(148, 163, 184, .18);
  background: rgba(2, 6, 23, .78);
  color: #f8fafc;
  padding: 7px 10px;
  font-weight: 700;
}
.daw-filmora-timeline .daw-clip-ai-popover input:focus {
  outline: none;
  border-color: rgba(56, 189, 248, .62);
  box-shadow: 0 0 0 3px rgba(14, 165, 233, .16);
}
.daw-filmora-timeline .daw-clip-ai-examples {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}
.daw-filmora-timeline .daw-clip-ai-examples button {
  min-height: 28px;
  height: 28px;
  padding: 5px 8px;
  border-radius: 9px;
  font-size: .72rem;
}
.daw-filmora-timeline .daw-clip-ai-examples button.primary {
  min-width: 94px;
}
@media (max-width: 1240px) {
  .daw-filmora-timeline.daw-clean-workspace .daw-clean-control {
    grid-template-columns: 1fr !important;
    grid-template-areas:
      "transport"
      "project"
      "tools"
      "edit" !important;
  }
  .daw-filmora-timeline.daw-clean-workspace .daw-clean-project,
  .daw-filmora-timeline.daw-clean-workspace .daw-clean-edit {
    justify-content: flex-start !important;
  }
  .daw-filmora-timeline .daw-clip-ai-popover {
    right: auto;
    left: 8px;
    width: min(480px, calc(100vw - 320px));
    min-width: 320px;
  }
}
`;

function markerSortValue(marker) {
  const label = String(marker?.label || '');
  const numeric = Number(label);
  if (String(marker?.type || '').toLowerCase() === 'jump' && Number.isFinite(numeric)) {
    return numeric - 1000;
  }
  return safeNumber(marker?.time);
}

function sortMarkers(markers = []) {
  return [...markers].sort((a, b) => {
    const byTime = safeNumber(a?.time) - safeNumber(b?.time);
    if (Math.abs(byTime) > 0.0001) return byTime;
    return markerSortValue(a) - markerSortValue(b);
  });
}

function cloneArrangementSnapshot(value) {
  if (!value) return null;
  try { return JSON.parse(JSON.stringify(value)); } catch { return null; }
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, Number(value || 0)));
}

function safeNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function clipDuration(clip) {
  return Math.max(0, safeNumber(clip?.source_end) - safeNumber(clip?.source_start));
}

function normalizeFadePair(fadeInValue, fadeOutValue, durationValue) {
  const duration = Math.max(0, safeNumber(durationValue));
  const maxTotal = Math.max(0, duration - 0.05);
  let fadeIn = clamp(safeNumber(fadeInValue), 0, maxTotal);
  let fadeOut = clamp(safeNumber(fadeOutValue), 0, maxTotal);
  const total = fadeIn + fadeOut;
  if (total > maxTotal && total > 0) {
    const ratio = maxTotal / total;
    fadeIn *= ratio;
    fadeOut *= ratio;
  }
  return { fadeIn, fadeOut };
}

function fadeHandlePercent(value, durationValue, side = 'left') {
  const duration = Math.max(0.1, safeNumber(durationValue, 0.1));
  const raw = clamp((safeNumber(value) / duration) * 100, 0, 50);
  if (side === 'right') return clamp(100 - raw, 50, 99.2);
  return clamp(raw, 0.8, 50);
}

function secondsToClock(value, withTenths = false) {
  const total = Math.max(0, Number(value || 0));
  const minutes = Math.floor(total / 60);
  const seconds = Math.floor(total % 60);
  if (!withTenths) return `${minutes}:${String(seconds).padStart(2, '0')}`;
  const tenths = Math.floor((total % 1) * 10);
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${tenths}`;
}

function percent(value, duration) {
  if (!duration) return 0;
  return clamp((safeNumber(value) / duration) * 100, 0, 100);
}

function makeId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function arrangementLength(arrangement, fallbackDuration = 0) {
  const clips = Array.isArray(arrangement?.clips) ? arrangement.clips : [];
  const clipEnd = clips.reduce((max, clip) => Math.max(max, safeNumber(clip.timeline_start) + clipDuration(clip)), 0);
  const markerEnd = (arrangement?.markers || []).reduce((max, marker) => Math.max(max, safeNumber(marker.time)), 0);
  return Math.max(1, safeNumber(arrangement?.duration_seconds), fallbackDuration, clipEnd, markerEnd);
}

function roundedAudioValue(value, digits = 3) {
  const factor = 10 ** digits;
  return Math.round(safeNumber(value) * factor) / factor;
}

function arrangementPlaybackSignature(arrangement) {
  if (!arrangement || typeof arrangement !== 'object') return '';
  const clips = Array.isArray(arrangement.clips) ? arrangement.clips : [];
  const tracks = Array.isArray(arrangement.tracks) ? arrangement.tracks : [];
  return JSON.stringify({
    duration: roundedAudioValue(arrangementLength(arrangement, arrangement.duration_seconds || 0)),
    clips: clips
      .map((clip) => ({
        id: String(clip.id || ''),
        track: String(clip.track_id || ''),
        source: Number(clip.source_audio_id || 0),
        start: roundedAudioValue(clip.timeline_start),
        in: roundedAudioValue(clip.source_start),
        out: roundedAudioValue(clip.source_end),
        gain: roundedAudioValue(clip.gain_db, 2),
        fadeIn: roundedAudioValue(clip.fade_in, 2),
        fadeOut: roundedAudioValue(clip.fade_out, 2),
        muted: Boolean(clip.muted),
      }))
      .sort((a, b) => (a.track === b.track ? a.start - b.start : a.track.localeCompare(b.track))),
    tracks: tracks.map((track) => ({ id: String(track.id || ''), muted: Boolean(track.muted), solo: Boolean(track.solo), volume: roundedAudioValue(track.volume_db, 2) })),
  });
}

function arrangementNeedsRenderedPlayback(arrangement, sourceDuration = 0) {
  const clips = Array.isArray(arrangement?.clips) ? arrangement.clips.filter((clip) => !clip.muted) : [];
  const duration = arrangementLength(arrangement, sourceDuration || arrangement?.duration_seconds || 0);
  const safeSourceDuration = Math.max(0, safeNumber(sourceDuration));
  if (!clips.length) return false;
  if (duration > safeSourceDuration + 0.15) return true;
  if (clips.length !== 1) return true;
  const clip = clips[0];
  if (Math.abs(safeNumber(clip.timeline_start)) > 0.05) return true;
  if (Math.abs(safeNumber(clip.source_start)) > 0.05) return true;
  if (safeSourceDuration > 0 && Math.abs(safeNumber(clip.source_end) - safeSourceDuration) > 0.15) return true;
  if (Math.abs(safeNumber(clip.gain_db)) > 0.01) return true;
  if (safeNumber(clip.fade_in) > 0.01 || safeNumber(clip.fade_out) > 0.01) return true;
  return false;
}

function collectDawTextValues(value, depth = 0, sink = []) {
  if (value == null || depth > 5 || sink.length > 80) return sink;
  if (typeof value === 'string') {
    const parsed = parseMaybeJson(value);
    if (parsed && parsed !== value) collectDawTextValues(parsed, depth + 1, sink);
    const trimmed = value.trim();
    if (trimmed && trimmed.length <= 8000) sink.push(trimmed);
    return sink;
  }
  if (Array.isArray(value)) {
    value.slice(0, 30).forEach((item) => collectDawTextValues(item, depth + 1, sink));
    return sink;
  }
  if (typeof value === 'object') {
    Object.entries(value).forEach(([key, item]) => {
      if (/waveform|bars|peaks|samples|lyrics|prompt/i.test(key) && typeof item !== 'string') return;
      collectDawTextValues(item, depth + 1, sink);
    });
  }
  return sink;
}

function inferBpmFromAsset(asset) {
  const explicit = [
    asset?.bpm,
    asset?.tempo,
    asset?.metadata?.bpm,
    asset?.metadata?.tempo,
    asset?.metadata_json?.bpm,
    asset?.metadata_json?.tempo,
    asset?.metadata_json?.request_payload?.bpm,
    asset?.metadata_json?.request_payload?.tempo,
  ];
  for (const value of explicit) {
    const parsed = safeNumber(value, Number.NaN);
    if (Number.isFinite(parsed) && parsed >= 20 && parsed <= 300) return Math.round(parsed * 10) / 10;
  }

  const text = collectDawTextValues({
    tags: asset?.tags,
    style: asset?.style,
    style_prompt: asset?.style_prompt,
    metadata_json: asset?.metadata_json,
    metadata: asset?.metadata,
    candidate: asset?.candidate,
    request_payload: asset?.request_payload,
  }).join(' | ');
  const patterns = [
    /(?:^|[^0-9])([2][0-9]{2}|1[0-9]{2}|[6-9][0-9])\s*bpm\b/i,
    /\bbpm\s*[:=]?\s*([2][0-9]{2}|1[0-9]{2}|[6-9][0-9])\b/i,
    /\btempo\s*[:=]?\s*([2][0-9]{2}|1[0-9]{2}|[6-9][0-9])\b/i,
  ];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (!match) continue;
    const parsed = safeNumber(match[1], Number.NaN);
    if (Number.isFinite(parsed) && parsed >= 20 && parsed <= 300) return Math.round(parsed * 10) / 10;
  }
  return null;
}

function sectionBarCandidates(kind = '') {
  if (kind === 'chorus' || kind === 'post_chorus' || kind === 'pre_chorus') return [16, 8, 12, 4, 24, 32];
  if (kind === 'verse') return [16, 24, 32, 12, 8];
  if (kind === 'intro' || kind === 'outro' || kind === 'break' || kind === 'bridge') return [4, 8, 16, 12, 24, 32];
  return [4, 8, 12, 16, 24, 32];
}

function estimateMusicalBarsForSection(section, bpm) {
  const duration = Math.max(0, safeNumber(section?.duration || (safeNumber(section?.end) - safeNumber(section?.start))));
  const safeBpm = safeNumber(bpm, 0);
  if (!duration || safeBpm < 20) return null;
  const barLength = 240 / safeBpm;
  const candidates = sectionBarCandidates(section?.kind);
  let best = null;
  candidates.forEach((bars, index) => {
    const expected = bars * barLength;
    const diff = Math.abs(duration - expected);
    const score = diff + index * 0.035;
    if (!best || score < best.score) best = { bars, expected, diff, score };
  });
  const tolerance = Math.max(0.65, barLength * 0.45);
  return best && best.diff <= tolerance ? best : null;
}

function deriveBarGridOffset(sections = [], bpm = 0, fallback = 0) {
  const safeBpm = safeNumber(bpm, 0);
  if (safeBpm < 20) return 0;
  const barLength = 240 / safeBpm;
  const boundaries = [];
  sections.forEach((section) => {
    const start = safeNumber(section?.start, Number.NaN);
    const end = safeNumber(section?.end, Number.NaN);
    if (Number.isFinite(start) && start > 0.05) boundaries.push(start);
    if (Number.isFinite(end) && end > 0.05) boundaries.push(end);
  });
  if (!boundaries.length) return ((safeNumber(fallback) % barLength) + barLength) % barLength;
  let x = 0;
  let y = 0;
  boundaries.forEach((time) => {
    const residue = ((time % barLength) + barLength) % barLength;
    const angle = (residue / barLength) * Math.PI * 2;
    x += Math.cos(angle);
    y += Math.sin(angle);
  });
  if (Math.hypot(x, y) < 0.0001) return ((safeNumber(fallback) % barLength) + barLength) % barLength;
  const angle = Math.atan2(y, x);
  return ((angle / (Math.PI * 2)) * barLength + barLength) % barLength;
}

function snapToMusicalBar(time, bpm, offset = 0, duration = Infinity) {
  const safeBpm = safeNumber(bpm, 0);
  if (safeBpm < 20) return safeNumber(time);
  const barLength = 240 / safeBpm;
  const snapped = safeNumber(offset) + Math.round((safeNumber(time) - safeNumber(offset)) / barLength) * barLength;
  return clamp(snapped, 0, Number.isFinite(duration) ? duration : Math.max(snapped, 0));
}

function validDawBeatgrid(grid) {
  return Boolean(grid?.ok && Array.isArray(grid?.bars) && grid.bars.length >= 2);
}

function dawBeatgridBoundaries(grid, duration = 0) {
  if (!validDawBeatgrid(grid)) return [];
  const boundaries = [];
  (grid.bars || []).forEach((bar) => {
    const start = safeNumber(bar?.start, Number.NaN);
    if (Number.isFinite(start)) boundaries.push(start);
  });
  const lastEnd = safeNumber(grid.bars?.[grid.bars.length - 1]?.end, Number.NaN);
  if (Number.isFinite(lastEnd)) boundaries.push(lastEnd);
  const safeDuration = safeNumber(duration, 0);
  if (safeDuration > 0) boundaries.push(safeDuration);
  return [...new Set(boundaries.map((value) => Math.round(clamp(value, 0, safeDuration || value) * 1000) / 1000))].sort((a, b) => a - b);
}

function nearestDawBeatgridBoundary(time, grid, duration = 0) {
  const boundaries = dawBeatgridBoundaries(grid, duration);
  if (!boundaries.length) return null;
  const raw = safeNumber(time, 0);
  return boundaries.reduce((best, value) => (Math.abs(value - raw) < Math.abs(best - raw) ? value : best), boundaries[0]);
}

function nearestDawBeat(time, grid, duration = 0) {
  const beats = Array.isArray(grid?.beats) ? grid.beats.map((value) => safeNumber(value, Number.NaN)).filter(Number.isFinite) : [];
  if (!beats.length) return nearestDawBeatgridBoundary(time, grid, duration);
  const raw = clamp(safeNumber(time, 0), 0, duration || safeNumber(grid?.duration_seconds, 0) || Math.max(...beats));
  return beats.reduce((best, value) => (Math.abs(value - raw) < Math.abs(best - raw) ? value : best), beats[0]);
}

function snapToDawBeatgrid(time, grid, snapUnit = 'beat', duration = 0) {
  if (!validDawBeatgrid(grid)) return null;
  if (snapUnit === 'bar') return nearestDawBeatgridBoundary(time, grid, duration);
  if (snapUnit === 'beat') return nearestDawBeat(time, grid, duration);
  // Half/quarter are approximated locally from neighbouring beat intervals.
  const beats = Array.isArray(grid?.beats) ? grid.beats.map((value) => safeNumber(value, Number.NaN)).filter(Number.isFinite).sort((a, b) => a - b) : [];
  if (beats.length < 2) return nearestDawBeat(time, grid, duration);
  const raw = clamp(safeNumber(time, 0), 0, duration || safeNumber(grid?.duration_seconds, 0) || beats[beats.length - 1]);
  let best = beats[0];
  let bestDistance = Math.abs(best - raw);
  for (let index = 0; index < beats.length - 1; index += 1) {
    const start = beats[index];
    const end = beats[index + 1];
    const divisions = snapUnit === 'quarter' ? 4 : 2;
    for (let part = 0; part <= divisions; part += 1) {
      const candidate = start + ((end - start) * part) / divisions;
      const distance = Math.abs(candidate - raw);
      if (distance < bestDistance) {
        best = candidate;
        bestDistance = distance;
      }
    }
  }
  return clamp(best, 0, duration || best);
}

function medianNumber(values = []) {
  const cleaned = values.map((value) => safeNumber(value, Number.NaN)).filter(Number.isFinite).sort((a, b) => a - b);
  if (!cleaned.length) return null;
  const mid = Math.floor(cleaned.length / 2);
  return cleaned.length % 2 ? cleaned[mid] : (cleaned[mid - 1] + cleaned[mid]) / 2;
}

function medianBarLengthFromGrid(grid) {
  const lengths = (Array.isArray(grid?.bars) ? grid.bars : [])
    .map((bar) => safeNumber(bar?.end) - safeNumber(bar?.start))
    .filter((value) => value > 0.25 && value < 12);
  return medianNumber(lengths) || (safeNumber(grid?.bpm, 0) >= 20 ? 240 / safeNumber(grid.bpm) : null);
}

function estimateBarsForSectionFromGrid(section, grid, rawStart, rawEnd) {
  const barLength = medianBarLengthFromGrid(grid);
  const duration = Math.max(0, safeNumber(rawEnd) - safeNumber(rawStart));
  if (!barLength || !duration) return null;
  const candidates = sectionBarCandidates(section?.kind);
  let best = null;
  candidates.forEach((bars, index) => {
    const expected = bars * barLength;
    const diff = Math.abs(duration - expected);
    const score = diff + index * 0.025;
    if (!best || score < best.score) best = { bars, expected, diff, score };
  });
  const tolerance = Math.max(0.9, barLength * 0.68);
  if (best && best.diff <= tolerance) return best.bars;
  const rounded = Math.round(duration / barLength);
  return rounded >= 1 && rounded <= 128 ? rounded : null;
}

function boundaryIndexAtOrBefore(boundaries = [], time = 0, tolerance = 0.12) {
  if (!boundaries.length) return -1;
  const raw = safeNumber(time);
  let index = -1;
  for (let i = 0; i < boundaries.length; i += 1) {
    if (boundaries[i] <= raw + tolerance) index = i;
    else break;
  }
  return index;
}

function matchingGridSegment(section, grid) {
  if (!section || !Array.isArray(grid?.segments)) return null;
  const kind = String(section.kind || '').toLowerCase();
  const occurrence = safeNumber(section.occurrence, 0);
  const candidates = grid.segments
    .filter((segment) => String(segment?.kind || '').toLowerCase() === kind)
    .sort((a, b) => safeNumber(a?.start) - safeNumber(b?.start));
  if (!candidates.length) return null;
  if (occurrence >= 1 && candidates[occurrence - 1]) return candidates[occurrence - 1];
  const rawStart = safeNumber(section.start);
  return candidates.reduce((best, item) => (Math.abs(safeNumber(item.start) - rawStart) < Math.abs(safeNumber(best.start) - rawStart) ? item : best), candidates[0]);
}

function dawBeatgridRangeForSection(section, grid, duration = 0) {
  if (!validDawBeatgrid(grid) || !section) return null;
  const maxDuration = duration || safeNumber(grid.duration_seconds, 0);
  const rawStart = clamp(safeNumber(section.start), 0, maxDuration);
  const rawEnd = clamp(safeNumber(section.end), rawStart + 0.25, maxDuration);
  const boundaries = dawBeatgridBoundaries(grid, maxDuration);
  if (boundaries.length < 2) return null;

  const gridSegment = matchingGridSegment(section, grid);
  const segmentStart = gridSegment && Number.isFinite(Number(gridSegment.snapped_start)) ? safeNumber(gridSegment.snapped_start) : null;
  const segmentEnd = gridSegment && Number.isFinite(Number(gridSegment.snapped_end)) ? safeNumber(gridSegment.snapped_end) : null;
  const kind = String(section.kind || '').toLowerCase();
  const isMusicalSection = ['chorus', 'post_chorus', 'pre_chorus', 'verse', 'bridge', 'break', 'intro', 'outro'].includes(kind);
  const barLength = medianBarLengthFromGrid(grid) || 0;
  const barsWanted = estimateBarsForSectionFromGrid(section, grid, rawStart, rawEnd);

  let startIndex = -1;
  let endIndex = -1;

  if (segmentStart != null && segmentEnd != null && segmentEnd > segmentStart + 0.2) {
    startIndex = boundaries.findIndex((value) => Math.abs(value - segmentStart) <= 0.025);
    if (startIndex < 0) startIndex = boundaryIndexAtOrBefore(boundaries, segmentStart, 0.12);
    if (startIndex < 0) startIndex = 0;
    endIndex = boundaries.findIndex((value) => Math.abs(value - segmentEnd) <= 0.025);
  }

  if (startIndex < 0) {
    // For semantic song sections, never cut the beginning late: prefer the last
    // downbeat/bar-boundary at or slightly before the detected structure start.
    startIndex = boundaryIndexAtOrBefore(boundaries, rawStart, 0.14);
    if (startIndex < 0) startIndex = 0;

    // If the detector timestamp is only marginally before the next downbeat,
    // use that next downbeat instead of pulling in a full extra bar.
    const next = boundaries[startIndex + 1];
    if (barLength > 0 && Number.isFinite(next) && next - rawStart >= 0 && next - rawStart <= Math.min(0.18, barLength * 0.08)) {
      startIndex += 1;
    }
  }

  if (barsWanted && isMusicalSection) {
    endIndex = Math.min(boundaries.length - 1, startIndex + barsWanted);
  }
  if (endIndex < 0 || endIndex <= startIndex) {
    // Without a stable bar count, prefer the last boundary at or before the end
    // for chorus/verse style commands. This avoids copying the first half-line
    // of the following section into the duplicate.
    endIndex = boundaryIndexAtOrBefore(boundaries, rawEnd, 0.18);
    if (endIndex <= startIndex) {
      const after = boundaries.findIndex((value) => value > rawEnd + 0.1);
      endIndex = after > startIndex ? after : Math.min(boundaries.length - 1, startIndex + 1);
    }
  }

  let start = clamp(boundaries[startIndex], 0, maxDuration);
  let end = clamp(boundaries[endIndex], start + 0.25, maxDuration);
  if (end <= start + 0.2) {
    start = nearestDawBeatgridBoundary(rawStart, grid, maxDuration);
    end = nearestDawBeatgridBoundary(rawEnd, grid, maxDuration);
  }
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start + 0.2) return null;

  const bars = Math.max(1, endIndex - startIndex) || (grid.bars || []).filter((bar) => safeNumber(bar?.start) >= start - 0.02 && safeNumber(bar?.end) <= end + 0.02).length || null;
  const adjusted = Math.abs(start - rawStart) > 0.035 || Math.abs(end - rawEnd) > 0.035;
  const source = grid.source_label || grid.source || 'local_bar_map';
  const confidence = safeNumber(grid.confidence, null);
  const modeLabel = segmentStart != null ? 'Analyse-Segment + Bar-Map' : 'Bar-Map-Schnitt';
  return {
    start,
    end,
    bars,
    bpm: safeNumber(grid.bpm, null),
    adjusted,
    source,
    confidence,
    label: adjusted
      ? `${modeLabel}: ${secondsToClock(rawStart, true)} – ${secondsToClock(rawEnd, true)} → ${secondsToClock(start, true)} – ${secondsToClock(end, true)}${bars ? ` (${bars} Takte` : ''}${confidence ? `, Sicherheit ${Math.round(confidence * 100)}%` : ''}`
      : `Bar-Map aktiv${bars ? ` (${bars} Takte` : ''}${confidence ? `, Sicherheit ${Math.round(confidence * 100)}%` : ''}`,
  };
}

function buildDefaultArrangement(asset, duration = 0) {
  const safeDuration = Math.max(1, safeNumber(duration || asset?.duration_seconds, 1));
  const title = pickTitle(asset) || `Audio ${asset?.id || ''}`;
  const inferredBpm = inferBpmFromAsset(asset);
  return {
    version: 1,
    source_audio_id: Number(asset?.id || 0),
    duration_seconds: safeDuration,
    bpm: inferredBpm,
    time_signature: '4/4',
    snap_enabled: false,
    snap_unit: 'beat',
    tracks: TRACKS.map((track) => ({ ...track, muted: false, solo: false, volume_db: 0 })),
    clips: [{
      id: makeId('clip'),
      track_id: 'track-1',
      source_audio_id: Number(asset?.id || 0),
      timeline_start: 0,
      source_start: 0,
      source_end: safeDuration,
      gain_db: 0,
      fade_in: 0,
      fade_out: 0,
      label: title,
      muted: false,
      locked: false,
      color: 'cyan',
    }],
    markers: [],
  };
}

function normalizeArrangement(raw, asset, duration = 0) {
  const base = buildDefaultArrangement(asset, duration);
  if (!raw || typeof raw !== 'object') return base;
  const tracks = Array.isArray(raw.tracks) && raw.tracks.length ? raw.tracks.slice(0, 3) : base.tracks;
  const validTrackIds = new Set(tracks.map((track, index) => track?.id || `track-${index + 1}`));
  const sourceDuration = Math.max(0, safeNumber(duration || asset?.duration_seconds, 0));
  const minClipLength = 0.25;
  const clips = (Array.isArray(raw.clips) ? raw.clips : base.clips).map((clip, index) => {
    let sourceStart = Math.max(0, safeNumber(clip?.source_start));
    let sourceEnd = safeNumber(clip?.source_end, sourceStart + 1);
    if (sourceDuration > minClipLength) {
      sourceStart = clamp(sourceStart, 0, Math.max(0, sourceDuration - minClipLength));
      sourceEnd = clamp(sourceEnd, sourceStart + minClipLength, sourceDuration);
    }
    if (sourceEnd <= sourceStart) sourceEnd = sourceStart + minClipLength;
    const trackId = validTrackIds.has(clip?.track_id) ? clip.track_id : 'track-1';
    const fades = normalizeFadePair(clip?.fade_in, clip?.fade_out, sourceEnd - sourceStart);
    return {
      id: String(clip?.id || makeId(`clip-${index + 1}`)),
      track_id: trackId,
      source_audio_id: Number(clip?.source_audio_id || asset?.id || 0),
      timeline_start: Math.max(0, safeNumber(clip?.timeline_start)),
      source_start: sourceStart,
      source_end: sourceEnd,
      gain_db: clamp(safeNumber(clip?.gain_db), -24, 24),
      fade_in: fades.fadeIn,
      fade_out: fades.fadeOut,
      label: String(clip?.label || pickTitle(asset) || `Clip ${index + 1}`),
      muted: Boolean(clip?.muted),
      locked: Boolean(clip?.locked),
      color: String(clip?.color || 'cyan'),
    };
  });
  return {
    ...base,
    ...raw,
    source_audio_id: Number(asset?.id || raw.source_audio_id || 0),
    duration_seconds: arrangementLength({ ...raw, clips }, base.duration_seconds),
    tracks: tracks.map((track, index) => ({
      id: String(track?.id || `track-${index + 1}`),
      name: String(track?.name || `Spur ${index + 1}`),
      muted: Boolean(track?.muted),
      solo: Boolean(track?.solo),
      volume_db: clamp(safeNumber(track?.volume_db), -24, 24),
    })),
    clips,
    markers: sortMarkers((Array.isArray(raw.markers) ? raw.markers : []).map((marker, index) => ({
      id: String(marker?.id || makeId(`marker-${index + 1}`)),
      label: String(marker?.label || 'Marker'),
      time: Math.max(0, safeNumber(marker?.time)),
      type: String(marker?.type || 'marker'),
      note: marker?.note || null,
    }))),
    snap_enabled: Boolean(raw.snap_enabled),
    snap_unit: ['bar', 'beat', 'half', 'quarter'].includes(raw.snap_unit) ? raw.snap_unit : 'beat',
    bpm: raw.bpm ? clamp(safeNumber(raw.bpm), 20, 300) : base.bpm,
  };
}

function ticksForDuration(duration, zoomLevel = 1) {
  const counts = [8, 10, 12, 16, 20];
  const count = counts[clamp(zoomLevel, 0, counts.length - 1)] || 10;
  return Array.from({ length: count + 1 }, (_, index) => {
    const time = (duration / count) * index;
    const major = index === 0 || index === count || index % 2 === 0;
    return {
      index,
      major,
      time,
      left: `${(index / count) * 100}%`,
      label: secondsToClock(time, zoomLevel >= 3 && duration <= 360),
    };
  });
}

function parseMaybeJson(value) {
  if (!value) return null;
  if (Array.isArray(value) || (typeof value === 'object' && value !== null)) return value;
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed || !['[', '{'].includes(trimmed[0])) return null;
  try { return JSON.parse(trimmed); } catch { return null; }
}

function parseClockValue(value) {
  if (typeof value !== 'string') return Number.NaN;
  const trimmed = value.trim();
  if (!trimmed) return Number.NaN;
  if (/^\d+(?:[.,]\d+)?$/.test(trimmed)) return Number(trimmed.replace(',', '.'));
  const parts = trimmed.split(':').map((part) => Number(part.replace(',', '.')));
  if (parts.some((part) => !Number.isFinite(part))) return Number.NaN;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return Number.NaN;
}

function segmentTimeValue(segment, keys, duration = 0) {
  if (!segment || typeof segment !== 'object') return Number.NaN;
  for (const key of keys) {
    if (!(key in segment)) continue;
    let value = segment[key];
    let parsed = typeof value === 'string' ? parseClockValue(value) : Number(value);
    if (!Number.isFinite(parsed)) continue;
    if (/ms$/i.test(key) || (parsed > 1000 && duration > 0 && parsed > duration * 2.5)) parsed /= 1000;
    return parsed;
  }
  return Number.NaN;
}

function cleanSectionLabel(value = '') {
  return String(value || '')
    .replace(/^\s*\[/, '')
    .replace(/[\[\]]/g, ' ')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function sectionKindFromLabel(label = '') {
  const raw = cleanSectionLabel(label).toLowerCase();
  if (!raw) return '';
  if (/pre\s*(chorus|hook|refrain)/i.test(raw)) return 'pre_chorus';
  if (/post\s*(chorus|hook|refrain)/i.test(raw)) return 'post_chorus';
  if (/chorus|hook|refrain|refrain/i.test(raw)) return 'chorus';
  if (/verse|strophe|part\s*\d|rap\s*verse/i.test(raw)) return 'verse';
  if (/intro|anfang|opening/i.test(raw)) return 'intro';
  if (/outro|ende|ending|final/i.test(raw)) return 'outro';
  if (/bridge|middle\s*8|mittelteil/i.test(raw)) return 'bridge';
  if (/breakdown|break|pause|interlude/i.test(raw)) return 'break';
  if (/drop|climax/i.test(raw)) return 'drop';
  if (/instrumental|solo|beat/i.test(raw)) return 'instrumental';
  return '';
}

function labelFromSegment(segment = {}) {
  const candidates = [segment.label, segment.name, segment.title, segment.section, segment.type, segment.kind, segment.part, segment.tag];
  const direct = candidates.find((item) => String(item || '').trim());
  if (direct) return cleanSectionLabel(direct);
  const text = String(segment.text || segment.line || '').trim();
  if (/^\s*\[.+\]\s*$/.test(text)) return cleanSectionLabel(text);
  return '';
}

function extractSegmentsFromValue(value, sourceName, duration = 0, depth = 0) {
  const parsed = parseMaybeJson(value);
  if (!parsed || depth > 4) return [];
  if (Array.isArray(parsed)) {
    return parsed.flatMap((item) => extractSegmentsFromValue(item, sourceName, duration, depth + 1));
  }
  if (typeof parsed !== 'object') return [];

  const label = labelFromSegment(parsed);
  const kind = sectionKindFromLabel(label);
  const start = segmentTimeValue(parsed, ['start_seconds', 'startSeconds', 'start_sec', 'startSec', 'start_s', 'startS', 'start_time', 'startTime', 'start_ms', 'startMs', 'start', 'from', 'begin', 'time'], duration);
  const end = segmentTimeValue(parsed, ['end_seconds', 'endSeconds', 'end_sec', 'endSec', 'end_s', 'endS', 'end_time', 'endTime', 'end_ms', 'endMs', 'end', 'to', 'until', 'stop', 'finish'], duration);
  const found = [];
  if (kind && Number.isFinite(start) && Number.isFinite(end) && end - start >= 0.25) {
    found.push({
      id: `${sourceName}-${kind}-${start.toFixed(2)}-${end.toFixed(2)}`,
      label: label || SECTION_KIND_LABELS[kind] || 'Abschnitt',
      kind,
      start,
      end,
      source: sourceName,
    });
  }

  const knownKeys = ['structure_segments_json', 'structureSegmentsJson', 'structure_segments', 'structureSegments', 'section_segments', 'sectionSegments', 'sections', 'segments_json', 'segmentsJson', 'segments', 'timeline_segments', 'timelineSegments', 'song_structure', 'songStructure', 'lyrics_structure', 'lyricsStructure', 'structure', 'analysis', 'metadata'];
  for (const key of knownKeys) {
    if (parsed[key]) found.push(...extractSegmentsFromValue(parsed[key], `${sourceName}.${key}`, duration, depth + 1));
  }
  return found;
}

function buildResolvedSections({ project, asset, arrangement }, duration = 0) {
  const raw = [];
  const sources = [
    ['project', project],
    ['project.asset', project?.asset],
    ['project.transcript', project?.transcript],
    ['asset', asset],
    ['asset.transcript', asset?.transcript],
    ['arrangement', arrangement],
  ];
  sources.forEach(([name, value]) => raw.push(...extractSegmentsFromValue(value, name, duration)));

  const safeDuration = Math.max(1, safeNumber(duration, 1));
  const deduped = [];
  const seen = new Set();
  raw.forEach((item) => {
    const start = clamp(item.start, 0, safeDuration);
    const end = clamp(item.end, start + 0.25, safeDuration);
    if (end - start < 0.25) return;
    const key = `${item.kind}-${Math.round(start * 10)}-${Math.round(end * 10)}`;
    if (seen.has(key)) return;
    seen.add(key);
    deduped.push({ ...item, id: key, start, end });
  });

  const ordered = deduped.sort((a, b) => {
    const byTime = a.start - b.start;
    if (Math.abs(byTime) > 0.001) return byTime;
    return SECTION_KIND_PRIORITY.indexOf(a.kind) - SECTION_KIND_PRIORITY.indexOf(b.kind);
  });
  const counters = {};
  return ordered.map((item) => {
    counters[item.kind] = (counters[item.kind] || 0) + 1;
    const baseLabel = SECTION_KIND_LABELS[item.kind] || item.label || 'Abschnitt';
    const displayLabel = `${baseLabel}${counters[item.kind] > 1 ? ` ${counters[item.kind]}` : ''}`;
    return {
      ...item,
      occurrence: counters[item.kind],
      displayLabel,
      duration: item.end - item.start,
    };
  });
}


function normalizeDawAiText(value = '') {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ä/g, 'ae')
    .replace(/ö/g, 'oe')
    .replace(/ü/g, 'ue')
    .replace(/ß/g, 'ss')
    .replace(/[„“”]/g, '"')
    .replace(/[’']/g, '')
    .replace(/[^a-z0-9#+:.,\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function dawAiSectionKindFromText(text = '') {
  const raw = normalizeDawAiText(text);
  if (/pre\s*(chorus|hook|refrain)|vor\s*(chorus|hook|refrain)/.test(raw)) return 'pre_chorus';
  if (/post\s*(chorus|hook|refrain)|nach\s*(chorus|hook|refrain)/.test(raw)) return 'post_chorus';
  if (/hook|chorus|refrain|refreng|refrain/.test(raw)) return 'chorus';
  if (/verse|strophe|part\s*\d|rap\s*part/.test(raw)) return 'verse';
  if (/intro|anfang|opening/.test(raw)) return 'intro';
  if (/outro|ende|ending|schluss/.test(raw)) return 'outro';
  if (/bridge|mittelteil/.test(raw)) return 'bridge';
  if (/breakdown|break|pause|interlude/.test(raw)) return 'break';
  if (/drop|climax/.test(raw)) return 'drop';
  if (/instrumental|solo|beat/.test(raw)) return 'instrumental';
  return '';
}

function dawAiOccurrenceFromText(text = '') {
  const raw = normalizeDawAiText(text);
  if (/letzte[nrms]?|finale[nrms]?|schluss/.test(raw)) return 'last';
  if (/erste[nrms]?|1\.|#?1\b/.test(raw)) return 1;
  if (/zweite[nrms]?|2\.|#?2\b/.test(raw)) return 2;
  if (/dritte[nrms]?|3\.|#?3\b/.test(raw)) return 3;
  if (/vierte[nrms]?|4\.|#?4\b/.test(raw)) return 4;
  if (/fuenfte[nrms]?|funfte[nrms]?|5\.|#?5\b/.test(raw)) return 5;
  return null;
}

function truncateDawAiPrompt(value = '') {
  const text = String(value || '').trim().replace(/\s+/g, ' ');
  return text.length > 120 ? `${text.slice(0, 117)}…` : text;
}

function dawAiFirstNumber(text = '', fallback = null) {
  const match = String(text || '').match(/[-+]?\d+(?:[,.]\d+)?/);
  if (!match) return fallback;
  const parsed = Number(match[0].replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : fallback;
}

function dawAiSecondsFromText(text = '', fallback = 2) {
  const raw = String(text || '');
  const minuteMatch = raw.match(/(\d+(?:[,.]\d+)?)\s*(min|minute|minuten)/);
  if (minuteMatch) {
    const minutes = Number(minuteMatch[1].replace(',', '.'));
    if (Number.isFinite(minutes)) return minutes * 60;
  }
  const secondMatch = raw.match(/(\d+(?:[,.]\d+)?)\s*(s|sek|sekunde|sekunden|sec|seconds)/);
  if (secondMatch) {
    const seconds = Number(secondMatch[1].replace(',', '.'));
    if (Number.isFinite(seconds)) return seconds;
  }
  return fallback;
}

function usePointerDrag(onMove, onEnd) {
  const state = useRef(null);
  useEffect(() => {
    function handleMove(event) {
      if (!state.current) return;
      onMove(event, state.current);
    }
    function handleEnd(event) {
      if (!state.current) return;
      const current = state.current;
      state.current = null;
      onEnd?.(event, current);
    }
    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleEnd);
    window.addEventListener('pointercancel', handleEnd);
    return () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleEnd);
      window.removeEventListener('pointercancel', handleEnd);
    };
  }, [onMove, onEnd]);
  return state;
}

function DawEmptyState({ t, lastKnownAsset, onOpenLast, onBackToLibrary }) {
  return (
    <section className="panel empty-state daw-empty-state">
      <Scissors size={34} />
      <h3>{t('daw.empty.title', 'Kein Audio ausgewählt')}</h3>
      <p>{t('daw.empty.description', 'Öffne einen Song oder eine Variante aus der Library über „In Mini-DAW öffnen“.')}</p>
      <div className="button-row wrap">
        <button className="primary" type="button" onClick={onBackToLibrary}><ArrowLeft size={15} /> {t('daw.backToLibrary', 'Zur Library')}</button>
        {lastKnownAsset && <button type="button" onClick={onOpenLast}><FileAudio size={15} /> Zuletzt öffnen</button>}
      </div>
    </section>
  );
}

export function DawPage({ assets = [], selectedAssetId = null, onSelectedHandled, onAssetChange, onBackToLibrary, onPlay, notify, onReload }) {
  const { t } = useI18n();
  const playable = useMemo(() => (assets || []).filter((asset) => asset?.id && (asset.public_url || asset.local_path || asset.source_url)), [assets]);
  const [assetId, setAssetId] = useState(() => String(selectedAssetId || '').trim());
  const [lastKnownAssetId, setLastKnownAssetId] = useState(() => localStorage.getItem('react-daw-asset-id') || '');
  const [project, setProject] = useState(null);
  const [arrangement, setArrangement] = useState(null);
  const [beatgrid, setBeatgrid] = useState(null);
  const [beatgridLoading, setBeatgridLoading] = useState(false);
  const [selectedClipId, setSelectedClipId] = useState('');
  const [selectedSectionId, setSelectedSectionId] = useState('');
  const [undoStack, setUndoStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [toolMode, setToolMode] = useState('select');
  const [helpOpen, setHelpOpen] = useState(false);
  const [timelineZoom, setTimelineZoom] = useState(() => {
    const stored = Number(localStorage.getItem('react-daw-timeline-zoom'));
    return Number.isFinite(stored) ? clamp(stored, 0, DAW_TIMELINE_ZOOM_OPTIONS.length - 1) : 1;
  });
  const [currentTime, setCurrentTime] = useState(0);
  const [mediaDuration, setMediaDuration] = useState(0);
  const [selection, setSelection] = useState(null);
  const [closeGap, setCloseGap] = useState(true);
  const [outputFormat, setOutputFormat] = useState('mp3');
  const [versionLabel, setVersionLabel] = useState('DAW Arrangement');
  const [previewUrl, setPreviewUrl] = useState('');
  const [previewSignature, setPreviewSignature] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [rendering, setRendering] = useState(false);
  const [renderTask, setRenderTask] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(1);
  const [dragTooltip, setDragTooltip] = useState(null);
  const [snapGuide, setSnapGuide] = useState(null);
  const [commandPreview, setCommandPreview] = useState(null);
  const [aiCommandText, setAiCommandText] = useState('');
  const [aiCommandStatus, setAiCommandStatus] = useState('');
  const [aiCommandHistory, setAiCommandHistory] = useState([]);
  const [aiPanelOpen, setAiPanelOpen] = useState(false);
  const [clipAiPanel, setClipAiPanel] = useState({ clipId: '', prompt: '' });

  useEffect(() => {
    document.body.classList.add('daw-page-active');
    return () => document.body.classList.remove('daw-page-active');
  }, []);
  const audioRef = useRef(null);
  const timelineRef = useRef(null);
  const arrangementRef = useRef(null);
  const timelineDurationRef = useRef(1);
  const snapTimeRef = useRef((value) => Number(value || 0));
  const selectedClipIdRef = useRef('');
  const currentTimeRef = useRef(0);
  const pendingPreviewPlaybackRef = useRef(null);

  const currentAsset = project?.asset || playable.find((asset) => String(asset.id) === String(assetId));
  const lastKnownAsset = playable.find((asset) => String(asset.id) === String(lastKnownAssetId));
  const audioUrl = currentAsset?.public_url ? api.archive.streamUrl(currentAsset.id) : currentAsset?.source_url;
  const timelineDuration = arrangementLength(arrangement, mediaDuration || currentAsset?.duration_seconds || 1);
  const selectedClip = (arrangement?.clips || []).find((clip) => clip.id === selectedClipId) || null;
  const selectedTrackName = selectedClip ? (TRACKS.find((track) => track.id === selectedClip.track_id)?.name || 'Spur') : '';
  const timelineZoomOption = DAW_TIMELINE_ZOOM_OPTIONS[timelineZoom] || DAW_TIMELINE_ZOOM_OPTIONS[1];
  const ticks = useMemo(() => ticksForDuration(timelineDuration, timelineZoom), [timelineDuration, timelineZoom]);
  const sourceDuration = Math.max(0, safeNumber(mediaDuration), safeNumber(currentAsset?.duration_seconds));
  const arrangementSignature = useMemo(() => arrangementPlaybackSignature(arrangement), [arrangement]);
  const needsRenderedPlayback = useMemo(() => arrangementNeedsRenderedPlayback(arrangement, sourceDuration), [arrangement, sourceDuration]);
  const previewMatchesArrangement = Boolean(previewUrl && previewSignature && arrangementSignature && previewSignature === arrangementSignature);
  const activeAudioUrl = previewMatchesArrangement ? previewUrl : audioUrl;
  const usingRenderedPlayback = previewMatchesArrangement && needsRenderedPlayback;
  const activeBeatgrid = validDawBeatgrid(beatgrid) ? beatgrid : null;
  const beatgridSourceLabel = activeBeatgrid?.source_label || (String(activeBeatgrid?.source || '').includes('allin1') ? 'allin1' : activeBeatgrid?.source ? 'Analyse' : '');
  const beatgridStatusLabel = activeBeatgrid
    ? `Bar-Map: ${activeBeatgrid.bars?.length || 0} Takte · ${activeBeatgrid.bpm ? `${Math.round(Number(activeBeatgrid.bpm) * 10) / 10} BPM` : 'lokal analysiert'}${beatgridSourceLabel ? ` · ${beatgridSourceLabel}` : ''}`
    : beatgridLoading
      ? 'Bar-Map wird analysiert …'
      : beatgrid?.status === 'missing_dependency'
        ? 'Bar-Map: allin1/madmom fehlt'
        : beatgrid?.status === 'failed'
          ? 'Bar-Map nicht verfügbar'
          : '';
  const resolvedSections = useMemo(() => buildResolvedSections({ project, asset: currentAsset, arrangement }, Math.max(sourceDuration, timelineDuration)), [project, currentAsset, arrangement, sourceDuration, timelineDuration]);
  const selectedSection = resolvedSections.find((section) => section.id === selectedSectionId) || null;
  const dawAiExamples = useMemo(() => [
    'Schließe alle Lücken',
    'Schneide am Playhead',
    'Dupliziere den markierten Clip',
    'Entferne den markierten Clip',
    'Clip an nächsten Clip anschließen',
    '30s-Bereich ab Playhead markieren',
  ], []);

  useEffect(() => {
    if (!resolvedSections.length) {
      setSelectedSectionId('');
      return;
    }
    setSelectedSectionId((current) => {
      if (current && resolvedSections.some((section) => section.id === current)) return current;
      return resolvedSections.find((section) => section.kind === 'chorus')?.id || resolvedSections[0]?.id || '';
    });
  }, [resolvedSections]);

  function showDragTimeTooltip(event, payload) {
    if (!event) return;
    setDragTooltip({
      x: event.clientX,
      y: event.clientY,
      mode: payload?.mode || 'info',
      title: payload?.title || '',
      rows: Array.isArray(payload?.rows) ? payload.rows : [],
    });
  }

  function hideDragTimeTooltip() {
    setDragTooltip(null);
  }

  function showTimelineSnapGuide(time, label = 'Snap') {
    const safeTime = clamp(safeNumber(time), 0, timelineDurationRef.current || timelineDuration || 1);
    setSnapGuide({ time: safeTime, label: String(label || 'Snap') });
  }

  function hideTimelineSnapGuide() {
    setSnapGuide(null);
  }

  const snapTime = useCallback((value) => {
    const raw = clamp(value, 0, timelineDuration);
    if (!arrangement?.snap_enabled) return raw;
    const gridSnap = snapToDawBeatgrid(raw, activeBeatgrid, arrangement.snap_unit, timelineDuration);
    if (gridSnap !== null && Number.isFinite(gridSnap)) return clamp(gridSnap, 0, timelineDuration);
    if (!arrangement?.bpm) return raw;
    const beat = 60 / Number(arrangement.bpm);
    const unit = arrangement.snap_unit === 'bar' ? beat * 4 : arrangement.snap_unit === 'half' ? beat / 2 : arrangement.snap_unit === 'quarter' ? beat / 4 : beat;
    return clamp(Math.round(raw / unit) * unit, 0, timelineDuration);
  }, [activeBeatgrid, arrangement?.bpm, arrangement?.snap_enabled, arrangement?.snap_unit, timelineDuration]);

  useEffect(() => { arrangementRef.current = arrangement; }, [arrangement]);
  useEffect(() => { timelineDurationRef.current = timelineDuration; }, [timelineDuration]);
  useEffect(() => { snapTimeRef.current = snapTime; }, [snapTime]);
  useEffect(() => { selectedClipIdRef.current = selectedClipId; }, [selectedClipId]);
  useEffect(() => { currentTimeRef.current = currentTime; }, [currentTime]);
  useEffect(() => { localStorage.setItem('react-daw-timeline-zoom', String(timelineZoom)); }, [timelineZoom]);

  useEffect(() => {
    const pending = pendingPreviewPlaybackRef.current;
    if (!pending || !previewMatchesArrangement || !audioRef.current) return undefined;
    pendingPreviewPlaybackRef.current = null;
    const audio = audioRef.current;
    const targetTime = clamp(safeNumber(pending.time), 0, timelineDurationRef.current || timelineDuration || 1);
    let cancelled = false;
    const startPlayback = async () => {
      if (cancelled) return;
      try {
        audio.currentTime = targetTime;
        audio.volume = volume;
        await audio.play();
        if (!cancelled) setIsPlaying(true);
      } catch {
        if (!cancelled) setIsPlaying(false);
      }
    };
    if (audio.readyState >= 1) {
      startPlayback();
      return () => { cancelled = true; };
    }
    audio.addEventListener('loadedmetadata', startPlayback, { once: true });
    return () => {
      cancelled = true;
      audio.removeEventListener('loadedmetadata', startPlayback);
    };
  }, [activeAudioUrl, previewMatchesArrangement, timelineDuration, volume]);

  const renderTaskStatus = String(renderTask?.status || '').toUpperCase();
  const renderTaskActive = Boolean(renderTask?.id || renderTask?.task_local_id) && !['SUCCESS', 'COMPLETED', 'COMPLETE', 'DONE', 'FAILED', 'ERROR', 'CANCELLED', 'COMPLETED_MANUAL'].includes(renderTaskStatus);
  const renderTaskProgress = Number(renderTask?.response_payload?.progress?.percent ?? renderTask?.progress ?? 0);
  const renderTaskPhase = renderTask?.response_payload?.progress?.message || renderTask?.response_payload?.progress?.phase || renderTask?.error_message || '';

  useEffect(() => {
    const taskId = renderTask?.id || renderTask?.task_local_id;
    if (!taskId || !renderTaskActive) return undefined;
    let cancelled = false;
    const poll = async () => {
      try {
        const fresh = await api.music.getTask(taskId);
        if (cancelled) return;
        setRenderTask(fresh);
        const status = String(fresh?.status || '').toUpperCase();
        if (['SUCCESS', 'COMPLETED', 'COMPLETE', 'DONE'].includes(status)) {
          notify?.('DAW-Version wurde fertig gespeichert.', 'success');
          onReload?.();
        }
        if (['FAILED', 'ERROR', 'CANCELLED'].includes(status)) {
          notify?.(fresh?.error_message || 'DAW-Render wurde beendet oder ist fehlgeschlagen.', status === 'CANCELLED' ? 'warning' : 'error');
        }
      } catch {
        // Polling darf den Editor nicht blockieren; Statusseite/Topbar behalten ebenfalls den Task.
      }
    };
    const timer = window.setInterval(poll, 1800);
    poll();
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [renderTask?.id, renderTask?.task_local_id, renderTaskActive, notify, onReload]);

  const rawTimeFromPointer = useCallback((event) => {
    const rect = timelineRef.current?.getBoundingClientRect();
    if (!rect) return 0;
    const x = clamp(event.clientX - rect.left, 0, rect.width);
    return clamp((x / rect.width) * timelineDuration, 0, timelineDuration);
  }, [timelineDuration]);

  const timeFromPointer = useCallback((event) => {
    return snapTime(rawTimeFromPointer(event));
  }, [rawTimeFromPointer, snapTime]);

  function pointerIsInTimelineNavigationZone(event) {
    const zones = Array.from(timelineRef.current?.querySelectorAll('.daw-arr-ruler, .daw-arr-markers') || []);
    return zones.some((zone) => {
      const rect = zone.getBoundingClientRect();
      return event.clientY >= rect.top && event.clientY <= rect.bottom;
    });
  }

  const secondsFromPixels = useCallback((pixels) => {
    const rect = timelineRef.current?.getBoundingClientRect();
    if (!rect?.width) return 0;
    return (Number(pixels || 0) / rect.width) * timelineDurationRef.current;
  }, []);

  const clipSnapThresholdSeconds = useCallback(() => {
    const rect = timelineRef.current?.getBoundingClientRect();
    if (!rect?.width) return 0.25;
    return clamp(secondsFromPixels(SNAP_EDGE_PIXEL_TOLERANCE), SNAP_EDGE_MIN_SECONDS, SNAP_EDGE_MAX_SECONDS);
  }, [secondsFromPixels]);

  const collectClipEdgeSnapPoints = useCallback((excludeClipId, trackId) => {
    const clips = arrangementRef.current?.clips || [];
    return clips
      .filter((clip) => clip.id !== excludeClipId && (!trackId || clip.track_id === trackId))
      .flatMap((clip) => {
        const start = safeNumber(clip.timeline_start);
        const end = start + clipDuration(clip);
        return [
          { time: start, label: `${clip.label || 'Clip'} Start` },
          { time: end, label: `${clip.label || 'Clip'} Ende` },
        ];
      });
  }, []);

  const snapTimelinePoint = useCallback((value, options = {}) => {
    const arrangementSnapshot = arrangementRef.current;
    const base = snapTimeRef.current(value);
    if (!arrangementSnapshot?.snap_enabled) return { value: base, snappedToClip: false, label: '' };

    const threshold = clipSnapThresholdSeconds();
    const points = collectClipEdgeSnapPoints(options.excludeClipId, options.trackId);
    let best = null;
    points.forEach((point) => {
      const diff = Math.abs(base - point.time);
      if (diff <= threshold && (!best || diff < best.diff)) best = { ...point, diff };
    });
    if (!best) return { value: base, snappedToClip: false, label: '' };
    return { value: clamp(best.time, 0, timelineDurationRef.current), snappedToClip: true, label: best.label };
  }, [clipSnapThresholdSeconds, collectClipEdgeSnapPoints]);

  const snapClipPlacement = useCallback((rawStart, options = {}) => {
    const arrangementSnapshot = arrangementRef.current;
    const duration = Math.max(0, safeNumber(options.duration));
    const maxStart = Math.max(0, timelineDurationRef.current - duration);
    const baseStart = clamp(snapTimeRef.current(rawStart), 0, maxStart);
    if (!arrangementSnapshot?.snap_enabled || duration <= 0) {
      return { start: baseStart, snappedToClip: false, label: '' };
    }

    const threshold = clipSnapThresholdSeconds();
    const points = collectClipEdgeSnapPoints(options.excludeClipId, options.trackId);
    let best = null;
    points.forEach((point) => {
      const startDiff = Math.abs(baseStart - point.time);
      if (startDiff <= threshold && (!best || startDiff < best.diff)) {
        best = { start: point.time, diff: startDiff, label: `${point.label} ↔ Clip-Start` };
      }

      const endDiff = Math.abs((baseStart + duration) - point.time);
      if (endDiff <= threshold && (!best || endDiff < best.diff)) {
        best = { start: point.time - duration, diff: endDiff, label: `${point.label} ↔ Clip-Ende` };
      }
    });

    if (!best) return { start: baseStart, snappedToClip: false, label: '' };
    return { start: clamp(best.start, 0, maxStart), snappedToClip: true, label: best.label };
  }, [clipSnapThresholdSeconds, collectClipEdgeSnapPoints]);

  const trackIdFromClientY = useCallback((clientY, fallback = 'track-1') => {
    const rows = Array.from(timelineRef.current?.querySelectorAll('.daw-arr-track-row') || []);
    const row = rows.find((item) => {
      const rect = item.getBoundingClientRect();
      return clientY >= rect.top && clientY <= rect.bottom;
    });
    return row?.getAttribute('data-track-id') || fallback;
  }, []);

  const updateArrangement = useCallback((updater) => {
    setArrangement((current) => {
      const base = normalizeArrangement(current, currentAsset, mediaDuration || currentAsset?.duration_seconds || 1);
      const next = typeof updater === 'function' ? updater(base) : updater;
      return normalizeArrangement(next, currentAsset, mediaDuration || currentAsset?.duration_seconds || 1);
    });
  }, [currentAsset, mediaDuration]);

  const commitArrangementHistory = useCallback((snapshot = arrangementRef.current) => {
    const cloned = cloneArrangementSnapshot(snapshot);
    if (!cloned) return;
    setUndoStack((items) => [...items.slice(-(HISTORY_LIMIT - 1)), cloned]);
    setRedoStack([]);
  }, []);

  const restoreArrangementSnapshot = useCallback((snapshot) => {
    const cloned = cloneArrangementSnapshot(snapshot);
    if (!cloned) return;
    const normalized = normalizeArrangement(cloned, currentAsset, mediaDuration || currentAsset?.duration_seconds || 1);
    setArrangement(normalized);
    setSelectedClipId((current) => normalized.clips.some((clip) => clip.id === current) ? current : (normalized.clips[0]?.id || ''));
    setSelection(null);
  }, [currentAsset, mediaDuration]);

  const undoArrangement = useCallback(() => {
    setUndoStack((items) => {
      if (!items.length) return items;
      const previous = items[items.length - 1];
      const current = cloneArrangementSnapshot(arrangementRef.current);
      if (current) setRedoStack((redoItems) => [...redoItems.slice(-(HISTORY_LIMIT - 1)), current]);
      restoreArrangementSnapshot(previous);
      return items.slice(0, -1);
    });
  }, [restoreArrangementSnapshot]);

  const redoArrangement = useCallback(() => {
    setRedoStack((items) => {
      if (!items.length) return items;
      const next = items[items.length - 1];
      const current = cloneArrangementSnapshot(arrangementRef.current);
      if (current) setUndoStack((undoItems) => [...undoItems.slice(-(HISTORY_LIMIT - 1)), current]);
      restoreArrangementSnapshot(next);
      return items.slice(0, -1);
    });
  }, [restoreArrangementSnapshot]);


  function createDawCommandPlan(command = {}) {
    const base = normalizeArrangement(arrangementRef.current || arrangement, currentAsset, timelineDurationRef.current || mediaDuration || currentAsset?.duration_seconds || 1);
    const original = cloneArrangementSnapshot(base);
    const next = cloneArrangementSnapshot(base);
    if (!original || !next) throw new Error('Kein Arrangement geladen.');

    const commandType = String(command.type || '').trim();
    const actions = [];
    const warnings = Array.isArray(command.warnings) ? command.warnings.filter(Boolean) : [];
    let title = 'DAW-Kommando';
    let summary = 'Geplante Änderung prüfen und danach anwenden.';
    let nextSelectedClipId = selectedClipIdRef.current;
    let nextSelection = selection ? { ...selection } : null;
    let guideTime = null;
    let guideLabel = '';

    const beforeDuration = arrangementLength(base, mediaDuration || currentAsset?.duration_seconds || 1);
    const findClipById = (id) => next.clips.find((clip) => clip.id === id) || null;
    const findClipAt = (time, explicitClipId = '') => {
      const direct = explicitClipId ? findClipById(explicitClipId) : null;
      if (direct) return direct;
      return next.clips.find((clip) => {
        const start = safeNumber(clip.timeline_start);
        const end = start + clipDuration(clip);
        return time > start + 0.001 && time < end - 0.001;
      }) || null;
    };
    const markArrangementChanged = () => {
      next.duration_seconds = arrangementLength(next, beforeDuration);
      next.clips = next.clips.map((clip) => ({ ...clip }));
      next.markers = sortMarkers(next.markers || []);
    };
    const adjacentFor = (clip, direction) => {
      if (!clip) return null;
      const start = safeNumber(clip.timeline_start);
      const end = start + clipDuration(clip);
      const candidates = (next.clips || [])
        .filter((candidate) => candidate.id !== clip.id && candidate.track_id === clip.track_id)
        .map((candidate) => {
          const candidateStart = safeNumber(candidate.timeline_start);
          const candidateEnd = candidateStart + clipDuration(candidate);
          return { ...candidate, candidateStart, candidateEnd };
        });
      if (direction === 'previous') {
        return candidates.filter((candidate) => candidate.candidateEnd <= start + 0.02).sort((a, b) => b.candidateEnd - a.candidateEnd)[0] || null;
      }
      return candidates.filter((candidate) => candidate.candidateStart >= end - 0.02).sort((a, b) => a.candidateStart - b.candidateStart)[0] || null;
    };
    const selectedId = command.clipId || selectedClipIdRef.current;
    const resolveCommandSection = () => {
      const section = command.section || resolvedSections.find((item) => item.id === command.sectionId) || selectedSection;
      if (!section) throw new Error('Bitte zuerst einen Songabschnitt auswählen.');
      const start = clamp(safeNumber(section.start), 0, beforeDuration);
      const end = clamp(safeNumber(section.end), start + 0.25, beforeDuration);
      if (end - start < 0.25) throw new Error('Der ausgewählte Abschnitt ist zu kurz.');
      return { ...section, start, end, duration: end - start, displayLabel: section.displayLabel || section.label || 'Abschnitt' };
    };
    const resolveMusicalSectionRange = (section) => {
      const rawStart = clamp(safeNumber(section.start), 0, sourceDuration || beforeDuration);
      const rawEnd = clamp(safeNumber(section.end), rawStart + 0.25, sourceDuration || beforeDuration);
      const gridRange = dawBeatgridRangeForSection(section, activeBeatgrid, sourceDuration || beforeDuration);
      if (gridRange) return gridRange;
      const bpm = safeNumber(next.bpm || base.bpm || inferBpmFromAsset(currentAsset), 0);
      if (!bpm || bpm < 20) {
        return { start: rawStart, end: rawEnd, bars: null, bpm: null, adjusted: false, label: '', source: 'raw' };
      }
      const barLength = 240 / bpm;
      const offset = deriveBarGridOffset(resolvedSections, bpm, rawStart);
      const snappedStart = snapToMusicalBar(rawStart, bpm, offset, sourceDuration || beforeDuration);
      const snappedEnd = snapToMusicalBar(rawEnd, bpm, offset, sourceDuration || beforeDuration);
      const barEstimate = estimateMusicalBarsForSection(section, bpm);
      let candidates = [{
        start: snappedStart,
        end: Math.max(snappedStart + 0.25, snappedEnd),
        bars: null,
      }];
      if (barEstimate) {
        const targetLength = barEstimate.expected;
        candidates = [
          { start: snappedStart, end: snappedStart + targetLength, bars: barEstimate.bars },
          { start: snappedEnd - targetLength, end: snappedEnd, bars: barEstimate.bars },
          { start: snappedStart, end: snappedEnd, bars: barEstimate.bars },
        ];
      }
      const maxEnd = sourceDuration || beforeDuration;
      const valid = candidates
        .map((item) => ({
          ...item,
          start: clamp(item.start, 0, Math.max(0, maxEnd - 0.25)),
          end: clamp(item.end, 0.25, maxEnd),
        }))
        .filter((item) => item.end - item.start >= 0.25)
        .map((item) => ({
          ...item,
          score: Math.abs(item.start - rawStart) + Math.abs(item.end - rawEnd) + (item.bars ? 0 : 0.15),
        }))
        .sort((a, b) => a.score - b.score);
      const best = valid[0] || { start: rawStart, end: rawEnd, bars: null };
      const adjusted = Math.abs(best.start - rawStart) > 0.04 || Math.abs(best.end - rawEnd) > 0.04;
      return {
        start: best.start,
        end: best.end,
        bars: best.bars,
        bpm,
        adjusted,
        source: 'bpm_fallback',
        label: adjusted
          ? `Takt-Schnitt: ${secondsToClock(rawStart, true)} – ${secondsToClock(rawEnd, true)} → ${secondsToClock(best.start, true)} – ${secondsToClock(best.end, true)}${best.bars ? ` (${best.bars} Takte` : ''}${bpm ? `, ${Math.round(bpm * 10) / 10} BPM` : ''}${best.bars ? ')' : ''}`
          : '',
      };
    };
    const extractRangeClipParts = (rangeStart, rangeEnd, insertAt, sectionLabel) => {
      const pieces = [];
      (base.clips || []).forEach((clip) => {
        if (clip.locked) return;
        const clipStart = safeNumber(clip.timeline_start);
        const clipEnd = clipStart + clipDuration(clip);
        const overlapStart = Math.max(rangeStart, clipStart);
        const overlapEnd = Math.min(rangeEnd, clipEnd);
        if (overlapEnd - overlapStart <= 0.05) return;
        pieces.push({
          ...clip,
          id: makeId('clip'),
          timeline_start: insertAt + (overlapStart - rangeStart),
          source_start: safeNumber(clip.source_start) + (overlapStart - clipStart),
          source_end: safeNumber(clip.source_start) + (overlapEnd - clipStart),
          label: `${sectionLabel} Kopie`,
          locked: false,
        });
      });
      if (!pieces.length && sourceDuration >= rangeEnd) {
        pieces.push({
          id: makeId('clip'),
          track_id: 'track-1',
          source_audio_id: Number(currentAsset?.id || base.source_audio_id || 0),
          timeline_start: insertAt,
          source_start: rangeStart,
          source_end: rangeEnd,
          gain_db: 0,
          fade_in: 0,
          fade_out: 0,
          label: `${sectionLabel} Kopie`,
          muted: false,
          locked: false,
          color: 'cyan',
        });
      }
      return pieces.sort((a, b) => safeNumber(a.timeline_start) - safeNumber(b.timeline_start));
    };
    const insertTimelineGap = (insertAt, gapLength) => {
      const minLength = 0.25;
      const nextClips = [];
      (next.clips || []).forEach((clip) => {
        if (clip.locked) {
          nextClips.push(clip);
          return;
        }
        const start = safeNumber(clip.timeline_start);
        const end = start + clipDuration(clip);
        if (end <= insertAt + 0.001) {
          nextClips.push(clip);
          return;
        }
        if (start >= insertAt - 0.001) {
          nextClips.push({ ...clip, timeline_start: start + gapLength });
          return;
        }
        const leftLength = insertAt - start;
        const rightLength = end - insertAt;
        if (leftLength >= minLength) {
          nextClips.push({ ...clip, id: makeId('clip'), source_end: safeNumber(clip.source_start) + leftLength });
        }
        if (rightLength >= minLength) {
          nextClips.push({
            ...clip,
            id: makeId('clip'),
            timeline_start: insertAt + gapLength,
            source_start: safeNumber(clip.source_start) + leftLength,
          });
        }
      });
      next.clips = nextClips;
      next.markers = (next.markers || []).map((marker) => safeNumber(marker.time) >= insertAt ? { ...marker, time: safeNumber(marker.time) + gapLength } : marker);
    };

    if (commandType === 'clip_split') {
      const splitTime = snapTime(command.time ?? currentTime);
      const target = findClipAt(splitTime, selectedId);
      if (!target || target.locked) throw new Error('Kein Clip am Schnittpunkt gefunden.');
      const offset = splitTime - safeNumber(target.timeline_start);
      const length = clipDuration(target);
      if (offset <= 0.05 || offset >= length - 0.05) throw new Error('Schnittpunkt liegt zu nah am Clip-Rand.');
      const left = { ...target, id: makeId('clip'), source_end: safeNumber(target.source_start) + offset };
      const right = { ...target, id: makeId('clip'), timeline_start: splitTime, source_start: safeNumber(target.source_start) + offset };
      next.clips = next.clips.flatMap((clip) => clip.id === target.id ? [left, right] : [clip]);
      nextSelectedClipId = right.id;
      guideTime = splitTime;
      guideLabel = 'Schnittpunkt';
      title = 'Clip schneiden';
      summary = `Clip „${target.label || 'Clip'}“ wird bei ${secondsToClock(splitTime, true)} in zwei Clips geteilt.`;
      actions.push(`Schnitt bei ${secondsToClock(splitTime, true)} setzen`);
      actions.push('Linken und rechten Clip erzeugen');
      markArrangementChanged();
    } else if (commandType === 'clip_duplicate') {
      const target = findClipById(selectedId);
      if (!target) throw new Error('Bitte zuerst einen Clip auswählen.');
      const duration = clipDuration(target);
      const copy = { ...target, id: makeId('clip'), timeline_start: safeNumber(target.timeline_start) + duration, label: `${target.label || 'Clip'} Kopie` };
      next.clips.push(copy);
      nextSelectedClipId = copy.id;
      guideTime = copy.timeline_start;
      guideLabel = 'Duplikat';
      title = 'Clip duplizieren';
      summary = `Clip „${target.label || 'Clip'}“ wird direkt hinter dem Original eingefügt.`;
      actions.push(`Duplikat ab ${secondsToClock(copy.timeline_start, true)} erstellen`);
      actions.push(`Länge ${secondsToClock(duration, true)} übernehmen`);
      markArrangementChanged();
    } else if (commandType === 'clip_delete') {
      const target = findClipById(selectedId);
      if (!target) throw new Error('Bitte zuerst einen Clip auswählen.');
      next.clips = next.clips.filter((clip) => clip.id !== target.id);
      nextSelectedClipId = '';
      title = 'Clip löschen';
      summary = `Clip „${target.label || 'Clip'}“ wird aus dem Arrangement entfernt.`;
      actions.push('Clip aus der Timeline entfernen');
      actions.push('Original-Audio bleibt unverändert');
      markArrangementChanged();
    } else if (commandType === 'clip_gain') {
      const target = findClipById(selectedId);
      if (!target) throw new Error('Bitte zuerst einen Clip auswählen.');
      const currentGain = safeNumber(target.gain_db);
      const nextGain = Number.isFinite(Number(command.gainDb))
        ? clamp(Number(command.gainDb), -24, 24)
        : clamp(currentGain + safeNumber(command.gainDelta), -24, 24);
      next.clips = next.clips.map((clip) => clip.id === target.id ? { ...clip, gain_db: nextGain } : clip);
      nextSelectedClipId = target.id;
      guideTime = safeNumber(target.timeline_start);
      guideLabel = 'Clip-Pegel';
      title = 'Clip-Pegel ändern';
      summary = `Clip „${target.label || 'Clip'}“ wird von ${currentGain} dB auf ${nextGain} dB gesetzt.`;
      actions.push(`Gain ${currentGain} dB → ${nextGain} dB`);
      actions.push('Änderung betrifft nur diesen Timeline-Clip');
      markArrangementChanged();
    } else if (commandType === 'clip_fade') {
      const target = findClipById(selectedId);
      if (!target) throw new Error('Bitte zuerst einen Clip auswählen.');
      const duration = clipDuration(target);
      const fadeSeconds = clamp(safeNumber(command.seconds, 2), 0, Math.max(0.1, duration / 2));
      const edge = command.edge === 'out' ? 'out' : command.edge === 'both' ? 'both' : 'in';
      next.clips = next.clips.map((clip) => {
        if (clip.id !== target.id) return clip;
        if (edge === 'both') return { ...clip, fade_in: fadeSeconds, fade_out: fadeSeconds };
        return edge === 'out' ? { ...clip, fade_out: fadeSeconds } : { ...clip, fade_in: fadeSeconds };
      });
      nextSelectedClipId = target.id;
      guideTime = edge === 'out' ? safeNumber(target.timeline_start) + duration - fadeSeconds : safeNumber(target.timeline_start);
      guideLabel = edge === 'out' ? 'Fade-out' : edge === 'both' ? 'Fade' : 'Fade-in';
      title = edge === 'out' ? 'Fade-out setzen' : edge === 'both' ? 'Fade setzen' : 'Fade-in setzen';
      summary = `Clip „${target.label || 'Clip'}“ bekommt ${edge === 'both' ? 'Fade-in und Fade-out' : edge === 'out' ? 'einen Fade-out' : 'einen Fade-in'} von ${secondsToClock(fadeSeconds, true)}.`;
      actions.push(`${edge === 'both' ? 'Fade-in/Fade-out' : edge === 'out' ? 'Fade-out' : 'Fade-in'} auf ${secondsToClock(fadeSeconds, true)} setzen`);
      actions.push('Änderung betrifft nur diesen Timeline-Clip');
      markArrangementChanged();
    } else if (commandType === 'clip_trim') {
      const target = findClipById(selectedId);
      if (!target) throw new Error('Bitte zuerst einen Clip auswählen.');
      const duration = clipDuration(target);
      const amount = clamp(safeNumber(command.seconds, 2), 0.05, Math.max(0.05, duration - 0.25));
      const edge = command.edge === 'start' ? 'start' : 'end';
      if (duration - amount < 0.25) throw new Error('Der Clip wäre nach dem Kürzen zu kurz.');
      next.clips = next.clips.map((clip) => {
        if (clip.id !== target.id) return clip;
        if (edge === 'start') return { ...clip, source_start: safeNumber(clip.source_start) + amount };
        return { ...clip, source_end: Math.max(safeNumber(clip.source_start) + 0.25, safeNumber(clip.source_end) - amount) };
      });
      nextSelectedClipId = target.id;
      guideTime = edge === 'start' ? safeNumber(target.timeline_start) : safeNumber(target.timeline_start) + duration - amount;
      guideLabel = edge === 'start' ? 'Clip-Anfang gekürzt' : 'Clip-Ende gekürzt';
      title = edge === 'start' ? 'Clip-Anfang kürzen' : 'Clip-Ende kürzen';
      summary = `Clip „${target.label || 'Clip'}“ wird am ${edge === 'start' ? 'Anfang' : 'Ende'} um ${secondsToClock(amount, true)} gekürzt.`;
      actions.push(`${edge === 'start' ? 'Quelle-Start' : 'Quelle-Ende'} um ${secondsToClock(amount, true)} verschieben`);
      actions.push(`Neue Länge ca. ${secondsToClock(duration - amount, true)}`);
      markArrangementChanged();
    } else if (commandType === 'range_delete') {
      const range = command.range || selection;
      if (!range || safeNumber(range.end) - safeNumber(range.start) <= 0.05) throw new Error('Bitte zuerst einen Bereich in der Timeline markieren.');
      const cutStart = snapTime(range.start);
      const cutEnd = snapTime(range.end);
      const cutLength = cutEnd - cutStart;
      const shouldCloseGap = command.closeGap ?? closeGap;
      const nextClips = [];
      for (const clip of next.clips) {
        if (clip.locked) {
          nextClips.push(clip);
          continue;
        }
        const start = safeNumber(clip.timeline_start);
        const end = start + clipDuration(clip);
        if (end <= cutStart || start >= cutEnd) {
          nextClips.push(shouldCloseGap && start >= cutEnd ? { ...clip, timeline_start: Math.max(0, start - cutLength) } : clip);
          continue;
        }
        if (start < cutStart) {
          nextClips.push({ ...clip, id: makeId('clip'), source_end: safeNumber(clip.source_start) + (cutStart - start) });
        }
        if (end > cutEnd) {
          const rightSourceStart = safeNumber(clip.source_start) + (cutEnd - start);
          nextClips.push({
            ...clip,
            id: makeId('clip'),
            timeline_start: shouldCloseGap ? cutStart : cutEnd,
            source_start: rightSourceStart,
          });
        }
      }
      next.clips = nextClips;
      next.markers = (next.markers || [])
        .filter((marker) => marker.time < cutStart || marker.time > cutEnd)
        .map((marker) => shouldCloseGap && marker.time >= cutEnd ? { ...marker, time: Math.max(0, marker.time - cutLength) } : marker);
      nextSelection = null;
      nextSelectedClipId = '';
      guideTime = cutStart;
      guideLabel = shouldCloseGap ? 'Bereich entfernt · Lücke geschlossen' : 'Bereich entfernt';
      title = shouldCloseGap ? 'Bereich entfernen und Lücke schließen' : 'Bereich entfernen';
      summary = `Bereich ${secondsToClock(cutStart, true)} – ${secondsToClock(cutEnd, true)} wird entfernt.`;
      actions.push(`Bereichslänge ${secondsToClock(cutLength, true)} entfernen`);
      if (shouldCloseGap) actions.push('Nachfolgende Clips und Marker nach links verschieben');
      else actions.push('Lücke in der Timeline bestehen lassen');
      markArrangementChanged();
    } else if (commandType === 'clip_align_to_playhead') {
      const target = findClipById(selectedId);
      if (!target) throw new Error('Bitte zuerst einen Clip auswählen.');
      const duration = clipDuration(target);
      const edge = command.edge === 'end' ? 'end' : 'start';
      const rawStart = edge === 'end' ? currentTime - duration : currentTime;
      const nextStart = clamp(snapTime(rawStart), 0, Math.max(0, beforeDuration - duration));
      next.clips = next.clips.map((clip) => clip.id === target.id ? { ...clip, timeline_start: nextStart } : clip);
      nextSelectedClipId = target.id;
      guideTime = edge === 'end' ? nextStart + duration : nextStart;
      guideLabel = edge === 'end' ? 'Clip-Ende an Playhead' : 'Clip-Start an Playhead';
      title = edge === 'end' ? 'Clip-Ende an Playhead' : 'Clip-Start an Playhead';
      summary = `Clip „${target.label || 'Clip'}“ wird an den aktuellen Playhead gesetzt.`;
      actions.push(`Neue Position ${secondsToClock(nextStart, true)}`);
      actions.push(`Playhead ${secondsToClock(currentTime, true)} als Bezugspunkt verwenden`);
      markArrangementChanged();
    } else if (commandType === 'clip_attach_adjacent') {
      const target = findClipById(selectedId);
      if (!target) throw new Error('Bitte zuerst einen Clip auswählen.');
      const direction = command.direction === 'next' ? 'next' : 'previous';
      const adjacent = adjacentFor(target, direction);
      if (!adjacent) throw new Error(direction === 'previous' ? 'Kein vorheriger Clip auf derselben Spur gefunden.' : 'Kein nächster Clip auf derselben Spur gefunden.');
      const duration = clipDuration(target);
      const nextStart = direction === 'previous' ? adjacent.candidateEnd : Math.max(0, adjacent.candidateStart - duration);
      next.clips = next.clips.map((clip) => clip.id === target.id ? { ...clip, timeline_start: nextStart } : clip);
      nextSelectedClipId = target.id;
      guideTime = direction === 'previous' ? nextStart : nextStart + duration;
      guideLabel = direction === 'previous' ? 'An vorherigen Clip' : 'An nächsten Clip';
      title = direction === 'previous' ? 'An Vorgänger anschließen' : 'An Nächsten anschließen';
      summary = `Clip „${target.label || 'Clip'}“ wird ohne Lücke an „${adjacent.label || 'Clip'}“ angelegt.`;
      actions.push(`Neue Position ${secondsToClock(nextStart, true)}`);
      actions.push('Nur Clips derselben Spur werden als Nachbarn genutzt');
      markArrangementChanged();
    } else if (commandType === 'section_duplicate' || commandType === 'section_append_to_end') {
      const section = resolveCommandSection();
      const musicalRange = resolveMusicalSectionRange(section);
      const rangeStart = musicalRange.start;
      const rangeEnd = musicalRange.end;
      const rangeLength = rangeEnd - rangeStart;
      const appendToEnd = commandType === 'section_append_to_end' || command.target === 'end';
      const insertAt = appendToEnd ? arrangementLength(base, beforeDuration) : rangeEnd;
      let copies = [];
      const sourceLimit = sourceDuration || safeNumber(currentAsset?.duration_seconds) || beforeDuration;
      if (sourceLimit >= rangeEnd - 0.05) {
        copies = [{
          id: makeId('clip'),
          track_id: 'track-1',
          source_audio_id: Number(currentAsset?.id || base.source_audio_id || 0),
          timeline_start: insertAt,
          source_start: rangeStart,
          source_end: rangeEnd,
          gain_db: 0,
          fade_in: 0,
          fade_out: 0,
          label: `${section.displayLabel} Kopie`,
          muted: false,
          locked: false,
          color: 'cyan',
        }];
      } else {
        copies = extractRangeClipParts(rangeStart, rangeEnd, insertAt, section.displayLabel);
      }
      if (!copies.length) throw new Error('Für diesen Abschnitt konnten keine passenden Audioclips ermittelt werden.');
      if (!appendToEnd) insertTimelineGap(insertAt, rangeLength);
      next.clips = [...(next.clips || []), ...copies].sort((a, b) => safeNumber(a.timeline_start) - safeNumber(b.timeline_start));
      nextSelectedClipId = copies[0]?.id || '';
      nextSelection = { start: insertAt, end: insertAt + rangeLength };
      guideTime = insertAt;
      guideLabel = appendToEnd ? `${section.displayLabel} ans Ende` : `${section.displayLabel} doppelt`;
      title = appendToEnd ? 'Abschnitt ans Ende hängen' : 'Abschnitt duplizieren';
      summary = appendToEnd
        ? `Abschnitt „${section.displayLabel}“ wird an das Ende des Arrangements gehängt.`
        : `Abschnitt „${section.displayLabel}“ wird direkt hinter dem Original eingefügt.`;
      actions.push(`${section.displayLabel}: ${secondsToClock(rangeStart, true)} – ${secondsToClock(rangeEnd, true)} verwenden`);
      if (musicalRange.label) actions.push(musicalRange.label);
      actions.push(`${copies.length} Audio-Teil${copies.length === 1 ? '' : 'e'} als neue Clip-Kopie erzeugen`);
      if (!appendToEnd) actions.push('Nachfolgende Clips bei Bedarf nach rechts verschieben');
      else actions.push(`Einfügen am Arrangement-Ende bei ${secondsToClock(insertAt, true)}`);
      if (copies.length > 1) warnings.push('Der Abschnitt liegt über mehreren Clips und wird als mehrere Teilclips eingefügt.');
      if (musicalRange.source === 'raw') warnings.push('Keine Beat-/Bar-Map gefunden; Abschnittsgrenzen werden unverändert verwendet.');
      markArrangementChanged();
    } else if (commandType === 'section_delete') {
      const section = resolveCommandSection();
      const musicalRange = resolveMusicalSectionRange(section);
      const cutStart = musicalRange.start;
      const cutEnd = musicalRange.end;
      const cutLength = cutEnd - cutStart;
      const shouldCloseGap = command.closeGap ?? closeGap;
      const nextClips = [];
      for (const clip of next.clips) {
        if (clip.locked) {
          nextClips.push(clip);
          continue;
        }
        const start = safeNumber(clip.timeline_start);
        const end = start + clipDuration(clip);
        if (end <= cutStart || start >= cutEnd) {
          nextClips.push(shouldCloseGap && start >= cutEnd ? { ...clip, timeline_start: Math.max(0, start - cutLength) } : clip);
          continue;
        }
        if (start < cutStart) {
          nextClips.push({ ...clip, id: makeId('clip'), source_end: safeNumber(clip.source_start) + (cutStart - start) });
        }
        if (end > cutEnd) {
          const rightSourceStart = safeNumber(clip.source_start) + (cutEnd - start);
          nextClips.push({
            ...clip,
            id: makeId('clip'),
            timeline_start: shouldCloseGap ? cutStart : cutEnd,
            source_start: rightSourceStart,
          });
        }
      }
      next.clips = nextClips;
      next.markers = (next.markers || [])
        .filter((marker) => marker.time < cutStart || marker.time > cutEnd)
        .map((marker) => shouldCloseGap && marker.time >= cutEnd ? { ...marker, time: Math.max(0, marker.time - cutLength) } : marker);
      nextSelection = null;
      nextSelectedClipId = '';
      guideTime = cutStart;
      guideLabel = shouldCloseGap ? `${section.displayLabel} entfernt` : `${section.displayLabel} ausgeschnitten`;
      title = 'Abschnitt entfernen';
      summary = `Abschnitt „${section.displayLabel}“ wird aus dem Arrangement entfernt.`;
      actions.push(`${section.displayLabel}: ${secondsToClock(cutStart, true)} – ${secondsToClock(cutEnd, true)} entfernen`);
      if (musicalRange.label) actions.push(musicalRange.label);
      if (musicalRange.source === 'raw') warnings.push('Keine Beat-/Bar-Map gefunden; Abschnittsgrenzen werden unverändert verwendet.');
      if (shouldCloseGap) actions.push('Nachfolgende Clips und Marker nach links verschieben');
      else actions.push('Lücke in der Timeline bestehen lassen');
      markArrangementChanged();
    } else if (commandType === 'gap_close') {
      const trackIds = TRACKS.map((track) => track.id);
      let moved = 0;
      next.clips = next.clips.slice();
      trackIds.forEach((trackId) => {
        let cursor = 0;
        next.clips
          .filter((clip) => clip.track_id === trackId && !clip.locked)
          .sort((a, b) => safeNumber(a.timeline_start) - safeNumber(b.timeline_start))
          .forEach((clip) => {
            const start = safeNumber(clip.timeline_start);
            const duration = clipDuration(clip);
            if (start > cursor + 0.02) {
              clip.timeline_start = cursor;
              moved += 1;
            }
            cursor = Math.max(cursor, clip.timeline_start + duration);
          });
      });
      if (!moved) warnings.push('Es wurden keine relevanten Lücken zwischen Clips gefunden.');
      title = 'Alle Lücken schließen';
      summary = 'Alle nicht gesperrten Clips werden pro Spur nach links zusammengeschoben.';
      actions.push(`${moved} Clip${moved === 1 ? '' : 's'} verschieben`);
      actions.push('Spuren bleiben getrennt');
      markArrangementChanged();
    } else {
      throw new Error('Unbekanntes DAW-Kommando.');
    }

    if (command.aiPrompt) {
      title = `KI: ${title}`;
      actions.unshift(`KI-Befehl: „${command.aiPrompt}“`);
      if (command.aiInterpretation) actions.unshift(`Interpretation: ${command.aiInterpretation}`);
    }

    const normalizedNext = normalizeArrangement(next, currentAsset, arrangementLength(next, beforeDuration));
    const afterDuration = arrangementLength(normalizedNext, beforeDuration);
    return {
      id: makeId('daw-command'),
      command,
      aiPrompt: command.aiPrompt || '',
      aiInterpretation: command.aiInterpretation || '',
      aiSource: command.aiSource || '',
      section: command.section || resolvedSections.find((item) => item.id === command.sectionId) || null,
      title,
      summary,
      actions,
      warnings,
      beforeDuration,
      afterDuration,
      affectedClips: Math.max(0, Math.abs((normalizedNext.clips || []).length - (base.clips || []).length)) || 1,
      originalArrangement: original,
      nextArrangement: normalizedNext,
      nextSelectedClipId,
      nextSelection,
      guideTime,
      guideLabel,
    };
  }

  function openDawCommandPreview(command) {
    try {
      const plan = createDawCommandPlan(command);
      setCommandPreview(plan);
    } catch (err) {
      notify?.(err.message || 'DAW-Kommando konnte nicht vorbereitet werden.', 'error');
    }
  }

  function applyDawCommandPlan(plan = commandPreview) {
    if (!plan?.nextArrangement) return;
    commitArrangementHistory(plan.originalArrangement || arrangementRef.current);
    const normalized = normalizeArrangement(plan.nextArrangement, currentAsset, plan.afterDuration || timelineDurationRef.current || mediaDuration || currentAsset?.duration_seconds || 1);
    setArrangement(normalized);
    arrangementRef.current = normalized;
    setSelectedClipId(plan.nextSelectedClipId && normalized.clips.some((clip) => clip.id === plan.nextSelectedClipId) ? plan.nextSelectedClipId : (normalized.clips[0]?.id || ''));
    setSelection(plan.nextSelection || null);
    setCommandPreview(null);
    setPreviewSignature('');
    if (arrangementNeedsRenderedPlayback(normalized, sourceDuration || currentAsset?.duration_seconds || mediaDuration || 0)) {
      window.setTimeout(() => {
        buildArrangementPreview({ arrangementPayload: normalized, silent: true }).catch(() => null);
      }, 0);
    }
    if (Number.isFinite(plan.guideTime)) {
      showTimelineSnapGuide(plan.guideTime, plan.guideLabel || 'Kommando angewendet');
      window.setTimeout(hideTimelineSnapGuide, 950);
    }
    notify?.(`${plan.title} angewendet.`, 'success');
  }

  const selectAsset = useCallback((nextAssetId, options = {}) => {
    const normalized = String(nextAssetId || '').trim();
    setAssetId(normalized);
    setProject(null);
    setArrangement(null);
    setBeatgrid(null);
    setBeatgridLoading(false);
    setSelectedClipId('');
    setSelectedSectionId('');
    setMediaDuration(0);
    setSelection(null);
    setUndoStack([]);
    setRedoStack([]);
    setCurrentTime(0);
    currentTimeRef.current = 0;
    setPreviewSignature('');
    setPreviewUrl((current) => { if (current) URL.revokeObjectURL(current); return ''; });
    if (normalized) {
      localStorage.setItem('react-daw-asset-id', normalized);
      setLastKnownAssetId(normalized);
    }
    if (options.notifyParent !== false) onAssetChange?.(normalized);
  }, [onAssetChange]);

  useEffect(() => {
    const normalized = String(selectedAssetId || '').trim();
    if (normalized === String(assetId || '').trim()) {
      onSelectedHandled?.();
      return;
    }
    selectAsset(normalized, { notifyParent: false });
    onSelectedHandled?.();
  }, [selectedAssetId, assetId, selectAsset, onSelectedHandled]);

  useEffect(() => {
    if (!assetId) return;
    setLoading(true);
    Promise.all([api.daw.project(assetId), api.daw.getArrangement(assetId)])
      .then(([projectResult, arrangementResult]) => {
        setProject(projectResult);
        const asset = projectResult?.asset || playable.find((item) => String(item.id) === String(assetId));
        const nextArrangement = normalizeArrangement(arrangementResult?.arrangement, asset, asset?.duration_seconds || 1);
        setArrangement(nextArrangement);
        setSelectedClipId(nextArrangement.clips?.[0]?.id || '');
        setVersionLabel('DAW Arrangement');
        setPreviewSignature('');
        setPreviewUrl((current) => { if (current) URL.revokeObjectURL(current); return ''; });
      })
      .catch((err) => notify?.(err.message || 'DAW-Projekt konnte nicht geladen werden.', 'error'))
      .finally(() => setLoading(false));
  }, [assetId]);


  useEffect(() => {
    if (!assetId) {
      setBeatgrid(null);
      setBeatgridLoading(false);
      return undefined;
    }
    let cancelled = false;
    setBeatgrid(null);
    setBeatgridLoading(true);
    api.daw.getBeatgrid(assetId)
      .then((result) => {
        if (cancelled) return;
        const grid = result?.beatgrid || result;
        setBeatgrid(grid && typeof grid === 'object' ? grid : { ok: false, status: 'failed' });
      })
      .catch((err) => {
        if (!cancelled) setBeatgrid({ ok: false, status: 'failed', message: err?.message || 'Beatgrid fehlgeschlagen' });
      })
      .finally(() => { if (!cancelled) setBeatgridLoading(false); });
    return () => { cancelled = true; };
  }, [assetId]);

  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  const rebuildBeatgrid = useCallback(async () => {
    if (!assetId) return;
    setBeatgridLoading(true);
    try {
      const result = await api.daw.rebuildBeatgrid(assetId);
      const grid = result?.beatgrid || result;
      setBeatgrid(grid && typeof grid === 'object' ? grid : { ok: false, status: 'failed' });
      if (grid?.ok) {
        notify?.(`Bar-Map analysiert: ${grid.summary || `${grid.bars?.length || 0} Takte`}`, 'success');
      } else {
        notify?.(grid?.message || 'Bar-Map konnte nicht erstellt werden.', 'warning');
      }
    } catch (err) {
      setBeatgrid({ ok: false, status: 'failed', message: err?.message || 'Beatgrid fehlgeschlagen' });
      notify?.(err?.message || 'Bar-Map-Analyse fehlgeschlagen.', 'error');
    } finally {
      setBeatgridLoading(false);
    }
  }, [assetId, notify]);

  const dragState = usePointerDrag(
    (event, state) => {
      if (!arrangement) return;
      const nextTime = timeFromPointer(event);
      if (state.kind === 'range') {
        const nextSelection = { start: Math.min(state.start, nextTime), end: Math.max(state.start, nextTime) };
        setSelection(nextSelection);
        showDragTimeTooltip(event, {
          mode: 'range',
          title: 'Bereich',
          rows: [
            `Start ${secondsToClock(nextSelection.start, true)}`,
            `Ende ${secondsToClock(nextSelection.end, true)}`,
            `Länge ${secondsToClock(nextSelection.end - nextSelection.start, true)}`,
          ],
        });
        return;
      }
      if (state.kind === 'playhead') {
        seekTo(nextTime);
        showDragTimeTooltip(event, { mode: 'playhead', title: 'Playhead', rows: [secondsToClock(nextTime, true)] });
        return;
      }
      if (state.kind === 'move') {
        state.moved = true;
        const delta = secondsFromPixels(event.clientX - state.startClientX);
        const nextTrackId = trackIdFromClientY(event.clientY, state.originalTrackId);
        const placement = snapClipPlacement(Math.max(0, state.originalStart + delta), {
          excludeClipId: state.clipId,
          trackId: nextTrackId,
          duration: state.originalDuration,
        });
        const nextStart = placement.start;
        if (placement.snappedToClip) showTimelineSnapGuide(nextStart, placement.label || 'Audio an Audio');
        else hideTimelineSnapGuide();
        showDragTimeTooltip(event, {
          mode: placement.snappedToClip ? 'snap' : 'move',
          title: placement.snappedToClip ? 'Audio an Audio eingerastet' : 'Clip verschieben',
          rows: [
            `Position ${secondsToClock(nextStart, true)}`,
            `Spur ${nextTrackId.replace('track-', '')}`,
            ...(placement.snappedToClip ? [placement.label] : []),
          ],
        });
        updateArrangement((current) => ({
          ...current,
          clips: current.clips.map((clip) => clip.id === state.clipId ? { ...clip, timeline_start: nextStart, track_id: nextTrackId } : clip),
        }));
        return;
      }
      if (state.kind === 'fade') {
        state.moved = true;
        const rawTime = rawTimeFromPointer(event);
        const minGap = 0.05;
        const clipStart = state.originalTimelineStart;
        const clipEnd = state.originalTimelineStart + state.originalDuration;
        const maxFade = Math.max(0, state.originalDuration - minGap);
        let nextFade = 0;
        let patch = null;
        let tooltipPayload = null;

        if (state.edge === 'in') {
          nextFade = clamp(rawTime - clipStart, 0, maxFade);
          const fades = normalizeFadePair(nextFade, state.originalFadeOut, state.originalDuration);
          patch = { fade_in: fades.fadeIn, fade_out: fades.fadeOut };
          tooltipPayload = {
            mode: 'fade',
            title: 'Fade-in',
            rows: [
              `Fade-in ${secondsToClock(fades.fadeIn, true)}`,
              `endet bei ${secondsToClock(clipStart + fades.fadeIn, true)}`,
              `Clip-Länge ${secondsToClock(state.originalDuration, true)}`,
            ],
          };
        } else {
          nextFade = clamp(clipEnd - rawTime, 0, maxFade);
          const fades = normalizeFadePair(state.originalFadeIn, nextFade, state.originalDuration);
          patch = { fade_in: fades.fadeIn, fade_out: fades.fadeOut };
          tooltipPayload = {
            mode: 'fade',
            title: 'Fade-out',
            rows: [
              `Fade-out ${secondsToClock(fades.fadeOut, true)}`,
              `startet bei ${secondsToClock(clipEnd - fades.fadeOut, true)}`,
              `Clip-Ende ${secondsToClock(clipEnd, true)}`,
            ],
          };
        }

        showDragTimeTooltip(event, tooltipPayload);
        updateArrangement((current) => ({
          ...current,
          clips: current.clips.map((clip) => clip.id === state.clipId ? { ...clip, ...patch } : clip),
        }));
        return;
      }
      if (state.kind === 'resize') {
        state.moved = true;
        const delta = secondsFromPixels(event.clientX - state.startClientX);
        const minLength = 0.25;
        const sourceLimit = Math.max(minLength, state.sourceDuration || state.originalSourceEnd);
        let clipPatch = null;
        let tooltipPayload = null;

        if (state.edge === 'left') {
          const maxPositive = Math.max(0, state.originalDuration - minLength);
          const minNegative = -Math.min(state.originalSourceStart, state.originalTimelineStart);
          const rawTimelineStart = Math.max(0, state.originalTimelineStart + delta);
          const snappedPoint = snapTimelinePoint(rawTimelineStart, { excludeClipId: state.clipId, trackId: state.originalTrackId });
          const snappedDelta = snappedPoint.value - state.originalTimelineStart;
          const limitedDelta = clamp(snappedDelta, minNegative, maxPositive);
          const nextTimelineStart = Math.max(0, state.originalTimelineStart + limitedDelta);
          const nextSourceStart = clamp(state.originalSourceStart + limitedDelta, 0, Math.max(0, sourceLimit - minLength));
          const nextLength = Math.max(minLength, state.originalSourceEnd - nextSourceStart);
          if (snappedPoint.snappedToClip) showTimelineSnapGuide(nextTimelineStart, snappedPoint.label || 'Audio an Audio');
          else hideTimelineSnapGuide();
          clipPatch = {
            timeline_start: nextTimelineStart,
            source_start: nextSourceStart,
            source_end: state.originalSourceEnd,
          };
          tooltipPayload = {
            mode: 'trim',
            title: 'Linke Kante',
            rows: [
              `Start ${secondsToClock(nextTimelineStart, true)}`,
              `Quelle ${secondsToClock(nextSourceStart, true)}`,
              `Länge ${secondsToClock(nextLength, true)}`,
              ...(snappedPoint.snappedToClip ? [`Snap ${snappedPoint.label}`] : []),
            ],
          };
        } else {
          const rawDuration = state.originalDuration + delta;
          const snappedEndPoint = snapTimelinePoint(state.originalTimelineStart + rawDuration, { excludeClipId: state.clipId, trackId: state.originalTrackId });
          const snappedDuration = snappedEndPoint.value - state.originalTimelineStart;
          const limitedDuration = clamp(snappedDuration, minLength, Math.max(minLength, sourceLimit - state.originalSourceStart));
          const nextSourceEnd = state.originalSourceStart + limitedDuration;
          const nextTimelineEnd = state.originalTimelineStart + limitedDuration;
          if (snappedEndPoint.snappedToClip) showTimelineSnapGuide(nextTimelineEnd, snappedEndPoint.label || 'Audio an Audio');
          else hideTimelineSnapGuide();
          clipPatch = { source_end: nextSourceEnd };
          tooltipPayload = {
            mode: 'trim',
            title: 'Rechte Kante',
            rows: [
              `Ende ${secondsToClock(nextTimelineEnd, true)}`,
              `Quelle ${secondsToClock(nextSourceEnd, true)}`,
              `Länge ${secondsToClock(limitedDuration, true)}`,
              ...(snappedEndPoint.snappedToClip ? [`Snap ${snappedEndPoint.label}`] : []),
            ],
          };
        }

        // Tooltip-Werte werden bewusst vor dem React-State-Update berechnet.
        // Sonst bleibt bei gebatchten setState-Aufrufen nur der Wert vom PointerDown sichtbar.
        showDragTimeTooltip(event, tooltipPayload);
        updateArrangement((current) => ({
          ...current,
          clips: current.clips.map((clip) => clip.id === state.clipId ? { ...clip, ...clipPatch } : clip),
        }));
      }
    },
    (event, state) => {
      if (state.kind === 'range') {
        const nextTime = timeFromPointer(event);
        const nextSelection = { start: Math.min(state.start, nextTime), end: Math.max(state.start, nextTime) };
        if (nextSelection.end - nextSelection.start < 0.1) setSelection(null);
        else setSelection(nextSelection);
      }
      if ((state.kind === 'move' || state.kind === 'resize' || state.kind === 'fade') && state.clipId) {
        setSelectedClipId(state.clipId);
        if (state.moved) commitArrangementHistory(state.originalArrangement);
      }
      hideDragTimeTooltip();
      hideTimelineSnapGuide();
    }
  );

  function handleDurationDetected(event) {
    const duration = safeNumber(event.currentTarget?.duration, 0);
    if (duration > 0) {
      setMediaDuration(duration);
      setArrangement((current) => current ? normalizeArrangement({ ...current, duration_seconds: Math.max(current.duration_seconds || 0, duration) }, currentAsset, duration) : current);
    }
  }

  function seekTo(time) {
    const next = snapTime(time);
    setCurrentTime(next);
    currentTimeRef.current = next;
    const audio = audioRef.current;
    if (!audio) return;
    const nativeDuration = safeNumber(audio.duration, 0);
    if (usingRenderedPlayback || !nativeDuration || next <= nativeDuration + 0.05) {
      audio.currentTime = nativeDuration > 0 ? clamp(next, 0, Math.max(nativeDuration, next)) : next;
    } else {
      audio.currentTime = nativeDuration;
    }
  }

  async function togglePlayback() {
    if (!audioRef.current) return;
    try {
      if (audioRef.current.paused) {
        if (needsRenderedPlayback && !previewMatchesArrangement) {
          await buildArrangementPreview({ autoplay: true, successMessage: 'Timeline-Vorschau erstellt. Arrangement wird abgespielt.' });
          return;
        }
        audioRef.current.volume = volume;
        audioRef.current.currentTime = clamp(currentTimeRef.current, 0, timelineDurationRef.current || timelineDuration || 1);
        await audioRef.current.play();
        setIsPlaying(true);
      } else {
        audioRef.current.pause();
        setIsPlaying(false);
      }
    } catch {
      setIsPlaying(false);
    }
  }

  function addMarkerAt(time = currentTime, options = {}) {
    const nextTime = snapTime(time);
    const markerType = options.type || 'marker';
    const explicitLabel = options.label ? String(options.label) : '';
    const existingMarkers = arrangementRef.current?.markers || [];
    let label = explicitLabel;

    if (markerType === 'jump' && !label) {
      const used = new Set(existingMarkers
        .filter((marker) => String(marker?.type || '').toLowerCase() === 'jump')
        .map((marker) => String(marker?.label || '')));
      label = JUMP_MARKER_LABELS.find((candidate) => !used.has(candidate)) || '';
      if (!label) {
        notify?.('Alle Sprungmarker 1–9 sind bereits belegt.', 'warning');
        return;
      }
    }

    const fallbackLabel = markerType === 'jump'
      ? label
      : `Marker ${existingMarkers.filter((marker) => String(marker?.type || 'marker').toLowerCase() !== 'jump').length + 1}`;

    commitArrangementHistory();
    updateArrangement((current) => ({
      ...current,
      markers: sortMarkers([
        ...(current.markers || []),
        {
          id: makeId(markerType === 'jump' ? 'jump-marker' : 'marker'),
          label: label || fallbackLabel,
          time: nextTime,
          type: markerType,
          note: options.note || null,
        },
      ]),
    }));
    setCurrentTime(nextTime);
    if (markerType === 'jump') notify?.(`Sprungmarker ${label} gesetzt.`, 'success');
  }

  function setRangeBoundary(boundary, time = currentTime) {
    const nextTime = snapTime(time);
    setSelection((current) => {
      const currentStart = safeNumber(current?.start, nextTime);
      const currentEnd = safeNumber(current?.end, currentStart);
      if (boundary === 'start') return { start: nextTime, end: Math.max(nextTime, currentEnd) };
      return { start: Math.min(currentStart, nextTime), end: nextTime };
    });
    setCurrentTime(nextTime);
  }

  function jumpToMarker(label) {
    const marker = (arrangementRef.current?.markers || []).find((item) => String(item?.type || '').toLowerCase() === 'jump' && String(item?.label || '') === String(label));
    if (!marker) {
      notify?.(`Kein Sprungmarker ${label} gesetzt.`, 'warning');
      return;
    }
    seekTo(marker.time);
  }

  function splitClipAt(time = currentTime, clipId = selectedClipId) {
    openDawCommandPreview({ type: 'clip_split', time, clipId });
  }

  function cutRange() {
    openDawCommandPreview({ type: 'range_delete', range: selection, closeGap });
  }

  function duplicateClip() {
    openDawCommandPreview({ type: 'clip_duplicate', clipId: selectedClipIdRef.current });
  }

  function focusSection(sectionId = selectedSectionId, options = {}) {
    const section = resolvedSections.find((item) => item.id === sectionId);
    if (!section) return;
    setSelectedSectionId(section.id);
    setSelection({ start: section.start, end: section.end });
    if (options.seek !== false) seekTo(section.start);
  }

  function runSelectedSectionCommand(type) {
    const section = selectedSection || resolvedSections.find((item) => item.id === selectedSectionId);
    if (!section) {
      notify?.('Keine passende Zeitmarkierung gefunden.', 'warning');
      return;
    }
    openDawCommandPreview({ type, sectionId: section.id, section, closeGap });
  }

  function resolveDawAiSection(kind, occurrence = null, prompt = '') {
    const matches = resolvedSections
      .filter((section) => section.kind === kind)
      .sort((a, b) => safeNumber(a.start) - safeNumber(b.start));
    if (!matches.length) {
      const label = SECTION_KIND_LABELS[kind] || 'Abschnitt';
      throw new Error(`${label} wurde in den vorhandenen Struktursegmenten nicht gefunden.`);
    }
    if (occurrence === 'last') return { section: matches[matches.length - 1], warning: '' };
    if (Number.isFinite(Number(occurrence)) && Number(occurrence) > 0) {
      const section = matches[Number(occurrence) - 1];
      if (!section) throw new Error(`${SECTION_KIND_LABELS[kind] || 'Abschnitt'} ${occurrence} wurde nicht gefunden.`);
      return { section, warning: '' };
    }
    if (selectedSection?.kind === kind) return { section: selectedSection, warning: '' };
    const warning = matches.length > 1
      ? `Mehrere passende Zeitmarken gefunden; ohne genaue Angabe wird ${matches[0].displayLabel} verwendet.`
      : '';
    return { section: matches[0], warning };
  }

  function appendDawAiHistory(role, text, meta = {}) {
    const value = String(text || '').trim();
    if (!value) return;
    setAiCommandHistory((current) => [
      ...current.slice(-7),
      { id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, role, text: value, meta },
    ]);
  }

  function selectedSectionInstructionFallback(text) {
    const section = selectedSection || resolvedSections.find((item) => item.id === selectedSectionId);
    if (!section) return null;
    if (/ausgewaehl|ausgewahl|markiert|songteil|abschnitt|bereich/.test(text)) return section;
    return null;
  }

  function parseDawAiCommand(prompt = aiCommandText, options = {}) {
    const rawPrompt = String(prompt || '').trim();
    const text = normalizeDawAiText(rawPrompt);
    if (!text) throw new Error('Bitte zuerst einen DAW-Befehl eingeben.');
    const contextClipId = options.clipId || selectedClipIdRef.current;
    const isClipContext = Boolean(options.clipId);
    const common = { aiPrompt: truncateDawAiPrompt(rawPrompt), aiSource: options.source || 'local-daw-command-parser' };

    if (/(intro|part|rap\s*part|verse|strophe|bridge|outro|hook|chorus|refrain).*(laenger|langer|verlaenger|erweitern|hinzufueg|hinzufug|fuege|fuge|neu|dritter|dritten|16\s*bars|16\s*takte|sechzehn)/.test(text)) {
      return {
        ...common,
        uiAction: 'needs_generation_workflow',
        aiInterpretation: 'Dieser Wunsch braucht neue Audio-Erzeugung statt nur Timeline-Schnitt. Der Befehl wurde als Planungswunsch erkannt, aber nicht blind angewendet.',
      };
    }

    if (/(luecke|lucke)[n]?\s*(schliessen|schliesse|schliess|entfernen)|alle\s*(luecken|lucken)|gap\s*close/.test(text)) {
      return { ...common, type: 'gap_close', aiInterpretation: 'Alle Timeline-Lücken pro Spur schließen.' };
    }

    if (contextClipId) {
      const requestedSeconds = dawAiSecondsFromText(text, 2);
      const explicitDb = dawAiFirstNumber(text, null);
      if (/(fade\s*in|fadein|einblend|sanft\s*rein)/.test(text)) {
        return { ...common, type: 'clip_fade', clipId: contextClipId, edge: 'in', seconds: requestedSeconds, aiInterpretation: `Fade-in für den gewählten Clip auf ${secondsToClock(requestedSeconds, true)} setzen.` };
      }
      if (/(fade\s*out|fadeout|ausblend|sanft\s*raus)/.test(text)) {
        return { ...common, type: 'clip_fade', clipId: contextClipId, edge: 'out', seconds: requestedSeconds, aiInterpretation: `Fade-out für den gewählten Clip auf ${secondsToClock(requestedSeconds, true)} setzen.` };
      }
      if (/(fade|einblenden|ausblenden)/.test(text)) {
        return { ...common, type: 'clip_fade', clipId: contextClipId, edge: 'both', seconds: requestedSeconds, aiInterpretation: `Fade-in und Fade-out für den gewählten Clip auf ${secondsToClock(requestedSeconds, true)} setzen.` };
      }
      if (/(leiser|senk|reduzier|weniger\s*laut|runter|absenken)/.test(text) && /(laut|volume|gain|pegel|db|dezibel|leiser)/.test(text)) {
        const amount = Math.abs(Number.isFinite(explicitDb) ? explicitDb : 3);
        return { ...common, type: 'clip_gain', clipId: contextClipId, gainDelta: -amount, aiInterpretation: `Gewählten Clip um ${amount} dB leiser machen.` };
      }
      if (/(lauter|erhoeh|erhohe|hoch|mehr\s*laut|boost)/.test(text) && /(laut|volume|gain|pegel|db|dezibel|lauter)/.test(text)) {
        const amount = Math.abs(Number.isFinite(explicitDb) ? explicitDb : 3);
        return { ...common, type: 'clip_gain', clipId: contextClipId, gainDelta: amount, aiInterpretation: `Gewählten Clip um ${amount} dB lauter machen.` };
      }
      if (/(gain|pegel|lautstaerke|lautstarke|volume|db|dezibel)/.test(text) && Number.isFinite(explicitDb)) {
        return { ...common, type: 'clip_gain', clipId: contextClipId, gainDb: explicitDb, aiInterpretation: `Gewählten Clip auf ${explicitDb} dB setzen.` };
      }
      if (/(anfang|start|intro|vorne)/.test(text) && /(kurz|kuerz|trim|abschneid|wegschneid|entfern|weg)/.test(text)) {
        return { ...common, type: 'clip_trim', clipId: contextClipId, edge: 'start', seconds: requestedSeconds, aiInterpretation: `Anfang des gewählten Clips um ${secondsToClock(requestedSeconds, true)} kürzen.` };
      }
      if (/(ende|end|hinten|schluss|outro)/.test(text) && /(kurz|kuerz|trim|abschneid|wegschneid|entfern|weg)/.test(text)) {
        return { ...common, type: 'clip_trim', clipId: contextClipId, edge: 'end', seconds: requestedSeconds, aiInterpretation: `Ende des gewählten Clips um ${secondsToClock(requestedSeconds, true)} kürzen.` };
      }
    }

    const sectionKind = dawAiSectionKindFromText(text);
    if (sectionKind) {
      const occurrence = dawAiOccurrenceFromText(text);
      const { section, warning } = resolveDawAiSection(sectionKind, occurrence, rawPrompt);
      const aiWarnings = warning ? [warning] : [];
      if (/ans?\s*ende|anhaengen|anhaenge|hange|haenge|append|am\s*ende|nach\s*hinten/.test(text)) {
        return { ...common, type: 'section_append_to_end', sectionId: section.id, section, warnings: aiWarnings, aiInterpretation: `${section.displayLabel} ans Arrangement-Ende hängen.` };
      }
      if (/loesch|losch|entfern|wegschneid|schneid.*weg|raus|delete|remove/.test(text)) {
        return { ...common, type: 'section_delete', sectionId: section.id, section, closeGap, warnings: aiWarnings, aiInterpretation: `${section.displayLabel} entfernen${closeGap ? ' und Lücke schließen' : ''}.` };
      }
      if (/doppel|verdoppel|wiederhol|zweimal|2x|nochmal|noch\s*mal|repeat|kopier|copy|setze/.test(text)) {
        return { ...common, type: 'section_duplicate', sectionId: section.id, section, warnings: aiWarnings, aiInterpretation: `${section.displayLabel} direkt hinter dem Original duplizieren.` };
      }
      if (/bereich|markier|waehl|wahl|auswaehl|auswahl/.test(text)) {
        return { ...common, uiAction: 'focus_section', section, aiInterpretation: `${section.displayLabel} als Bereich markieren.` };
      }
      throw new Error('Abschnitt erkannt, aber keine Aktion. Nutze z. B. „doppelt“, „ans Ende“ oder „entfernen“.');
    }

    const fallbackSection = selectedSectionInstructionFallback(text);
    if (fallbackSection) {
      if (/ans?\s*ende|anhaeng|anhang|append|ende/.test(text)) {
        return { ...common, type: 'section_append_to_end', sectionId: fallbackSection.id, section: fallbackSection, aiInterpretation: `${fallbackSection.displayLabel} ans Arrangement-Ende hängen.` };
      }
      if (/loesch|losch|entfern|delete|remove/.test(text)) {
        return { ...common, type: 'section_delete', sectionId: fallbackSection.id, section: fallbackSection, closeGap, aiInterpretation: `${fallbackSection.displayLabel} entfernen${closeGap ? ' und Lücke schließen' : ''}.` };
      }
      if (/doppel|verdoppel|wiederhol|zweimal|2x|nochmal|duplizier|kopier|copy/.test(text)) {
        return { ...common, type: 'section_duplicate', sectionId: fallbackSection.id, section: fallbackSection, aiInterpretation: `${fallbackSection.displayLabel} direkt hinter dem Original duplizieren.` };
      }
      if (/bereich|markier|waehl|wahl|auswaehl|auswahl/.test(text)) {
        return { ...common, uiAction: 'focus_section', section: fallbackSection, aiInterpretation: `${fallbackSection.displayLabel} als Bereich markieren.` };
      }
    }

    if (/bereich/.test(text) && /entfern|loesch|losch|delete|remove/.test(text)) {
      return { ...common, type: 'range_delete', range: selection, closeGap, aiInterpretation: 'Aktuell markierten Bereich entfernen.' };
    }
    if (/30\s*s|30\s*sek|dreissig/.test(text) && /bereich|markier/.test(text)) {
      return { ...common, uiAction: 'range_30', aiInterpretation: 'Ab Playhead einen 30-Sekunden-Bereich markieren.' };
    }
    if (/schneid|schnitt|split|cut/.test(text)) {
      return { ...common, type: 'clip_split', time: currentTime, clipId: contextClipId, aiInterpretation: `Am Playhead ${secondsToClock(currentTime, true)} schneiden.` };
    }
    if (/duplizier|kopier|copy/.test(text) && /clip|audio|markiert/.test(text)) {
      return { ...common, type: 'clip_duplicate', clipId: contextClipId, aiInterpretation: isClipContext ? 'Gewählten Timeline-Clip duplizieren.' : 'Markierten Clip duplizieren.' };
    }
    if (/loesch|losch|entfern|delete|remove/.test(text) && /clip|audio|markiert/.test(text)) {
      return { ...common, type: 'clip_delete', clipId: contextClipId, aiInterpretation: isClipContext ? 'Gewählten Timeline-Clip löschen.' : 'Markierten Clip löschen.' };
    }
    if (/start/.test(text) && /playhead|slider|cursor|abspielkopf/.test(text)) {
      return { ...common, type: 'clip_align_to_playhead', edge: 'start', clipId: contextClipId, aiInterpretation: 'Clip-Start an Playhead ausrichten.' };
    }
    if (/(ende|end)/.test(text) && /playhead|slider|cursor|abspielkopf/.test(text)) {
      return { ...common, type: 'clip_align_to_playhead', edge: 'end', clipId: contextClipId, aiInterpretation: 'Clip-Ende an Playhead ausrichten.' };
    }
    if (/vorher|vorgaenger|previous/.test(text) && /clip|audio|anschliess|anlegen|snap/.test(text)) {
      return { ...common, type: 'clip_attach_adjacent', direction: 'previous', clipId: contextClipId, aiInterpretation: isClipContext ? 'Gewählten Clip an den vorherigen Clip anschließen.' : 'Markierten Clip an den vorherigen Clip anschließen.' };
    }
    if (/naechst|nachst|next/.test(text) && /clip|audio|anschliess|anlegen|snap/.test(text)) {
      return { ...common, type: 'clip_attach_adjacent', direction: 'next', clipId: contextClipId, aiInterpretation: isClipContext ? 'Gewählten Clip an den nächsten Clip anschließen.' : 'Markierten Clip an den nächsten Clip anschließen.' };
    }

    if (isClipContext && /duplizier|kopier|copy|wiederhol|nochmal|noch\s*mal/.test(text)) {
      return { ...common, type: 'clip_duplicate', clipId: contextClipId, aiInterpretation: 'Gewählten Timeline-Clip duplizieren.' };
    }
    if (isClipContext && /loesch|losch|entfern|delete|remove|weg/.test(text)) {
      return { ...common, type: 'clip_delete', clipId: contextClipId, aiInterpretation: 'Gewählten Timeline-Clip löschen.' };
    }
    if (isClipContext && /schneid|schnitt|split|cut/.test(text)) {
      return { ...common, type: 'clip_split', time: currentTime, clipId: contextClipId, aiInterpretation: `Gewählten Timeline-Clip am Playhead ${secondsToClock(currentTime, true)} schneiden.` };
    }

    throw new Error('Befehl nicht eindeutig. Beispiele: „Fade-in 3s“, „kürze Anfang um 8s“, „dupliziere diesen Clip“, „Schließe alle Lücken“.');
  }

  function runDawAiCommand(prompt = aiCommandText, options = {}) {
    const rawPrompt = String(prompt || '').trim();
    if (rawPrompt) appendDawAiHistory('user', rawPrompt);
    try {
      const command = parseDawAiCommand(rawPrompt, options);
      setAiCommandText(rawPrompt);
      setAiCommandStatus(command.aiInterpretation || 'Befehl erkannt.');
      appendDawAiHistory('assistant', command.aiInterpretation || 'Befehl erkannt und als prüfbarer DAW-Plan vorbereitet.', { type: command.type || command.uiAction });
      if (command.uiAction === 'needs_generation_workflow') {
        notify?.('Planungswunsch erkannt: Dafür braucht die App einen Erzeugen-und-Einfügen-Workflow.', 'info');
        return;
      }
      if (command.uiAction === 'focus_section' && command.section) {
        focusSection(command.section.id);
        notify?.(`${command.section.displayLabel} wurde als Bereich markiert.`, 'success');
        return;
      }
      if (command.uiAction === 'range_30') {
        const start = currentTime;
        setSelection({ start, end: Math.min(timelineDuration, start + 30) });
        notify?.('30s-Bereich ab Playhead markiert.', 'success');
        return;
      }
      openDawCommandPreview(command);
      if (options.closeClipPanel !== false) setClipAiPanel({ clipId: '', prompt: '' });
    } catch (err) {
      const message = err.message || 'KI-DAW-Befehl konnte nicht interpretiert werden.';
      setAiCommandStatus(message);
      appendDawAiHistory('assistant', message, { tone: 'warning' });
      notify?.(message, 'warning');
    }
  }

  function openClipAiPanel(event, clip) {
    event?.stopPropagation?.();
    event?.preventDefault?.();
    if (!clip?.id) return;
    setSelectedClipId(clip.id);
    setAiPanelOpen(false);
    setClipAiPanel((current) => ({ clipId: clip.id, prompt: current.clipId === clip.id ? current.prompt : '' }));
  }

  function closeClipAiPanel(event) {
    event?.stopPropagation?.();
    event?.preventDefault?.();
    setClipAiPanel({ clipId: '', prompt: '' });
  }

  function runClipAiCommand(event, clip) {
    event?.preventDefault?.();
    event?.stopPropagation?.();
    if (!clip?.id) return;
    const prompt = clipAiPanel.clipId === clip.id ? clipAiPanel.prompt : '';
    setSelectedClipId(clip.id);
    runDawAiCommand(prompt, { clipId: clip.id, source: 'timeline-clip-ai' });
  }

  function setClipAiPromptFor(clip, prompt) {
    if (!clip?.id) return;
    setClipAiPanel({ clipId: clip.id, prompt });
  }

  function adjacentClipFor(clip, direction) {
    if (!clip) return null;
    const start = safeNumber(clip.timeline_start);
    const end = start + clipDuration(clip);
    const clips = (arrangementRef.current?.clips || [])
      .filter((candidate) => candidate.id !== clip.id && candidate.track_id === clip.track_id)
      .map((candidate) => {
        const candidateStart = safeNumber(candidate.timeline_start);
        const candidateEnd = candidateStart + clipDuration(candidate);
        return { ...candidate, candidateStart, candidateEnd };
      });
    if (direction === 'previous') {
      return clips.filter((candidate) => candidate.candidateEnd <= start + 0.02).sort((a, b) => b.candidateEnd - a.candidateEnd)[0] || null;
    }
    return clips.filter((candidate) => candidate.candidateStart >= end - 0.02).sort((a, b) => a.candidateStart - b.candidateStart)[0] || null;
  }

  function alignSelectedClipToPlayhead(edge = 'start') {
    openDawCommandPreview({ type: 'clip_align_to_playhead', edge, clipId: selectedClipIdRef.current });
  }

  function attachSelectedClipToAdjacent(direction) {
    openDawCommandPreview({ type: 'clip_attach_adjacent', direction, clipId: selectedClipIdRef.current });
  }

  function moveSelectedClipToTrack(trackId) {
    if (!selectedClip) return;
    commitArrangementHistory();
    updateArrangement((current) => ({ ...current, clips: current.clips.map((clip) => clip.id === selectedClip.id ? { ...clip, track_id: trackId } : clip) }));
  }

  function updateSelectedClip(patch) {
    if (!selectedClip) return;
    commitArrangementHistory();
    updateArrangement((current) => ({ ...current, clips: current.clips.map((clip) => clip.id === selectedClip.id ? { ...clip, ...patch } : clip) }));
  }

  function removeSelectedClip() {
    openDawCommandPreview({ type: 'clip_delete', clipId: selectedClipIdRef.current });
  }

  // Navigations-Vertrag: Playhead, Bereichsgrenzen und Marker werden nur in der oberen Ruler-/Marker-Zone gesetzt.
  // Track-Zeilen darunter bleiben ausschließlich für Clip-Auswahl, Clip-Move, Trim, Fade und Schnitt zuständig.
  function timelineNavigationPointerDown(event) {
    if (!arrangement) return;
    if (event.target?.closest?.('.daw-arr-clip, .daw-arr-marker-button')) return;
    event.preventDefault();
    const time = timeFromPointer(event);

    if (event.shiftKey) {
      addMarkerAt(time, { type: 'jump' });
      return;
    }
    if (event.ctrlKey || event.metaKey) {
      setRangeBoundary('start', time);
      showDragTimeTooltip(event, { mode: 'range', title: 'Bereichsanfang', rows: [secondsToClock(time, true), 'Alt + Klick setzt das Ende'] });
      window.setTimeout(hideDragTimeTooltip, 900);
      return;
    }
    if (event.altKey) {
      setRangeBoundary('end', time);
      showDragTimeTooltip(event, { mode: 'range', title: 'Bereichsende', rows: [secondsToClock(time, true), 'Strg/Cmd + Klick setzt den Anfang'] });
      window.setTimeout(hideDragTimeTooltip, 900);
      return;
    }
    if (toolMode === 'marker') {
      addMarkerAt(time);
      return;
    }
    if (toolMode === 'range') {
      setSelection({ start: time, end: time });
      showDragTimeTooltip(event, { mode: 'range', title: 'Bereich', rows: [`Start ${secondsToClock(time, true)}`, `Ende ${secondsToClock(time, true)}`, 'Länge 00:00.0'] });
      dragState.current = { kind: 'range', start: time };
      return;
    }
    if (toolMode === 'split') {
      splitClipAt(time);
      return;
    }
    seekTo(time);
    showDragTimeTooltip(event, { mode: 'playhead', title: 'Playhead', rows: [secondsToClock(time, true)] });
    dragState.current = { kind: 'playhead' };
  }

  function timelineTrackPointerDown(event) {
    if (event.target?.closest?.('.daw-arr-clip')) return;
    setSelectedClipId('');
  }

  function clipPointerDown(event, clip) {
    event.stopPropagation();
    event.preventDefault();
    if (!clip || clip.locked) return;
    setSelectedClipId(clip.id);
    const time = timeFromPointer(event);
    const fadeHandle = event.target?.closest?.('.clip-fade-handle');
    if (fadeHandle) {
      const edge = fadeHandle.classList.contains('left') ? 'in' : 'out';
      showDragTimeTooltip(event, {
        mode: 'fade',
        title: edge === 'in' ? 'Fade-in' : 'Fade-out',
        rows: edge === 'in'
          ? [`Fade-in ${secondsToClock(safeNumber(clip.fade_in), true)}`, `endet bei ${secondsToClock(safeNumber(clip.timeline_start) + safeNumber(clip.fade_in), true)}`, `Clip-Länge ${secondsToClock(clipDuration(clip), true)}`]
          : [`Fade-out ${secondsToClock(safeNumber(clip.fade_out), true)}`, `startet bei ${secondsToClock(safeNumber(clip.timeline_start) + clipDuration(clip) - safeNumber(clip.fade_out), true)}`, `Clip-Ende ${secondsToClock(safeNumber(clip.timeline_start) + clipDuration(clip), true)}`],
      });
      dragState.current = {
        kind: 'fade',
        clipId: clip.id,
        edge,
        originalTimelineStart: safeNumber(clip.timeline_start),
        originalDuration: clipDuration(clip),
        originalFadeIn: safeNumber(clip.fade_in),
        originalFadeOut: safeNumber(clip.fade_out),
        originalArrangement: cloneArrangementSnapshot(arrangementRef.current),
      };
      return;
    }
    const resizeHandle = event.target?.closest?.('.clip-resize-handle');
    if (resizeHandle) {
      const edge = resizeHandle.classList.contains('left') ? 'left' : 'right';
      showDragTimeTooltip(event, {
        mode: 'trim',
        title: edge === 'left' ? 'Linke Kante' : 'Rechte Kante',
        rows: edge === 'left'
          ? [`Start ${secondsToClock(safeNumber(clip.timeline_start), true)}`, `Quelle ${secondsToClock(safeNumber(clip.source_start), true)}`, `Länge ${secondsToClock(clipDuration(clip), true)}`]
          : [`Ende ${secondsToClock(safeNumber(clip.timeline_start) + clipDuration(clip), true)}`, `Quelle ${secondsToClock(safeNumber(clip.source_end), true)}`, `Länge ${secondsToClock(clipDuration(clip), true)}`],
      });
      dragState.current = {
        kind: 'resize',
        clipId: clip.id,
        edge,
        startClientX: event.clientX,
        originalTimelineStart: safeNumber(clip.timeline_start),
        originalSourceStart: safeNumber(clip.source_start),
        originalSourceEnd: safeNumber(clip.source_end),
        originalDuration: clipDuration(clip),
        sourceDuration: Math.max(safeNumber(mediaDuration), safeNumber(currentAsset?.duration_seconds), safeNumber(clip.source_end)),
        originalArrangement: cloneArrangementSnapshot(arrangementRef.current),
      };
      return;
    }
    if (toolMode === 'split') {
      splitClipAt(time, clip.id);
      return;
    }
    // Marker- und Bereichsoperationen liegen bewusst in der oberen Ruler-/Marker-Zone.
    // Ein Klick auf einen Clip waehlt nur den Clip aus; der Playhead springt nicht.
    // Verschieben startet erst, wenn der Pointer wirklich bewegt wird.
    dragState.current = {
      kind: 'move',
      clipId: clip.id,
      startClientX: event.clientX,
      originalStart: safeNumber(clip.timeline_start),
      originalDuration: clipDuration(clip),
      originalTrackId: clip.track_id,
      originalArrangement: cloneArrangementSnapshot(arrangementRef.current),
    };
  }

  function currentArrangementPayload() {
    const snapshot = normalizeArrangement(arrangementRef.current || arrangement, currentAsset, timelineDuration || mediaDuration || currentAsset?.duration_seconds || 1);
    return { ...snapshot, duration_seconds: timelineDuration };
  }

  async function saveArrangement(showSuccess = true) {
    if (!assetId || !arrangementRef.current) return;
    setSaving(true);
    try {
      const payload = currentArrangementPayload();
      const result = await api.daw.saveArrangement(assetId, payload);
      const normalized = normalizeArrangement(result.arrangement, currentAsset, timelineDuration);
      setArrangement(normalized);
      arrangementRef.current = normalized;
      if (showSuccess) notify?.('DAW-Arrangement gespeichert.', 'success');
    } catch (err) {
      notify?.(err.message || 'DAW-Arrangement konnte nicht gespeichert werden.', 'error');
    } finally {
      setSaving(false);
    }
  }

  async function buildArrangementPreview(options = {}) {
    if (!assetId || !arrangementRef.current) return '';
    const payload = options.arrangementPayload
      ? normalizeArrangement(options.arrangementPayload, currentAsset, arrangementLength(options.arrangementPayload, timelineDurationRef.current || mediaDuration || currentAsset?.duration_seconds || 1))
      : currentArrangementPayload();
    const signature = arrangementPlaybackSignature(payload);
    setPreviewing(true);
    try {
      const result = await api.daw.previewArrangement(assetId, { arrangement: payload, output_format: outputFormat, version_label: versionLabel || 'Editiert Vorschau' });
      const url = URL.createObjectURL(result.blob);
      setPreviewUrl((current) => { if (current) URL.revokeObjectURL(current); return url; });
      setPreviewSignature(signature);
      if (options.autoplay) {
        pendingPreviewPlaybackRef.current = { time: currentTimeRef.current };
      }
      if (!options.silent) notify?.(options.successMessage || 'Arrangement-Vorschau erstellt.', 'success');
      return url;
    } catch (err) {
      if (!options.silent) notify?.(err.message || 'Arrangement-Vorschau fehlgeschlagen.', 'error');
      throw err;
    } finally {
      setPreviewing(false);
    }
  }

  async function previewArrangement() {
    try {
      await buildArrangementPreview();
    } catch {
      // buildArrangementPreview meldet den Fehler bereits im UI.
    }
  }

  async function renderArrangement() {
    if (!assetId || !arrangementRef.current) return;
    setRendering(true);
    try {
      const payload = currentArrangementPayload();
      const task = await api.daw.renderArrangementTask(assetId, { arrangement: payload, output_format: outputFormat, version_label: versionLabel || 'Editiert', create_notification: true });
      setRenderTask({ ...task, id: task.task_local_id, progress: 0, response_payload: { progress: { percent: 0, phase: 'queued', message: task.message || 'DAW-Render wurde gestartet.' } } });
      notify?.('DAW-Render wurde gestartet und läuft als aktiver Task im Hintergrund.', 'success');
      onReload?.();
    } catch (err) {
      notify?.(err.message || 'Arrangement-Render konnte nicht gestartet werden.', 'error');
    } finally {
      setRendering(false);
    }
  }

  function resetArrangement() {
    if (!currentAsset) return;
    commitArrangementHistory();
    const next = buildDefaultArrangement(currentAsset, mediaDuration || currentAsset.duration_seconds || 1);
    setArrangement(next);
    setSelectedClipId(next.clips[0]?.id || '');
    setSelection(null);
    setPreviewSignature('');
  }

  // Clip-Verschieben und Kürzen wird bewusst über Pointer-Events umgesetzt.
  // Das vermeidet Konflikte zwischen Drittanbieter-Drag-Handlern, React-Re-Renders und der Waveform-Komponente.


  useHotkeys('space,k,p', (event) => {
    event.preventDefault();
    togglePlayback();
  }, { enableOnFormTags: false, preventDefault: true }, [togglePlayback]);

  useHotkeys('s', (event) => {
    event.preventDefault();
    splitClipAt(currentTime);
  }, { enableOnFormTags: false, preventDefault: true }, [currentTime, selectedClipId, arrangement, splitClipAt]);

  // Kein DAW-Hotkey fuer M: M bleibt global fuer Sidebar-Modus (App.jsx) reserviert.
  // Marker werden in der DAW bewusst ueber den oberen Ruler-/Markerbereich gesetzt.

  useHotkeys('1,2,3,4,5,6,7,8,9', (event) => {
    event.preventDefault();
    jumpToMarker(event.key);
  }, { enableOnFormTags: false, preventDefault: true }, [jumpToMarker]);

  useHotkeys('delete,backspace', (event) => {
    event.preventDefault();
    if (selectedClipIdRef.current) removeSelectedClip();
  }, { enableOnFormTags: false, preventDefault: true }, [removeSelectedClip]);

  useHotkeys('esc', (event) => {
    event.preventDefault();
    setSelection(null);
    setSelectedClipId('');
  }, { enableOnFormTags: false, preventDefault: true }, []);

  useHotkeys('left,right', (event) => {
    event.preventDefault();
    const step = event.shiftKey ? 5 : 1;
    seekTo(currentTime + (event.key === 'ArrowLeft' ? -step : step));
  }, { enableOnFormTags: false, preventDefault: true }, [currentTime, seekTo]);

  useHotkeys('ctrl+z,meta+z', (event) => {
    event.preventDefault();
    undoArrangement();
  }, { enableOnFormTags: false, preventDefault: true }, [undoArrangement]);

  useHotkeys('ctrl+y,ctrl+shift+z,meta+shift+z', (event) => {
    event.preventDefault();
    redoArrangement();
  }, { enableOnFormTags: false, preventDefault: true }, [redoArrangement]);

  const warnings = [];
  if (!arrangement?.clips?.length) warnings.push('Keine Clips im Arrangement.');
  if (selection && selection.end - selection.start > 0.05) warnings.push(`Bereich aktiv: ${secondsToClock(selection.start)} – ${secondsToClock(selection.end)}`);
  const toolHelp = TOOL_HELP[toolMode] || TOOL_HELP.select;

  return (
    <section className="page stack daw-page daw-arr-page daw-filmora-timeline daw-clean-workspace">
      <style>{DAW_TIMELINE_VISUAL_CSS}</style>
      {!assetId ? (
        <DawEmptyState t={t} lastKnownAsset={lastKnownAsset} onOpenLast={() => lastKnownAsset && selectAsset(lastKnownAsset.id)} onBackToLibrary={onBackToLibrary} />
      ) : <>
        <header className="daw-projectbar panel">
          <div className="daw-projectbar-left">
            <button type="button" className="daw-nav-button" onClick={onBackToLibrary}><ArrowLeft size={16} /> Library</button>
            <img className="daw-project-cover" src={pickCover(currentAsset) || '/static/favicon.ico'} alt="Cover" onError={handleCoverImageError} />
            <div className="daw-project-title">
              <strong>{currentAsset ? pickTitle(currentAsset) : 'Audio wird geladen …'}</strong>
              <small>{formatDuration(timelineDuration)} · {outputFormat.toUpperCase()} · Lokal · Original bleibt unverändert{beatgridStatusLabel ? ` · ${beatgridStatusLabel}` : ''}</small>
            </div>
          </div>
          <div className="daw-projectbar-actions daw-projectbar-actions-clean">
            <button className="primary daw-save-version" type="button" onClick={renderArrangement} disabled={rendering || renderTaskActive || !arrangement}>{(rendering || renderTaskActive) ? <Loader2 className="spin-icon" size={15} /> : <Save size={15} />} {renderTaskActive ? 'Speichert …' : 'Version speichern'}</button>
          </div>
        </header>

        {renderTask && (
          <div className={`daw-render-task-strip ${renderTaskActive ? 'active' : renderTaskStatus === 'FAILED' ? 'failed' : 'done'}`}>
            <div>
              <strong>{renderTaskActive ? 'Version wird im Hintergrund gespeichert' : renderTaskStatus === 'FAILED' ? 'Render fehlgeschlagen' : 'Version gespeichert'}</strong>
              <span>{renderTaskPhase || (renderTaskActive ? 'Task läuft. Du kannst den Live-Status auch oben bei den aktiven Tasks öffnen.' : renderTaskStatus)}</span>
            </div>
            <div className="daw-render-task-progress" aria-label="DAW Render Fortschritt">
              <span style={{ width: `${Math.max(4, Math.min(100, renderTaskProgress || (renderTaskActive ? 8 : 100)))}%` }} />
            </div>
            <button type="button" onClick={() => onReload?.()}>Status aktualisieren</button>
          </div>
        )}

        {currentAsset && <audio ref={audioRef} src={activeAudioUrl || ''} preload="metadata" className="daw-hidden-audio" onLoadedMetadata={(event) => { if (!usingRenderedPlayback) handleDurationDetected(event); }} onDurationChange={(event) => { if (!usingRenderedPlayback) handleDurationDetected(event); }} onTimeUpdate={(event) => { const nextTime = event.currentTarget.currentTime || 0; currentTimeRef.current = nextTime; setCurrentTime(nextTime); }} onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} onEnded={() => setIsPlaying(false)} />}

        <section className="daw-clean-control panel" aria-label="DAW Steuerung">
          <div className="daw-clean-transport" aria-label="Transport">
            <button type="button" onClick={undoArrangement} disabled={!undoStack.length} title="Rückgängig (Strg+Z)"><Undo2 size={15} /> Undo</button>
            <button type="button" onClick={redoArrangement} disabled={!redoStack.length} title="Wiederholen (Strg+Y)"><Redo2 size={15} /> Redo</button>
            <button type="button" onClick={() => seekTo(Math.max(0, currentTime - 10))} title="10 Sekunden zurück"><SkipBack size={15} /> 10s</button>
            <button type="button" className="play daw-main-play" onClick={togglePlayback} aria-label={isPlaying ? 'Pause' : 'Abspielen'} disabled={previewing && needsRenderedPlayback && !previewMatchesArrangement}>{previewing && needsRenderedPlayback && !previewMatchesArrangement ? <Loader2 className="spin-icon" size={20} /> : isPlaying ? <Pause size={20} /> : <Play size={20} />}</button>
            <button type="button" onClick={() => seekTo(Math.min(timelineDuration, currentTime + 10))} title="10 Sekunden vor">10s <SkipForward size={15} /></button>
            <strong className="daw-time-readout">{secondsToClock(currentTime, true)} / {secondsToClock(timelineDuration)}</strong>
          </div>

          <div className="daw-clean-tools" aria-label="Werkzeuge">
            {TOOL_MODES.map((mode) => {
              const Icon = mode.icon;
              return <button key={mode.id} className={toolMode === mode.id ? 'active daw-tool-button' : 'daw-tool-button'} type="button" onClick={() => setToolMode(mode.id)}><Icon size={15} /> {mode.label}</button>;
            })}
          </div>

          <div className="daw-clean-edit" aria-label="Bearbeiten">
            <button type="button" className="daw-primary-edit" onClick={() => splitClipAt(currentTime)}><SplitSquareHorizontal size={15} /> Schneiden</button>
            <button type="button" onClick={() => setSelection({ start: currentTime, end: Math.min(timelineDuration, currentTime + 30) })}><Flag size={15} /> 30s-Bereich</button>
            <button type="button" onClick={cutRange} disabled={!selection}><Trash2 size={15} /> Bereich entfernen</button>
            <button type="button" onClick={duplicateClip} disabled={!selectedClip}><Copy size={15} /> Duplizieren</button>
            <label className="inline-check daw-toolbar-check"><input type="checkbox" checked={closeGap} onChange={(event) => setCloseGap(event.target.checked)} /> Lücke schließen</label>
            <button
              type="button"
              className={`daw-ai-toolbar-button ${clipAiPanel.clipId ? 'active' : ''}`}
              onClick={(event) => selectedClip ? openClipAiPanel(event, selectedClip) : notify?.('Bitte zuerst einen Clip in der Timeline auswählen.', 'info')}
              aria-expanded={Boolean(clipAiPanel.clipId)}
              title="KI für ausgewählten Timeline-Clip öffnen"
            >
              <Bot size={15} /> Clip-KI
            </button>
          </div>

          <div className="daw-clean-project" aria-label="Projekt und Raster">
            <label className="daw-field-pill">BPM <input type="number" min="20" max="300" value={arrangement?.bpm || ''} placeholder="frei" onChange={(event) => updateArrangement((current) => ({ ...current, bpm: event.target.value ? Number(event.target.value) : null }))} /></label>
            <button className={`daw-toggle-action ${arrangement?.snap_enabled ? 'active' : ''}`} type="button" title="Raster + Audio an Audio einrasten" onClick={() => updateArrangement((current) => ({ ...current, snap_enabled: !current.snap_enabled }))}><Magnet size={15} /> Snap</button>
            <select className="daw-select-pill" value={arrangement?.snap_unit || 'beat'} onChange={(event) => updateArrangement((current) => ({ ...current, snap_unit: event.target.value }))} aria-label="Rastereinheit">{SNAP_UNITS.map((unit) => <option key={unit.id} value={unit.id}>{unit.label}</option>)}</select>
            <div className="daw-zoom-pill" aria-label="Timeline-Zoom">
              <button type="button" onClick={() => setTimelineZoom((value) => Math.max(0, value - 1))} disabled={timelineZoom <= 0} title="Timeline verkleinern"><Minus size={15} /></button>
              <strong>{timelineZoomOption.label}</strong>
              <button type="button" onClick={() => setTimelineZoom((value) => Math.min(DAW_TIMELINE_ZOOM_OPTIONS.length - 1, value + 1))} disabled={timelineZoom >= DAW_TIMELINE_ZOOM_OPTIONS.length - 1} title="Timeline vergrößern"><Plus size={15} /></button>
            </div>
            <label className="daw-format-select"><span>Format</span><select value={outputFormat} onChange={(event) => setOutputFormat(event.target.value)} aria-label="Ausgabeformat">{OUTPUT_FORMATS.map((format) => <option key={format} value={format}>{format.toUpperCase()}</option>)}</select></label>
            <button type="button" className="daw-save-action" onClick={() => saveArrangement(true)} disabled={saving}>{saving ? <Loader2 className="spin-icon" size={15} /> : <Save size={15} />} Sichern</button>
            <details className="daw-project-more daw-clean-more">
              <summary>Mehr</summary>
              <div className="daw-project-more-panel">
                <button type="button" onClick={() => currentAsset && onPlay?.([currentAsset], 0)} disabled={!currentAsset}><Headphones size={15} /> Quelle</button>
                {currentAsset && <a className="button" href={api.archive.downloadUrl(currentAsset.id)}><Download size={15} /> Download</a>}
                <button type="button" onClick={rebuildBeatgrid} disabled={beatgridLoading}>{beatgridLoading ? <Loader2 className="spin-icon" size={15} /> : <Magnet size={15} />} Bar-Map neu</button>
                <button type="button" onClick={resetArrangement}><RotateCcw size={15} /> Reset</button>
                <button type="button" className="daw-help-open-button" onClick={() => setHelpOpen(true)}><HelpCircle size={15} /> Hilfe</button>
              </div>
            </details>
          </div>
        </section>



        {loading && <div className="daw-loading-strip"><Loader2 className="spin-icon" size={15} /> Arrangement wird geladen …</div>}

        <section className="daw-arr-editor panel">
          <div className="daw-arr-sidebar">
            <div className="daw-arr-track-head spacer" />
            {TRACKS.map((track) => (
              <div key={track.id} className="daw-arr-track-head">
                <strong>{track.name}</strong>
                <span>{(arrangement?.clips || []).filter((clip) => clip.track_id === track.id).length} Clips</span>
              </div>
            ))}
          </div>
          <div className="daw-arr-timeline" style={{ '--daw-timeline-width': `${timelineZoomOption.width}%` }}>
            <div className="daw-arr-timeline-canvas" ref={timelineRef}>
              <div className="daw-arr-ruler" onPointerDown={timelineNavigationPointerDown} title="Klick: Playhead · Strg/Cmd: Bereichsanfang · Alt: Bereichsende · Shift: Sprungmarker">
                {ticks.map((tick) => <span key={`${tick.index}-${tick.time}`} className={tick.major ? 'major' : 'minor'} style={{ left: tick.left }}>{tick.label}</span>)}
              </div>
            <div className="daw-arr-markers" onPointerDown={timelineNavigationPointerDown} title="Klick: Playhead · Strg/Cmd: Bereichsanfang · Alt: Bereichsende · Shift: Sprungmarker">
              {(arrangement?.markers || []).map((marker) => {
                const isJumpMarker = String(marker?.type || '').toLowerCase() === 'jump';
                return (
                  <button
                    key={marker.id}
                    type="button"
                    className={`daw-arr-marker-button ${isJumpMarker ? 'jump' : 'standard'}`}
                    style={{ left: `${percent(marker.time, timelineDuration)}%` }}
                    title={isJumpMarker ? `Sprungmarker ${marker.label}: Taste ${marker.label}` : marker.label}
                    onPointerDown={(event) => event.stopPropagation()}
                    onClick={(event) => { event.stopPropagation(); seekTo(marker.time); }}
                  >{isJumpMarker ? `#${marker.label}` : marker.label}</button>
                );
              })}
            </div>

            <span
              className="daw-arr-playhead"
              role="slider"
              aria-label="Playhead"
              aria-valuemin={0}
              aria-valuemax={Math.round(timelineDuration)}
              aria-valuenow={Math.round(currentTime)}
              style={{ left: `${percent(currentTime, timelineDuration)}%` }}
              onPointerDown={(event) => {
                if (!pointerIsInTimelineNavigationZone(event)) return;
                event.stopPropagation();
                event.preventDefault();
                const next = timeFromPointer(event);
                seekTo(next);
                showDragTimeTooltip(event, { mode: 'playhead', title: 'Playhead', rows: [secondsToClock(next, true)] });
                dragState.current = { kind: 'playhead' };
              }}
            />
            {selection && selection.end - selection.start > 0.05 && <span className="daw-arr-selection" style={{ left: `${percent(selection.start, timelineDuration)}%`, width: `${Math.max(0.4, percent(selection.end, timelineDuration) - percent(selection.start, timelineDuration))}%` }}><b>{secondsToClock(selection.start)} – {secondsToClock(selection.end)}</b></span>}
            {snapGuide && <span className="daw-snap-guide" style={{ left: `${percent(snapGuide.time, timelineDuration)}%` }} aria-hidden="true"><b className="daw-snap-guide-label">{snapGuide.label}</b></span>}
              {TRACKS.map((track) => (
                <div key={track.id} className="daw-arr-track-row" data-track-id={track.id} onPointerDown={timelineTrackPointerDown}>
                {(arrangement?.clips || []).filter((clip) => clip.track_id === track.id).map((clip) => {
                  const left = percent(clip.timeline_start, timelineDuration);
                  const width = Math.max(0.5, percent(clip.timeline_start + clipDuration(clip), timelineDuration) - left);
                  const duration = clipDuration(clip);
                  const fadeInPercent = duration > 0 ? clamp((safeNumber(clip.fade_in) / duration) * 100, 0, 50) : 0;
                  const fadeOutPercent = duration > 0 ? clamp((safeNumber(clip.fade_out) / duration) * 100, 0, 50) : 0;
                  const fadeInHandleLeft = fadeHandlePercent(clip.fade_in, duration, 'left');
                  const fadeOutHandleLeft = fadeHandlePercent(clip.fade_out, duration, 'right');
                  return (
                    <div
                      key={clip.id}
                      role="button"
                      tabIndex={0}
                      data-clip-id={clip.id}
                      aria-label={`Clip ${clip.label || ''}`.trim()}
                      className={`daw-arr-clip ${clip.id === selectedClipId ? 'selected' : ''}`}
                      style={{ left: `${left}%`, width: `${width}%` }}
                      onPointerDown={(event) => clipPointerDown(event, clip)}
                      onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setSelectedClipId(clip.id); } }}
                    >
                      <span className="clip-waveform" aria-hidden="true">
                        {currentAsset && <Waveform
                          asset={currentAsset}
                          audioRef={audioRef}
                          compact={false}
                          durationSeconds={duration}
                          sourceStartSeconds={safeNumber(clip.source_start)}
                          sourceEndSeconds={safeNumber(clip.source_end)}
                          sourceDurationSeconds={sourceDuration || safeNumber(currentAsset?.duration_seconds)}
                          interactive={false}
                          showProgress={false}
                          showSegments={true}
                        />}
                      </span>
                      {fadeInPercent > 0 && <span className="clip-fade-overlay in" aria-hidden="true" style={{ width: `${fadeInPercent}%` }} />}
                      {fadeOutPercent > 0 && <span className="clip-fade-overlay out" aria-hidden="true" style={{ width: `${fadeOutPercent}%` }} />}
                      <span className="clip-resize-handle left" aria-hidden="true" />
                      <span className="clip-resize-handle right" aria-hidden="true" />
                      <span className="clip-fade-handle left" role="slider" aria-label="Fade-in ziehen" aria-valuemin={0} aria-valuemax={Math.round(duration)} aria-valuenow={Math.round(safeNumber(clip.fade_in))} style={{ left: `${fadeInHandleLeft}%` }} />
                      <span className="clip-fade-handle right" role="slider" aria-label="Fade-out ziehen" aria-valuemin={0} aria-valuemax={Math.round(duration)} aria-valuenow={Math.round(safeNumber(clip.fade_out))} style={{ left: `${fadeOutHandleLeft}%` }} />
                      <button
                        type="button"
                        className={`daw-clip-ai-button ${clipAiPanel.clipId === clip.id ? 'active' : ''}`}
                        onPointerDown={(event) => event.stopPropagation()}
                        onClick={(event) => openClipAiPanel(event, clip)}
                        title="KI-Befehl für diesen Clip planen"
                        aria-label="KI-Befehl für diesen Clip planen"
                      >
                        <Bot size={12} /> KI
                      </button>
                      {clipAiPanel.clipId === clip.id && (
                        <form className="daw-clip-ai-popover" onSubmit={(event) => runClipAiCommand(event, clip)} onPointerDown={(event) => event.stopPropagation()} onClick={(event) => event.stopPropagation()} onKeyDown={(event) => event.stopPropagation()} onKeyUp={(event) => event.stopPropagation()}>
                          <div className="daw-clip-ai-head">
                            <div>
                              <span className="daw-kicker">Timeline-KI</span>
                              <strong>{clip.label || 'Clip bearbeiten'}</strong>
                            </div>
                            <button type="button" className="ghost" onClick={closeClipAiPanel} aria-label="Clip-KI schließen"><X size={14} /></button>
                          </div>
                          <input
                            value={clipAiPanel.prompt}
                            onChange={(event) => setClipAiPromptFor(clip, event.target.value)}
                            onKeyDown={(event) => event.stopPropagation()}
                            onKeyUp={(event) => event.stopPropagation()}
                            placeholder="z. B. Fade-in 3s, Anfang 8s kürzen, leiser -3 dB, duplizieren"
                            aria-label="KI-Befehl für diesen Clip"
                            autoFocus
                          />
                          <div className="daw-clip-ai-examples">
                            <button type="button" onClick={() => setClipAiPromptFor(clip, 'Fade-in 3s')}>Fade-in 3s</button>
                            <button type="button" onClick={() => setClipAiPromptFor(clip, 'Anfang um 8s kürzen')}>Anfang kürzen</button>
                            <button type="button" onClick={() => setClipAiPromptFor(clip, 'Clip um 3 dB leiser machen')}>-3 dB</button>
                            <button type="submit" className="primary"><Bot size={14} /> Planen</button>
                          </div>
                        </form>
                      )}
                    </div>
                  );
                  })}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="daw-arr-bottom panel daw-arr-bottom-streamlined daw-arr-bottom-clean" aria-label="DAW Clip-Inspector und Vorschau">
          <article className={`daw-arr-clip-inspector ${selectedClip ? '' : 'is-empty'}`} aria-live="polite">
            {selectedClip ? <>
              <div className="daw-arr-inspector-head">
                <div>
                  <strong>Clip-Inspector</strong>
                  <div className="daw-arr-inspector-pills" aria-label="Clipstatus">
                    <span>{selectedTrackName}</span>
                    <span>{secondsToClock(selectedClip.timeline_start, true)}</span>
                    <span>{secondsToClock(clipDuration(selectedClip), true)}</span>
                    {arrangement?.snap_enabled && <span>Snap aktiv</span>}
                    {selection && selection.end - selection.start > 0.05 && <span>Bereich {secondsToClock(selection.start)} – {secondsToClock(selection.end)}</span>}
                  </div>
                </div>
                <button type="button" className="danger ghost" onClick={removeSelectedClip}><Trash2 size={15} /> Löschen</button>
              </div>
              <div className="daw-arr-clip-fields">
                <label className="wide">Label<input value={selectedClip.label || ''} onChange={(event) => updateSelectedClip({ label: event.target.value })} /></label>
                <label>Position<input type="number" step="0.01" value={Number(selectedClip.timeline_start).toFixed(2)} onChange={(event) => updateSelectedClip({ timeline_start: snapTime(Number(event.target.value)) })} /></label>
                <label>Gain dB<input type="number" step="0.5" value={selectedClip.gain_db || 0} onChange={(event) => updateSelectedClip({ gain_db: Number(event.target.value) })} /></label>
                <label>Quelle Start<input type="number" step="0.01" value={Number(selectedClip.source_start).toFixed(2)} onChange={(event) => updateSelectedClip({ source_start: Math.max(0, Number(event.target.value)) })} /></label>
                <label>Quelle Ende<input type="number" step="0.01" value={Number(selectedClip.source_end).toFixed(2)} onChange={(event) => updateSelectedClip({ source_end: Math.max(selectedClip.source_start + 0.1, Number(event.target.value)) })} /></label>
                <label>Fade-in<input type="number" step="0.1" value={selectedClip.fade_in || 0} onChange={(event) => updateSelectedClip({ fade_in: Number(event.target.value) })} /></label>
                <label>Fade-out<input type="number" step="0.1" value={selectedClip.fade_out || 0} onChange={(event) => updateSelectedClip({ fade_out: Number(event.target.value) })} /></label>
              </div>
              {warnings.length > 0 && (
                <div className="daw-arr-warning-row compact">
                  {warnings.map((warning) => <span key={warning}><AlertTriangle size={14} /> {warning}</span>)}
                </div>
              )}
            </> : <div className="daw-arr-empty-inspector">
              <strong>Kein Clip ausgewählt</strong>
              <span>Clip anklicken, um Details zu bearbeiten.</span>
            </div>}
          </article>

          <article className="daw-arr-preview-card">
            <div className="daw-arr-preview-head">
              <div>
                <strong>Vorschau / Version</strong>
              </div>
              <button type="button" onClick={previewArrangement} disabled={previewing || rendering || !arrangement}>{previewing ? <Loader2 className="spin-icon" size={15} /> : <Headphones size={15} />} Vorschau</button>
            </div>
            <div className="daw-arr-preview-fields">
              <label>Versionsname<input value={versionLabel} onChange={(event) => setVersionLabel(event.target.value)} /></label>
              <label className="daw-arr-volume"><Volume2 size={15} /><input type="range" min="0" max="1" step="0.01" value={volume} onChange={(event) => { const next = Number(event.target.value); setVolume(next); if (audioRef.current) audioRef.current.volume = next; }} /></label>
            </div>
            {previewUrl && <audio controls src={previewUrl} preload="metadata" />}
          </article>
        </section>
        {helpOpen && (
          <div className="modal-backdrop daw-help-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setHelpOpen(false); }}>
            <section className="modal-card daw-help-modal" role="dialog" aria-modal="true" aria-labelledby="daw-help-title" onMouseDown={(event) => event.stopPropagation()}>
              <header className="modal-header daw-help-header">
                <div>
                  <p className="eyebrow">Mini-DAW Hilfe</p>
                  <h2 id="daw-help-title">Bedienung & Shortcuts</h2>
                </div>
                <button type="button" className="ghost" onClick={() => setHelpOpen(false)} aria-label="Hilfe schließen"><X size={18} /></button>
              </header>
              <div className="modal-content daw-help-content">
                <section className="daw-help-section">
                  <h3>Werkzeuge</h3>
                  <div className="daw-help-tool-grid">
                    {TOOL_MODES.map((mode) => {
                      const help = TOOL_HELP[mode.id] || TOOL_HELP.select;
                      const Icon = mode.icon;
                      return (
                        <article key={mode.id} className={toolMode === mode.id ? 'active' : ''}>
                          <span><Icon size={15} /> {mode.label}</span>
                          <strong>{help.title}</strong>
                          <p>{help.text}</p>
                        </article>
                      );
                    })}
                  </div>
                </section>
                <section className="daw-help-section">
                  <h3>Shortcuts</h3>
                  <div className="daw-help-shortcut-list">
                    {DAW_SHORTCUTS.map(([shortcut, description]) => (
                      <div key={shortcut}>
                        <kbd>{shortcut}</kbd>
                        <span>{description}</span>
                      </div>
                    ))}
                  </div>
                </section>
                <section className="daw-help-section compact">
                  <h3>Hinweis</h3>
                  <p>Die Hilfe ist nur Anzeige. Sie verändert keine Clips, Marker, Timeline-Daten oder gespeicherten Arrangements.</p>
                </section>
              </div>
            </section>
          </div>
        )}

        {commandPreview && (
          <div className="daw-command-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setCommandPreview(null); }}>
            <section className="daw-command-modal" role="dialog" aria-modal="true" aria-labelledby="daw-command-title" onMouseDown={(event) => event.stopPropagation()}>
              <header className="daw-command-header">
                <div>
                  <p>DAW Command Engine</p>
                  <h3 id="daw-command-title">{commandPreview.title}</h3>
                </div>
                <button type="button" className="ghost" onClick={() => setCommandPreview(null)} aria-label="Kommando-Vorschau schließen"><X size={18} /></button>
              </header>
              <div className="daw-command-body">
                {commandPreview.aiPrompt && (
                  <div className="daw-ai-command-preview">
                    <Bot size={18} />
                    <div>
                      <strong>KI-Befehl: „{commandPreview.aiPrompt}“</strong>
                      <span>{commandPreview.aiInterpretation || 'Der Befehl wurde in ein prüfbares DAW-Kommando übersetzt.'}</span>
                    </div>
                  </div>
                )}
                {commandPreview.section && (
                  <div className="daw-command-section-choice">
                    <strong>{commandPreview.section.displayLabel || commandPreview.section.label || 'Abschnitt'}</strong>
                    <span>{secondsToClock(commandPreview.section.start, true)} – {secondsToClock(commandPreview.section.end, true)} · Quelle: {commandPreview.section.source || 'Struktursegment'}</span>
                  </div>
                )}
                <div className="daw-command-summary">{commandPreview.summary}</div>
                <div className="daw-command-grid" aria-label="Auswirkung des Kommandos">
                  <div className="daw-command-metric"><span>Vorher</span><strong>{secondsToClock(commandPreview.beforeDuration, true)}</strong></div>
                  <div className="daw-command-metric"><span>Nachher</span><strong>{secondsToClock(commandPreview.afterDuration, true)}</strong></div>
                  <div className="daw-command-metric"><span>Änderung</span><strong>{commandPreview.afterDuration >= commandPreview.beforeDuration ? '+' : '-'}{secondsToClock(Math.abs(commandPreview.afterDuration - commandPreview.beforeDuration), true)}</strong></div>
                </div>
                <ul className="daw-command-actions-list" aria-label="Geplante Aktionen">
                  {(commandPreview.actions || []).map((action, index) => <li key={`${action}-${index}`}><CheckCircle2 size={15} /> {action}</li>)}
                </ul>
                {(commandPreview.warnings || []).length > 0 && (
                  <ul className="daw-command-warning-list" aria-label="Hinweise">
                    {commandPreview.warnings.map((warning, index) => <li key={`${warning}-${index}`}><AlertTriangle size={15} /> {warning}</li>)}
                  </ul>
                )}
              </div>
              <footer className="daw-command-footer">
                <button type="button" onClick={() => setCommandPreview(null)}>Abbrechen</button>
                <button type="button" className="primary" onClick={() => applyDawCommandPlan(commandPreview)}><CheckCircle2 size={15} /> Anwenden</button>
              </footer>
            </section>
          </div>
        )}


        {dragTooltip && (
          <div
            className={`daw-time-tooltip ${dragTooltip.mode || ''}`}
            style={{ left: `${dragTooltip.x}px`, top: `${dragTooltip.y}px` }}
            role="status"
            aria-live="polite"
          >
            {dragTooltip.title && <strong>{dragTooltip.title}</strong>}
            {dragTooltip.rows.map((row, index) => <span key={`${row}-${index}`}>{row}</span>)}
          </div>
        )}
      </>}
    </section>
  );
}
